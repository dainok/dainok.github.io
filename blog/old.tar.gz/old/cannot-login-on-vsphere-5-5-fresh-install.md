---
title: "Cannot login on vSphere 5.5 (fresh install)"
date: "2014-06-17T09:00:00+01:00"
draft: false
---
After vSphere 4.X setup, administrator user was automatically allowed to login with admin privileges. After a vSphere 5.5 install, administrator user cannot login via vClient:

![no_permissions](/images/posts/2014/06/no_permissions.png "no_permissions")

Using Web Client, an unparsed error message appears:

~~~
In order for this direct link to work, you must first log in to the vSphere Web Client at least once from https://{webclient-host}:{webclient-https-port}.
~~~

First login must manually connect to port 9443, but seems that Administrator does not have any permissions (again):

![no_roles](/images/posts/2014/06/no_roles.png "no_roles")

In fact Administrator used is no more allowed to browse vSphere ingrastructure by default. First login must be from SSO Administrator (**administrator@vsphere.local** on vSphere 5.5, **admin@system-domain** on previous vSphere 5.X) with the related SSO password:

![roles_after_login](/images/posts/2014/06/roles_after_login.png "roles_after_login")

Domain and local users are available, but they don't have any permissions. Let's allow domain administrators to connect to:

![allowed_admin](/images/posts/2014/06/allowed_admin.png "allowed_admin")

Don't use "Administrators" domain group, use "Domains Admins" instead, or a permission error will occour (log from vpxd-alert.log):

~~~
2014-06-17T09:58:29.087+02:00 [01756 info '[SSO]' opID=123C4D52-00000004-ae] [UserDirectorySso] Authenticate(example\administrator, "not shown")
2014-06-17T09:58:29.575+02:00 [01756 info '[SSO]' opID=123C4D52-00000004-ae] User EXAMPLE\Administrator authenticated successfully.
2014-06-17T09:58:29.578+02:00 [01756 info 'Default' opID=123C4D52-00000004-ae] [Auth]: User EXAMPLE\Administrator
2014-06-17T09:58:29.581+02:00 [01756 info 'commonvpxLro' opID=123C4D52-00000004-ae] [VpxLRO] -- FINISH task-internal-395 -- -- vim.SessionManager.login --
2014-06-17T09:58:29.581+02:00 [01756 info 'Default' opID=123C4D52-00000004-ae] [VpxLRO] -- ERROR task-internal-395 -- -- vim.SessionManager.login: vim.fault.NoPermission:
--> Result:
--> (vim.fault.NoPermission) {
--> dynamicType = <unset>,
--> faultCause = (vmodl.MethodFault) null,
--> object = 'vim.Folder:group-d1',
--> privilegeId = "System.View",
--> msg = "",
--> }
--> Args:
-->
~~~

Finally we can set EXAMPLE domain as default identity sources, so users can obmit the EXAMPLE domain when logging in:

![default_identity_sources](/images/posts/2014/06/default_identity_sources.png "default_identity_sources")

After the SSO administrator login, the above error (https://{webclient-host}:{webclient-https-port}) disappears, and a proper redirect is configured.
