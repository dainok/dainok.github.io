---
title: "Configuring OSPF between Logical and Edge routers on VMware NSX"
date: "2015-01-15T09:00:00+01:00"
draft: false
---
On [Distributed routing on VMware NSX](http://www.routereflector.com/2015/01/distributed-routing-on-vmware-nsx/ "Distributed routing on VMware NSX") the following topology has been deployed:

![nsx_ospf_1](/images/posts/2015/01/nsx_ospf_1.png "nsx_ospf_1")

The next step is adding an Edge router which can manage external traffic. On a next post the Edge router will be bridged to a physical network. The expected topology will be the following:

![nsx_ospf_2](/images/posts/2015/01/nsx_ospf_2.png "nsx_ospf_2")

Open the Web Client and go to "Networking & Security ->Logical Switches" and add a new segment:

![nsx_ospf_4](/images/posts/2015/01/nsx_ospf_4.png "nsx_ospf_4")

Then go to "Networking & Security -> NSX Edges" and add a "Edge Service Gateway"

![nsx_ospf_3](/images/posts/2015/01/nsx_ospf_3.png "nsx_ospf_3")Set admin password, enable SSH and HA:

![nsx_ospf_5](/images/posts/2015/01/nsx_ospf_5.png "nsx_ospf_5")



Select where to deploy the edge router:

![nsx_ospf_6](/images/posts/2015/01/nsx_ospf_6.png "nsx_ospf_6") And attach the edge router to the new logical switch:

![nsx_ospf_7](/images/posts/2015/01/nsx_ospf_7.png "nsx_ospf_7")

Skip (for now) the default gateway and firewall configuration.

While the new edge router is deploying, connect the distributed router to the new logical switch. Go to "Networking & Security -> NSX Edges", double click on the LDR and go to "Settings -> Interfaces". Add a new interface connected to the new logical switch:

![nsx_ospf_8](/images/posts/2015/01/nsx_ospf_8.png "nsx_ospf_8")

Type must be "Uplink" not "Internal". OSPF can be configured on "Uplink" interfaces only.

Go to "Routing -> Global Configuration" and edit "Dynamic Routing Configuration".  Set an unique router ID and publish changes:

![nsx_ospf_12](/images/posts/2015/01/nsx_ospf_12.png "nsx_ospf_12")

Go to "Routing -> OSPF" and add a new area 0:

![nsx_ospf_9](/images/posts/2015/01/nsx_ospf_9.png "nsx_ospf_9")

Map now the LIF facing the external logical switch to Area 0:

![nsx_ospf_10](/images/posts/2015/01/nsx_ospf_10.png "nsx_ospf_10")

Click on the "Edit" button and enable OSPF setting protocol and forwarding address:

![nsx_ospf_11](/images/posts/2015/01/nsx_ospf_11.png "nsx_ospf_11")

Use the IP address of the LIF facing the new (external) logical switch as forwarding address and another IP address on the same subnet as protocol address:

![nsx_ospf_13](/images/posts/2015/01/nsx_ospf_13.png "nsx_ospf_13")

The protocol address is assigned to the control VM. The control VM is a VM deployed with the distributed router which manages the control plane (in this case OSPF neighbor
adjacencies and update the routing table).

Finally publish changes to the LDR.

Now go back to the edge router ("Netwroking & Security -> NSX Edges" and double click on the edge router), go to "Manage -> Routing -> Global Configuration", enable the router ID and publish changes:

![nsx_ospf_14](/images/posts/2015/01/nsx_ospf_14.png "nsx_ospf_14")

Open now the OSPF tab, and configure the interface facing the external logical switch for OSPF:

![nsx_ospf_15](/images/posts/2015/01/nsx_ospf_15.png "nsx_ospf_15")

Press now the "Edit" button, enable OSPF and "Default Originate":

![nsx_ospf_16](/images/posts/2015/01/nsx_ospf_16.png "nsx_ospf_16")

OSPF should now be active and the edge router should have all networks connected to the DLR. Default gateway on DLR is not present because the edge router doesn't have it yet.

VM1 and VM2 cannot ping the edge router because it's configure with a firewall by default.

The [Connecting Edge Router to physical LAN using VMware NSX](http://www.routereflector.com/2015/01/connecting-edge-router-to-physical-lan-using-vmware-nsx/ "Connecting Edge Router to physical LAN using VMware NSX") will show how to connect the edge router to the external (physical) network.
