---
title: "802.1x on Cisco Catalyst 2950"
date: "2014-07-17T09:00:00+01:00"
draft: false
---
A very short post about 802.1x (dot1x) on Cisco Catalyst 2950 series. Configure RADIUS and enable dot1x on the switch:

~~~
aaa authentication dot1x default group radius
aaa accounting dot1x default start-stop group radius
dot1x system-auth-control
~~~

Then enable dot1x on all interfaces (additional security commands are added in the example below):

~~~
interface FastEthernet0/1
 switchport mode access
 switchport nonegotiate
 switchport port-security maximum 5
 switchport port-security
 switchport port-security aging time 5
 switchport port-security violation restrict
 switchport port-security aging type inactivity
 dot1x port-control auto
 dot1x timeout tx-period 2
 dot1x guest-vlan 666
 dot1x auth-fail vlan 666
 no cdp enable
 spanning-tree portfast
 spanning-tree bpduguard enable
~~~

**Important:** be sure you have the latest IOS (c2950-i6k2l2q4-mz.121-22.EA14.bin) or unauthorized port won't learn PC's MAC address.
