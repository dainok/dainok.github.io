---
title: "Configuring presence locator in Home Assistant"
date: "2016-10-05T09:00:00+01:00"
draft: false
---
This post will show how to configure presence locator in Home Assistant using Owntracks and a personal server.

## Installing HBMQTT

Installing HBMQTT is very easy and requires a single command:

~~~
# pip install hbmqtt
~~~

## Configuring HBMQTT

The following configuration enable two different HBMQTT instances:

~~~
listeners:
  default:
    type: tcp
  my-tcp-1:
    bind: 127.0.0.1:1882
  my-tcp-2:
    bind: 0.0.0.0:1883
    ssl: on
    certfile: /etc/ssl/certs/apache-default.crt
    keyfile: /etc/ssl/private/apache-default.key
auth:
  allow-anonymous: false
  password-file: /etc/hbmqtt/mqttaccess
~~~

The first instance is dedicated to Home Assistant without authentication and it's not accessible from outside. The second instance is available to the external world via https and using a password file.

Check also my updated [HBMQTT configuration file](https://github.com/dainok/rrlabs/blob/master/linux/etc/hbmqtt/hbmqtt.yaml "hbmqtt.yaml").

Add also at least one user:

~~~
# mkpasswd -m sha-512
~~~

Add a user and the above hash to `/etc/hbmqtt/mqttaccess` file in the following form:

~~~
hass:veryverylonghash
andrea:veryverylonghash
~~~

Do not leave empty lines at the end.

## Starting HBMQTT

Create a startup script as following:

~~~
# /etc/systemd/system/hbmqtt@hass.service
[Unit]
Description=HBMQTT for Home Assistant
After=network.target

[Service]
Type=simple
User=root
ExecStart=/usr/local/bin/hbmqtt -c /etc/hbmqtt/hbmqtt.yaml
SendSIGKILL=yes
RestartForceExitStatus=100

[Install]
WantedBy=home-assistant@hass.service
~~~

Check also [my updated HBMQTT startup script](https://github.com/dainok/rrlabs/blob/master/linux/etc/systemd/system/hbmqtt.service "hbmqtt@hass.service").

Then enable HBMQTT at boot and start it:

~~~
# systemctl daemon-reload
# systemctl enable hbmqtt
# systemctl start hbmqtt
~~~

## Debugging HBMQTT script

Check if HBMQTT is running:

~~~
# systemctl -l status hbmqtt
~~~

There is a bug in the current version with SSL. If you see the following error, you need to update:

~~~
Sep 29 11:00:50 darkgate hbmqtt[1706]: AttributeError: 'module' object has no attribute 'open'
~~~

~~~
[2016-09-29 12:14:57,402] :: ERROR * Broker startup failed: 'bool' object has no attribute 'upper'
Traceback (most recent call last):
  File "/usr/local/lib/python3.4/dist-packages/hbmqtt/broker.py", line 240, in start
    if 'ssl' in listener and listener['ssl'].upper() == 'ON':
AttributeError: 'bool' object has no attribute 'upper'
~~~

I suggest to update the `broker.py` file:

~~~
# wget -q -O* https://raw.githubusercontent.com/beerfactory/hbmqtt/develop/hbmqtt/broker.py > /usr/local/lib/python3.4/dist-packages/hbmqtt/broker.py
~~~

## Configuring Owntracks on Android

Install [Owntracks](https://play.google.com/store/apps/details?id=org.owntracks.android "Owntracks") from Google Play Store, and configure in in the following way:

* Connection
	* Mode: `Private MQTT`
	* Host:
		* Host: your FQDN registered on FreeDNS (i.e. `example.moo.com`)
		* Port: `1883`
		* Use WebSockets: no
	* Identification:
		* Authentication: yes
		* Username: your configured username on HBMQTT (using `mkpasswd`)
		* Password: your configured password on HBMQTT (using `mkpasswd`)
		* Device ID: your name (i.e. `Andrea`)
		* Tracker id: your initials (i.e. `ad`)
	* Security:
		* TLS: yes
		* CA certificate: import `apache-default.crt` used by HBMQTT
		* Client certificate: empty
	* Parameters:
		* Clean Session: yes
		* Keepalive: `300`
* Reporting:
	* Automatic location reporting: yes
	* Include extended data in location report: yes
* Notifications:
	* Notifications: yes
	* Last reported location: yes
	* Events: yes
* Services:
	* Remote commands: yes
	* Locator foreground accuracy: `Low power`
	* Locator background accuracy: `Low power`
	* Locator background displacement: `500`
	* Locator background interval: `300`
	* Encryption key: empty
	* Autostart: yes

## Configuring Home Assistant

Home Assistant must be attached to HBMQTT server. Edit `configuration.yaml`:

~~~
device_tracker:
  platform: owntracks
  max_gps_accuracy: 50
~~~

Then some zones must be configured. Each zone describe a location which users can enters in or leave:

~~~
zone:
    name: Home
    latitude: 12.3456789
    longitude: 23.4567890
    radius: 200
    icon: mdi:home
zone 2:
    name: Work
    latitude: 45.6789012
    longitude: 67.8901234
    radius: 200
    icon: mdi:city
zone 3:
    name: School
    latitude: 89.0123456
    longitude: 90.1234567
    radius: 200
    icon: mdi:school
zone 4:
    name: Library
    latitude: 12.3456789
    longitude: 23.4567890
    radius: 200
    icon: mdi:library
~~~

Save and restart Home Assistant.
When each mobile user connects to HBMQTT reporting the location, Home Assistant will add each user to the `known_devices.yaml` file, creating it if necessary.

## Automation using presence

AThe file `known_devices.yaml` contains all discovered devices by Home Assistant. They are not formally "users", but "devices". Devices can be grouped to identify users, but it's out of scope for now.

Here an example of `known_devices.yaml` file:

~~~
andrea_andrea:
	name: Andrea
	mac:
	picture:
	track: yes
	hide_if_away: no
~~~

The above device can be used to automate things. In the following example, when "Andrea" enters "home" a notification via Pushover is sent:

~~~
alias: Notify when Andrea enters home
trigger:
  platform: zone
  entity_id: device_tracker.andrea_andrea
  zone: zone.home
  event: enter
action:
  * service: notify.andrea_mobile
    data:
      title: "Andrea is at home"
      message: "Andrea is arrived at home."
~~~

The `notify.yaml` file define the Pushover service:

~~~
* platform: pushover
  name: andrea_mobile
  api_key: your_api_key
  user_key: your_email_key
~~~

## References

* [HBMQTT](https://hbmqtt.readthedocs.io/en/latest/ "HBMQTT")
* [Home Assistant * Owntracks](https://home-assistant.io/components/device_tracker.owntracks/ "Home Assistant * Owntracks")
* [Home Assistant * MQTT](https://home-assistant.io/components/mqtt/ "Home Assistant * MQTT")
* [Home Assistant * Zone](https://home-assistant.io/components/zone/ "Home Assistant * Zone")
