---
title: "Install and configure vSphere Data Protection (VDP/VDPA)"
date: "2014-08-07T09:00:00+01:00"
draft: false
---
The vSphere Data Protection appliance allows to backup virtual machines with a built-in tool instead of a third-party backup product. VDP is available on all vSphere editions but Essentials Kit. Moreover VDP can be extended to VDPA (vSphere Data Protection Advanced). Basically VDPA has the same features of VDP, except:

* VDPA has a per-CPU (socket) license, VDP is included on most vSphere editions.
* VDPA can store 8TB of deduplicated backup, VDP can store 2TB only.
* VDPA can backup up to 400 VMs, VDP can backup 100 only. Up to 10 VDP/VDPA can be installed in a single vCenter, so up to 4000 VMs can be backuped using VDPA.
* VDPA can be integrated with Microsoft SQL and Exchange Server using an agent installed withing the Windows VM.

VDP appliance is distributed by EMC and it's based on Avamar software.

## Installation

Download the latest VMware vSphere Data Protection appliance from the VMware site. Import the OVA file into the vSphere infrastructure configuring network parameters.

After the first boot I strongly suggest to manually configure NTP server. Login to the VDP appliance using SSH (default root password is "changeme"), edit the `/etc/ntp.conf` file and add at least one NTP server:

~~~
# /etc/ntp.conf
[...]
server 127.127.1.0 # local clock (LCL)
server ntp.example.com
fudge 127.127.1.0 stratum 10 # LCL is unsynchronized
[...]
~~~

Then sync the clock, start the NTP server and mark it to start during the boot process:

~~~
# service ntp stop
# sntp -P no -r
# service ntp start
# chkconfig ntp on
~~~

If the system time differs between VPD appliance and SSO, the VDP will disconnect itself and report the following error:

> Connecting to the VMware vSphere Data Protection Appliance fails with the error: The most recent request has been rejected by the server. The most common cause for this error is that the times on the VDP appliance and your SSO server are not in sync (2040078)

In my test the system clock of VDP appliance run about twice faster than real clock. It should a [Time drifting when running a Linux guest under VMware ESX server](https://www.novell.com/support/kb/doc.php?id=3858673 "Time drifting when running a Linux guest under VMware ESX server") already solved, but I had to add the clock=pit boot option in the `/boot/grub/menu.lst` file:

~~~
# /boot/grub/menu.lst
[...]
title SUSE Linux Enterprise Server 11 SP1 - 2.6.32.59-0.7
    root (hd0,0)
    kernel /vmlinuz-2.6.32.59-0.7-default root=/dev/sda2 append dns=10.6.254.4 DH resume=/dev/sda3 splash=silent crashkernel=256M-:128M showopts clock=pit
    initrd /initrd-2.6.32.59-0.7-default
[...]
~~~

A reboot is required.

## Configuration

After the first boot, the VDP appliance must be configured using a browser and point to https://172.31.30.8:8543/vdp-configure/ (default password is still "changeme"). First configuration requires to review:

* network settings: IPv4 address, netmask, gateway, DNS servers, hostname and domain. (VDP hostname must be resolved by the DNS.
* Time zone.
* root password: password must be exactly 9 chars long, with at least one digit, one lowercase letter and one uppercase letter. No special chars are allowed.
* vCenter hostname, with administrative credential.
* VDP license, if VDPA is used.
* Add o attach an existing storage, where backup file will be stored.
* Allocate storage and set them as Thin or Tick.
* Review CPU and memory allocations based on storage capacity.

I got a couple of error during this phase:

* The first error happened during the vCenter registration:

> The specified user is not a dedicated VDP user or does not have sufficient vCenter privileges to administer the VDP Appliance. Please update your user role and try again.
> NOTE: The user must not inherit roles from a group.

The solution is explained inside the message: the user must be configured as administrator and cannot inherit permission from a group.
![user_privileges](/images/posts/2014/08/user_privileges.png "user_privileges")

* The second error happened during the Add/Attach storage:

> Cannot proceed because the appliance already has attached storage.

A reboot solved my issue. Check also for duplicated IP addresses.

After an additional reboot, which will require more time, the VDP interface is available using the Web Client (Home -> vSphere Data Protection).

New backup can be added and scheduled within the backup time (from 20:00 to 8:00 by default).

![vdp](/images/posts/2014/08/vdp.png "vdp")

If backups fail with "Error: Failed to remove snapshot." error, the subprocess timeout should be increased (see [KB:2044821](http://kb.vmware.com/selfservice/microsites/search.do?language=en_US&cmd=displayKC&externalId=2044821 "KB:2044821")). By the way the next backup should complete without errors.

## References

* [Time drifting when running a Linux guest under VMware ESX server](https://www.novell.com/support/kb/doc.php?id=3858673 "Time drifting when running a Linux guest under VMware ESX server")
* [vSphere Data Protection backup jobs fail intermittently (2044821)](http://kb.vmware.com/selfservice/microsites/search.do?language=en_US&cmd=displayKC&externalId=2044821 "vSphere Data Protection backup jobs fail intermittently (2044821)")
