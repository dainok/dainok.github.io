---
title: "Cisco One and OnePK: a short introduction"
date: "2013-09-24T09:00:00+01:00"
draft: false
---
Cisco Open Network Environment (ONE) is the Cisco Software Defined Network (SDN) strategy. Cisco ONE includes:

* The Cisco One Platform Kit (onePK): a set of APIs that allow application to control Cisco devices without a CLI. Cisco onePK is available on Cisco IOS, IOS-XE, IOS-XR and NX-OS software. Currently onePK is available on CSR1000V and on few IOU/IOL images to develop and test onePK software in a safe environment. Cisco onePK libraries are currently available for C and Java compilers but they are not available outside Cisco.
* The Cisco ONE Controller: is the Control Plane for a set of ONE enabled devices. Cisco supports OpenDaylight project: the first download is expected in Q4 of 2013.
* An overlay network solutions that include the Cisco Nexus 1000V (Data Center), CSR1000V and other various IOS/IOS-XE/IOS-XR/NX-OS platforms.

SDN "should" helps network administrator because it aggregates a lot of network devices under one controller. NetApp started the same evolution few years ago with Cluster Mode over the 7-Mode:: each 7-Mode NetApp storage is independent, a Cluster Mode can aggregate many NetApp storage and present just one storage. Each single storage becomes transparent.
I expect that SDN allows to manage many devices like a single ones: interactions within a single complex big network device can be enhanced because the same device spreads over a larger space. Managing and monitoring should be simpler too: rather than hundreds devices, just one controller is needed. And, of course, human error can be worse than ever: one error will spread over all devices.

In my mind a good parallel with Cisco ONE is Gaia (http://en.wikipedia.org/wiki/New_Age_Gaian): single network devices are like single humans, a Cisco ONE implementation is like Gaia.

## Cisco OnePk

Cisco OnePk (Cisco One Platform Kit) is a framework to develop Cisco ONE software. I liked the parallel made by [Joel Knight's Blog](http://www.packetmischief.ca/ "Joel Knight's Blog"): Wordpress is a blog framework written in PHP. A specific Blog is a Wordpress implementation. Cisco OnePK is a set of libraries written in C/Java, a specific Cisco ONE application is a Cisco OnePK implementation. The Cisco ONE Controller is a Cisco ONE implementation which uses the Cisco OnePk framework.

Today, Cisco OnePk is a set of libraries for Java and C programming languages. Currently [onePK Developer](http://developer.cisco.com/web/onepk/home "onePK Developer") is not available to the public. Only few enterprise or service provider customers can apply to OnePk program.

### A very simple Cisco OnePk application

Each router used by a Cisco ONE application must enable onep:

~~~
username admin privilege 15 password 0 cisco
onep
 transport socket
 start
~~~

A privileged username is required by the ONE application. Also ONE session can use clear (socket) or encrypted communications (TLS).

~~~
Router#show onep status
Status: enabled
Version: 0.6.0
Transport: socket; Status: running; Port: 15001
Transport: tls; Status: disabled
Transport: tipc; Status: disabled
~~~

The following code will get the CPU usage value from a specific router using onep API:

~~~
import com.cisco.onep.core.exception.OnepException;
import com.cisco.onep.element.NetworkApplication;
import com.cisco.onep.element.NetworkElement;
import java.net.InetAddress;

public class OnePkVerySimpleApp {
	public static void main( String args[] ) {
		try {
			InetAddress device_address = InetAddress.getByName("192.168.32.129");
			NetworkElement onep_device = NetworkApplication.getInstance().getNetworkElement(device_address);
			onep_device.connect("admin", "cisco");

			System.out.print("CPU usage: ");
			System.out.println(onep_device.getSystemCPUUtilization());

			onep_device.disconnect();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}
~~~

The code should be auto-explained:

* a network device is defined;
* a onep session is established using privileged credentials;
* the CPU utilization value is get and printed;
* the onep session is closed.

I think that the first use of Cisco OnePk is monitoring. Custom application can be easily developed to integrate Cisco devices within a single Java-enabled monitoring dashboard.
Advanced Cisco ONE applications could be able to modify routing and maybe alter packets.

## Cisco ONE Controller: the OpenDaylight project

The OpenDaylight project is a SDN platform supported by Cisco, Brocade, Citrix, Juniper, VMware Huawei and other vendors. OpenDaylight project supports Openflow, and ONE also, I suppose:
<a href="http://www.opendaylight.org/announcements/2013/09/opendaylight-project-releases-new-architecture-details-its-software-defined">![OpenDaylight Project](/images/posts/2013/09/hydrogen_diagram_-_final.jpg "OpenDaylight Project")
So, the Cisco ONE Controller is one of the Cisco ONE software supported by Cisco itself. It should be the mind (the control-plane) for all devices available in your network.
The first download from the project is expected in Q4 of 2013.

## Conclusions / My opinion

How SDN will impact in out networks is not easy to predict. SDN can enhance network applications but complexity could limit SDN applications. Monitoring applications will be enhanced, but this is not the main purpose of SDN. The most effective SDN applications should regards routing process: SDN should be able to route packets using business decision process rather than BGP/EIGRP/OSPF protocols. SDN should be able to manipulate packets also, but the question is: is there anyone who can understand network and can develop C/Java softwares.

My opinion is that SDN will require another specific engineer: a sort of Network DevOps, a CCIE with strong programming skills. I remember the 2013 1st April fool joke, the Cisco [New Cisco Certification &ndash; CCNA ONE (Open Network Environment) &ndash; April Fools&rsquo; Day Prank](http://www.itcertificationmaster.com/new-cisco-certification-ccna-one-open-network-environment/ "New Cisco Certification &ndash; CCNA ONE (Open Network Environment) &ndash; April Fools&rsquo; Day Prank"). It was a joke, but I'm not totally sure if it can became true, sooner or later.

## References

* [Cisco Open Network Environment](http://www.cisco.com/web/solutions/trends/open_network_environment/index.html "Cisco Open Network Environment")
* [Cisco OnePk Developer Program](http://developer.cisco.com/web/onepk/home "Cisco OnePk Developer Program")
* [Cisco onePK Use Cases](http://developer.cisco.com/web/onepk-developer/use-cases "Cisco onePK Use Cases")
* [Cisco onePK FAQ](http://developer.cisco.com/web/onepk-developer/faqs "Cisco onePK FAQ")
* [Cisco ONE Tutorials for Java](http://developer.cisco.com/web/onepk-developer/tutorials-for-java "Cisco ONE Tutorials for Java")
* [Cisco OnePk SDK and; Docs](http://developer.cisco.com/web/onepk-developer/sdk-and-docs "Cisco OnePk SDK and; Docs")
* [Cisco onePK: Now I Get It](http://www.packetmischief.ca/2013/07/15/cisco-onepk-now-i-get-it/ "Cisco onePK: Now I Get It")
* [Cisco onePK Screencast](http://www.packetmischief.ca/2013/07/22/cisco-onepk-screencast/ "Cisco onePK Screencast")
* [Cisco ONE Technology Presentations and Demos](http://www.cisco.com/web/solutions/trends/open_network_environment/presentations.html "Cisco ONE Technology Presentations and Demos")

* [Cisco SDN Live Seminars](https://learningnetwork.cisco.com/community/learning_center/sdn_live_seminars "Cisco SDN Live Seminars")
* [SDN: Software Defined Networks (book)](http://www.amazon.co.uk/SDN-Software-Networks-Thomas-Nadeau/dp/1449342302/ "SDN: Software Defined Networks (book)")
* <a title="A response to Padma Warrior's "Limitations of a Software-Only Approach to Data Center Networking"" href="http://www.networkworld.com/community/blog/response-padma-warriors-limitations-software-only-approach-data-center-networking">A response to Padma Warrior's "Limitations of a Software-Only Approach to Data Center Networking"</a>
* [Cisco Automation with Puppet and onePK](http://www.slideshare.net/getyourbuildon/cisco-automation-with-puppet-and-onepk "Cisco Automation with Puppet and onePK")
