---
title: "Syslog"
date: "2013-09-13T09:00:00+01:00"
draft: false
---
Syslog is a standard service for local and remote logging. Remote logging uses UDP protol, port 514. Syslog is installed by default in all Linux/Unix systems, and I geass all network devices can use syslog for remote logging. There are free software which configure Windows systems to use syslog too.

A centralized syslog server can acquires log from all remote devices: analyzing/managing logs became more simple.

All Linux distributions include a syslog server. In this article rsyslog will be used. Default configuration enable local logging only under /var/log.

## Configuration

Default config file is included within a single file: /etc/rsyslog.conf. Additional files can be included under /etc/rsyslog.d/ directory, which is included by default from the main config file.
Let's add a custom file to enable a per source/data logging:

~~~
# /etc/rsyslog.d/custom.conf
$template REMOTE,"/var/log/remote/%$YEAR%/%$MONTH%/%$DAY%/%HOSTNAME%-%FROMHOST-IP%.log"

$template CISCO,"/var/log/cisco.log"
$template RADWARE,"/var/log/radware.log"
$template SWITCH,"/var/log/switch.log"
$template VMWARE,"/var/log/vmware.log"

if $source != 'loghost' then ?REMOTE
if $source != 'loghost' and $syslogseverity == '3' then ?VMWARE
if $source != 'loghost' and $syslogseverity == '4' then ?SWITCH
if $source != 'loghost' and $syslogseverity == '5' then ?CISCO
if $source != 'loghost' and $syslogseverity == '6' then ?RADWARE
~~~

The first line configure a log file template: log files will be stored under a year/month/day directory path, and the filename will include the hostname (defined by the source) and the source IP address.
The following four lines will define a per vendor logfile, used by automatic log analyzer.
The last five lines will store incoming logs using the proper templates.

## Log rotation

Red Hat Linux uses logrotate for log rotation. The configuration is simple:

~~~
# /etc/logrotate.d/custom
/var/log/cisco.log
/var/log/radware.log
/var/log/switch.log
/var/log/vmware.log
{
    sharedscripts
    postrotate
        /bin/kill -HUP `cat /var/run/syslogd.pid 2> /dev/null` 2> /dev/null || true
    endscript
}
~~~

## Log analysis

All incoming logs are duplicated: each log will be stored under a per source file and under a per vendor file. The reason is simple: logwatch can automatically analyze log files using specific rules.

### Installation

The logwatch installation is very simple:

~~~
yum -y install logwatch
~~~

### Configuration

The lowatch configuration require to specific which rule should be enabled. By default a lot of rules (stored under /usr/share/logwatch/default.conf/services/) are enabled. The complete list can be shown with the following:

~~~
ls -1 /usr/share/logwatch/default.conf/services/ | sed 's/\.conf//'
~~~

We wants only Cisco rules to be enabled:

~~~
# /etc/conf/logwatch.conf
MailTo = noc@example.com
MailFrom = audit@example.com

Service = "-afpd"
Service = "-amavis"
Service = "-arpwatch"
Service = "-audit"
Service = "-automount"
Service = "-autorpm"
Service = "-bfd"
#Service = "-cisco"
Service = "-clamav"
Service = "-clamav-milter"
Service = "-clam-update"
Service = "-courier"
Service = "-cron"
Service = "-denyhosts"
Service = "-dhcpd"
Service = "-dnssec"
Service = "-dovecot"
Service = "-dpkg"
Service = "-emerge"
Service = "-evtapplication"
Service = "-evtsecurity"
Service = "-evtsystem"
Service = "-exim"
Service = "-eximstats"
Service = "-extreme-networks"
Service = "-fail2ban"
Service = "-ftpd-messages"
Service = "-ftpd-xferlog"
Service = "-http"
Service = "-identd"
Service = "-imapd"
Service = "-init"
Service = "-in.qpopper"
Service = "-ipop3d"
Service = "-iptables"
Service = "-kernel"
Service = "-mailscanner"
Service = "-modprobe"
Service = "-mountd"
Service = "-named"
Service = "-netopia"
Service = "-netscreen"
Service = "-oidentd"
Service = "-openvpn"
Service = "-pam"
Service = "-pam_pwdb"
Service = "-pam_unix"
Service = "-php"
Service = "-pix"
Service = "-pluto"
Service = "-pop3"
Service = "-portsentry"
Service = "-postfix"
Service = "-pound"
Service = "-proftpd-messages"
Service = "-pureftpd"
Service = "-qmail"
Service = "-qmail-pop3d"
Service = "-qmail-pop3ds"
Service = "-qmail-send"
Service = "-qmail-smtpd"
Service = "-raid"
Service = "-resolver"
Service = "-rt314"
Service = "-samba"
Service = "-saslauthd"
Service = "-scsi"
Service = "-secure"
Service = "-sendmail"
Service = "-sendmail-largeboxes"
Service = "-shaperd"
Service = "-slon"
Service = "-smartd"
Service = "-sonicwall"
Service = "-sshd2"
Service = "-sshd"
Service = "-stunnel"
Service = "-sudo"
Service = "-syslogd"
Service = "-tac_acc"
Service = "-up2date"
Service = "-vpopmail"
Service = "-vsftpd"
Service = "-windows"
Service = "-xntpd"
Service = "-yum"
Service = "-zz-disk_space"
Service = "-zz-fortune"
Service = "-zz-network"
Service = "-zz-runtime"
Service = "-zz-sys"
~~~

logwatch run daily, started by crontab (/etc/cron.daily/0logwatch).

### Additional rules

Each logwatch rule is defined by three file:

* `/usr/share/logwatch/default.conf/logfiles/cisco.conf`: declares all files to analyze (`cisco.log` in this case);
* `/usr/share/logwatch/default.conf/services/cisco.conf`: declares some configuration about what to analyze;
* `/usr/share/logwatch/scripts/services/cisco`: declares all rule for log analysis.
