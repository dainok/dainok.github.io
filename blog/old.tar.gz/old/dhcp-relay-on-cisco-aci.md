---
title: "DHCP Relay on Cisco ACI"
date: "2018-03-28T09:00:00+01:00"
draft: false
---
DHCP server is a service to automatically configure IP addresses. Using a DHCP Relay server, DHCP servers can be centralized in a single place. Under Cisco ACI, configuring a DHCP Relay server is a very simple task.

Steps:

* Create a DHCP Server policy: Tenants -> &lt;tenant name&gt; -> Policies -> Protocol -> DHCP Relay -> Create DHCP Relay Policy and specify the IP address of the DHCP server and the associated EPG.
* Associate the policy to a bridge domain: Tenants -> &lt;tenant name&gt; -> Networking -> Bridge Domain -> &lt;bridge domain name&gt; -> DHCP Relay Labels -> Create DHCP Relay Label and associate the policy created above.
* Adjust contracts if needed.

The DHCP Server policy can also be created as a global policy, under Fabric -> Global Policies -> DHCP Relay.
