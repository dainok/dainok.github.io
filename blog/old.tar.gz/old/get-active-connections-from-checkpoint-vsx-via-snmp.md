---
title: "Get active connections from Checkpoint VSX via SNMPv3"
date: "2016-05-18T09:00:00+01:00"
draft: false
---
In this post we'll learn how to get active connections managed by a Checkpoint VSX firewall using Linux and formatting them in a table.

## Configuring Checkpoint VSX

This post assumes SNMP is already configured on Checkpoint VSX firewall. If not, please refers to [Checkpoint website](https://sc1.checkpoint.com/documents/R76SP.10/CP_R76SP.10_for_41000_Security_System_Getting_Started_Guide/94813.htm "SNMP in a VSX Gateway")

## Testing SNMP from Linux

Before testing you should know how to import external MIBs to a Linux system and test them. Because usually MIBs found around Internet may or may not working fine, I suggest to give a look to my [MIB repository](https://github.com/dainok/rrlabs/tree/master/.snmp/mibs "RRLabs MIB repository").

All Linux SNMP commands check for a MIBDIR environment variable. On my script I prefer a local custom MIB repository:

~~~
client$ export MIBDIRS=/home/andrea/.snmp/mibs
client$ snmpwalk -mALL -v3 -l authNoPriv -a MD5 -A password -u user 10.0.0.2 sysName
SNMPv2-MIB::sysName.0 = STRING: FW1
~~~

SNMP is correctly configured on Checkpoint VSX and we can get the system name. We'll use the following OID: `i.1.3.6.1.4.1.2620.1.16.23.1.1`.
iJust for testing, we can translate it using MIBS:

~~~
client$ snmptranslate -mALL .1.3.6.1.4.1.2620.1.16.23.1.1
CHECKPOINT-MIB::vsxCountersEntry
~~~

And back:

~~~
client$ snmptranslate -mALL -TB vsxCountersEntrybash
CHECKPOINT-MIB::vsxCountersEntry
client$ snmptranslate -mALL -On CHECKPOINT-MIB::vsxCountersEntry
.1.3.6.1.4.1.2620.1.16.23.1.1
~~~

Let's test it:

~~~
client$ snmpwalk -mALL -v3 -l authNoPriv -a MD5 -A password -u user 10.0.0.2 vsxCountersEntry
CHECKPOINT-MIB::vsxCountersVSId.1.0 = Counter32: 0
CHECKPOINT-MIB::vsxCountersVSId.2.0 = Counter32: 1
CHECKPOINT-MIB::vsxCountersVSId.10.0 = Counter32: 9
CHECKPOINT-MIB::vsxCountersConnNum.1.0 = Counter32: 270
CHECKPOINT-MIB::vsxCountersConnNum.2.0 = Counter32: 40931
CHECKPOINT-MIB::vsxCountersConnPeakNum.1.0 = Counter32: 696
CHECKPOINT-MIB::vsxCountersConnPeakNum.2.0 = Counter32: 48773
CHECKPOINT-MIB::vsxCountersConnTableLimit.1.0 = Counter32: 14900
CHECKPOINT-MIB::vsxCountersConnTableLimit.2.0 = Counter32: 99900
CHECKPOINT-MIB::vsxCountersPackets.1.0 = STRING: 5791595
CHECKPOINT-MIB::vsxCountersPackets.2.0 = STRING: 494016323
CHECKPOINT-MIB::vsxCountersDroppedTotal.1.0 = STRING: 71867
CHECKPOINT-MIB::vsxCountersDroppedTotal.2.0 = STRING: 1006741
CHECKPOINT-MIB::vsxCountersAcceptedTotal.1.0 = STRING: 5719728
CHECKPOINT-MIB::vsxCountersAcceptedTotal.2.0 = STRING: 493009582
CHECKPOINT-MIB::vsxCountersRejectedTotal.1.0 = STRING: 0
CHECKPOINT-MIB::vsxCountersRejectedTotal.2.0 = STRING: 0
CHECKPOINT-MIB::vsxCountersBytesAcceptedTotal.1.0 = STRING: 3821802634
CHECKPOINT-MIB::vsxCountersBytesAcceptedTotal.2.0 = STRING: 464996253770
CHECKPOINT-MIB::vsxCountersBytesDroppedTotal.1.0 = STRING: 4984422
CHECKPOINT-MIB::vsxCountersBytesDroppedTotal.2.0 = STRING: 200770403
CHECKPOINT-MIB::vsxCountersBytesRejectedTotal.1.0 = STRING: 0
CHECKPOINT-MIB::vsxCountersBytesRejectedTotal.2.0 = STRING: 0
CHECKPOINT-MIB::vsxCountersLoggedTotal.1.0 = STRING: 12119
CHECKPOINT-MIB::vsxCountersLoggedTotal.2.0 = STRING: 9440326
CHECKPOINT-MIB::vsxCountersIsDataValid.1.0 = Counter32: 1
CHECKPOINT-MIB::vsxCountersIsDataValid.2.0 = Counter32: 4294967295
~~~

If you get errors like the following:

~~~
CHECKPOINT-MIB::vsxCountersVSId.1.0 = Wrong Type (should be INTEGER): Counter32: 0
~~~

Now we can get the data as a table:

~~~
client$ snmptable -mALL -v3 -l authNoPriv -a MD5 -A password -u user -Cf , 10.0.0.2 .1.3.6.1.4.1.2620.1.16.23.1 | cut -d',' -f1-4 | column -t -s','
SNMP table: CHECKPOINT-MIB::vsxCountersTable
vsxCountersVSId                               vsxCountersConnNum  vsxCountersConnPeakNum  vsxCountersConnTableLimit
0                                             198                 696                     14900
1                                             40236               48773                   99900
~~~

If you get no data from instances grated than zero, you should edit a file:

~~~
[Expert@Hostname:0]# echo 30 > $FWDIR/conf/amon_vsx_refresh_interval
[Expert@HostName:0]# service snmpd restart
~~~

If you get the following error:

~~~
Was that a table? CHECKPOINT-MIB::vsxCountersEntry
~~~

Be sure you're getting `.1.3.6.1.4.1.2620.1.16.23.1` OID, not `.1.3.6.1.4.1.2620.1.16.23.1.1`, not `CHECKPOINT-MIB::vsxCountersEntry`.

## References

* [SNMP in a VSX Gateway](https://sc1.checkpoint.com/documents/R76SP.10/CP_R76SP.10_for_41000_Security_System_Getting_Started_Guide/94813.htm "SNMP in a VSX Gateway")
* [SNMP return 0 value when querying virtual systems](http://somoit.net/checkpoint-fw/checkpoint-snmp-return-0-value-when-querying-virtual-systems "SNMP return 0 value when querying virtual systems")
* [RRLabs MIB repository](https://github.com/dainok/rrlabs/tree/master/.snmp/mibs "RRLabs MIB repository")
