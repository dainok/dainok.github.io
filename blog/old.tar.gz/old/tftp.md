---
title: "TFTP"
date: "2013-09-12T09:00:00+01:00"
draft: false
---
TFTP or Trivial File Transfer Protocol is a simple file transfer protocol. TFTP uses UDP port 69, no authentication or encryption are supported, and directory navigation is not possible. Three file transfer methods are available: netascii (or ASCII for text files), octet (or image for binary files) and mail (not used anymore).

A TFTP client sends to the server a read request (RRW or Read ReQuest) or a write request (WRQ or Write ReQuest) using UDP protocol; destination port is 69 and source port is random (X). The TFTP server answers to the client with an ACK using a random source port (Y). Next data transfer will use only UDP ports X and Y (port 69 is not used anymore); each sent data packet (DAT) will be acknowledge (ACK).

## Client

From an IOS device, TFTP can be used as "redirection" destination:

~~~
Router#show tech-support | redirect tftp://192.168.10.1/Router_tech-support-20120819
~~~

TFTP can be used also to transfer files from and to the server:

~~~
Router#copy tftp://192.168.10.1/ios/c180x-advipservicesk9-mz.124-9.T7.bin flash:
~~~

## Server

A Cisco router can act as a TFTP server, allowing remote clients to get local stored files:

~~~
tftp-server flash:c180x-advipservicesk9-mz.124-9.T7.bin
~~~

Each local file must be declared as a TFTP file.
