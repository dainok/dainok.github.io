---
title: "Configure DNS and Routing on an ESXi host"
date: "2014-06-18T09:00:00+01:00"
draft: false
---
Configure IP addresses are configured under a VMkernel interface (Host -> Manage -> Networking -> VMkernel adapters):

![ip_on_esxi](/images/posts/2014/06/ip_on_esxi.png "ip_on_esxi")

DNS and default gateway are globally configured under Host -> Manage -> Networking -> TCP/IP configuration:

![dns_on_esxi](/images/posts/2014/06/dns_on_esxi.png "dns_on_esxi")

Using CLI:

~~~
export VI_SERVER=172.31.30.4
export VI_USERNAME=EXAMPLE\\Administrator
export VI_PASSWORD=Password
$ vicfg-vmknic -h esxi1.example.com -i 172.31.30.11 -n 255.255.255.224 "Management Network"
$ vicfg-vmknic -h esxi1.example.com -l
Interface  Port Group/DVPort             IP Family IP Address                        Netmask           MAC Address       MTU     Type        VMotion
vmk0       Management Network            IPv4      172.31.30.11                      255.255.255.224   00:1b:78:b8:13:fc 1500    STATIC      Not Available
vmk0       Management Network            IPv6      fe80::21b:78ff:feb8:13fc          64                00:1b:78:b8:13:fc 1500    STATIC      Not Available
$ esxcli -h esxi1.example.com system hostname set --host esxi1 --domain example.com
$ vicfg-dns -h esxi1.example.com --dns 172.31.30.3
$ vicfg-route -h esxi1.example.com -a default 172.31.30.1
~~~

Using Host Profiles:

* VMkernel IP address: Networking configuration -> Management Network -> IP address settings:
![ip_on_profiles](/images/posts/2014/06/ip_on_profiles.png "ip_on_profiles")
* Hostname, domain and DNS: Networking configuration -> NetStack Instance -> DNS configuration:
![dns_on_profiles](/images/posts/2014/06/dns_on_profiles.png "dns_on_profiles")
* Default gateway and static routes: Networking configuration -> NetStack Instance -> IP route configuration:
![routes_on_profiles](/images/posts/2014/06/routes_on_profiles.png "routes_on_profiles")
