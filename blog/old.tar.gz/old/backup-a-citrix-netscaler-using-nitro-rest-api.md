---
title: "Backup a Citrix NetScaler using (NITRO) REST API"
date: "2016-06-03T09:00:00+01:00"
draft: false
---
In this post we'll learn how to use Citrix NetScaler (NITRO) REST API, retrieve it and delete it.

## Dealing with NITRO API

NITRO API documetnations is located on each NetScaler instance under `download -> NITRO API Documentation`.

Let's create a backup:

~~~
client$ curl -s -k -X POST -H 'Content-Type:application/vnd.com.citrix.netscaler.systembackup+json' --basic --user nsroot:password -d '{"systembackup":{"filename":"daily_backup","level":"basic"}}' 'https://ns.example.com/nitro/v1/config/systembackup?action=create'
~~~

Let's monitor the job until it's completed:

~~~
client$ curl -s -k -X GET -H 'Content-Type:application/vnd.com.citrix.netscaler.systembackup+json' --basic --user nsroot:password "https://ns.example.com/nitro/v1/config/systembackup/daily_backup.tgz" | python -m json.tool
{
    "errorcode": 0,
    "message": "Done",
    "severity": "NONE",
    "systembackup": [
        {
            "createdby": "nsroot",
            "creationtime": "Fri Jun  3 09:28:49 2016",
            "filename": "daily_backup.tgz",
            "ipaddress": "10.0.1.100",
            "level": "basic",
            "size": 21,
            "version": "NS10.5-61.11"
        }
    ]
}
~~~

Let's the remote file into a local folder:

~~~
client$ scp nsroot@ns.example.com:/var/ns_sys_backup/daily_backup.tgz .
~~~

Finally remove the backup:

~~~
client$ curl -s -k -X DELETE -H 'Content-Type:application/vnd.com.citrix.netscaler.systembackup+json' --basic --user nsroot:password "https://ns.example.com/nitro/v1/config/systembackup/daily_backup.tgz" | python -m json.tool
{
    "errorcode": 0,
    "message": "Done",
    "severity": "NONE"
}
~~~
