---
title: "Connecting an external entity to Cisco ACI (external L2Out)"
date: "2018-03-23T09:00:00+01:00"
draft: false
---
The first and important step with a Cisco ACI fabric, is the connection of an external entity (switch, router, firewall...) to the fabric.

Starting from [the previous post](/2018/03/port-channel-on-aci/ "Connecting an external entity to Cisco ACI (L2Out)
") we'll modify the Switch2 so it will be connected as an external device. In other words, the Switch2 will be bound to another EPG and a contract will be defined to allow communication between Switch1 and Switch2.

If Switch1 will be bound (at the end) to a physical (internal) domain, Switch2 will be bound (at the end) to an external domain. Both domains will be connected to the same AAEP.

Always remember [the Cisco ACI Workflow](/2018/03/cisco-aci-workflow/ "The Cisco ACI Workflow").

Steps:

* Create an external bridged domain and associate the same AAEP used by the Switch1.
  - Associate all required VLANs to the new external domain.
* From the EPG bound to both Switch1 and Switch2, remove the static port facing Switch2.
* Add a new EPG (inside the same Application Profile):
  - assign the external domain
  - assign the port facing the Switch2 as a static port
* create a contract between the two EPGs

Mind that:

> Physical domain profiles(physDomP) are typically used for bare metalserver attachment and management
access.
> Bridged outside network domain profiles (l2extDomP) are typically used to connect a bridged external
network trunk switch to a leaf switch in the ACI fabric.

In other word you should use physical domain to attach end-host devices, and external bridge domain to connect switches. Apparently there are not big differences between the two type (you can use physical domains for both servers and switches) but it's nice to have hosts under a tree, and switches under the other tree.

Remember also that in a leaf, the same VLAN cannot be shared between EPGs:

> Fault delegate: Configuration failed for uni/tn-Tenant1/ap-AppProfile/epg-EpgNameExt node 101 eth1/18 due to Encap Already Used in Another EPG,Invalid Path Configuration, debug message: invalid-path: Either the EpG is not associated with a domain or the domain does not have this interface assigned to it;encap-already-in-use: Encap is already in use by IC:AppName:EpgName;

## References

* [The Cisco ACI Workflow](/2018/03/cisco-aci-workflow/ "The Cisco ACI Workflow")
