---
title: "Hot migrating from vSwitch to dvSwitch"
date: "2014-06-24T09:00:00+01:00"
draft: false
---
One important and crucial step about distributed switches is the migration from standard switches. In the following example a standard vSwitch uses two physical adapter as uplink: ![vSwitch0](/images/posts/2014/06/vSwitch0.png "vSwitch0") Both vmnics are active. We want to migrate VMs and VMkernel adapter to a distributed switch without downtime. During the migration process one adapter will be dedicated to the newly created distributed switch, and redundancy will be lost.

## Disable Beacon Probing

Beacon probes are used to check network connectivity. ESXi hypervisor expects to receive beacon probes from all vmnic active ports. If a vmnic stops to receive beacon probes, an failure has occurred in that network path (see [What is beacon probing? (1005577)](http://kb.vmware.com/selfservice/microsites/search.do?language=en_US&cmd=displayKC&externalId=1005577 "What is beacon probing? (1005577)") for more information). Beacon probes are used with three or more vmnics, so in this example they are not used. If used, remember to configure Network failure detection as "Link status only" until the migration is completed. ![disable_beacon_probing](/images/posts/2014/06/disable_beacon_probing.png "disable_beacon_probing")

## Remove a vmnic from vSwitch0

The physical server only holds two vmnic, and they are both configured under vSwitch0. One (vmnic1) will be removed and configured in a new distributed switch. Before removing vmnic1, be sure that underlying port group ("VM network" and "Management Network") do not override vSwitch0 failover order, or connectivity issues can happen: ![override_vswitch0](/images/posts/2014/06/override_vswitch0.png "override_vswitch0") In the above example, the Override flag must be unchecked. Now it's safe remove vmnic1 from the vSwitch0: ![remove_vmnic1](/images/posts/2014/06/remove_vmnic1.png "remove_vmnic1") During this step a single packet for each VM/VMkernel can be lost due to MAC address refresh state.

## Add a new distributed switch

Under vCenter -> Datacenter, add a Distributed Switch and follow the wizard, do not create a default port group, it will be created later. On the switch side, the port is configured as follows:

~~~
interface GigabitEthernet1/0/4
 description esxi2:vmnic1
 switchport trunk encapsulation dot1q
 switchport trunk native vlan 4094
 switchport mode trunk
 switchport nonegotiate
 spanning-tree portfast trunk
 spanning-tree bpduguard enable
~~~

Because it's an end host port, the best practice requires to configure BPDU guard to avoid L2 loops. Additional precautions must be taken, and they will be discussed on another post. Add a port group configured for the VLAN 1: ![add_dvswitch](/images/posts/2014/06/add_dvswitch.png "add_dvswitch") Port binding can be:

* **Static Binding (default):** a port is reserved to a VM connected to a port group; the port will be released only when the VM is disconnected or deleted.
* **Dynamic Binding (deprecated):** a port is reserved to a VM connected and powered on; the port will be released when the VM is powered off or disconnected.
* **Ephemeral - no binding:** only ephemeral binding allows to modify virtual machine network connections without vCenter. Ephemeral port groups should be used only for recovery purposes

If static binding is selected, Port allocation can be

* **Elastic (default):** port groups automatically add needed port or remove unused ports when needed.
* **Fixed:** deploy a static number of port (default 128).

VLAN Type can be::

* **None (default):** when uplinks are configured as access port, the same network will be available in the configured port group (and attached VMs). It's also used with the native VLAN if uplinks are configured as trunks.
* **VLAN (most common choice):**  when uplinks are configured as trunks, a specific VLAN tagged will be available as native in the configured port group (and attached VMs).
* **VLAN trunking:** when uplinks are configued as trunks, more than one VLAN will be tagged and available in the configured port group (and attached VMs).
* **Private VLAN:** if the physical and distributed switch support Private VLAN, this option can be used.

By default Promiscuous mode, MAC address changes and Forged transmits are rejected on distributed vSwitch. ![dvswitch0](/images/posts/2014/06/dvswitch0.png "dvswitch0")Add esxi2 to the dvSwitch0: ![add_host](/images/posts/2014/06/add_host.png "add_host")And select physical adapter only: ![manage_vmnic](/images/posts/2014/06/manage_vmnic.png "manage_vmnic") Assign vmnic1: ![add_vmnic1](/images/posts/2014/06/add_vmnic1.png "add_vmnic1") Now the dvSwitch0 is ready: ![dvSwitch0_configured](/images/posts/2014/06/dvSwitch0_configured.png "dvSwitch0_configured")

## Migrating VMs

Before migrating active VMs and VMkernel ports, a test VM should be configured under the dvSwitch0 to vrify network connectivity. After a successful test, we can migrate VMs from the old "VM Network" to the new "VLAN_1" network: ![migrate_vm](/images/posts/2014/06/migrate_vm.png "migrate_vm") And select all connected VM: ![select_vm](/images/posts/2014/06/select_vm.png "select_vm") Some packets can be lost due to migration process and MAC address table refresh. Migrating VMkernel port VMkernel ports can be migrated with the "Add and Manage Hosts" wizard (select "Add hosts", select esxi2 host and select "Manage VMkernel adapter" option only): ![migrate_vmkernel](/images/posts/2014/06/migrate_vmkernel.png "migrate_vmkernel")   Select vmk0 port and configure the right destination port group on the dvSwitch0: ![select_dvswitch0](/images/posts/2014/06/select_dvswitch0.png "select_dvswitch0")

## Restore redundancy

Now shutdown the switch port connected to the vmnic0 adapter and reconfigure it on the switch side:

~~~
interface GigabitEthernet1/0/3
 description esxi2:vmnic0
 switchport trunk encapsulation dot1q
 switchport trunk native vlan 4094
 switchport mode trunk
 switchport nonegotiate
 shutdown
 spanning-tree portfast trunk
 spanning-tree bpduguard enable
~~~

Open the "Add and Manage Hosts" wizard, migrate the vmnic0 adapter to the vSwtich0 switch and finally enable the interface on the physical switch:

![dvSwitch0_completed](/images/posts/2014/06/dvSwitch0_completed.png "dvSwitch0_completed")

Old standard switch vSwitch0 can now be deleted. Remember to enable Beacon Probing if previously used.
