---
title: "RADIUS authentication on Citrix NetScaler"
date: "2016-09-26T09:00:00+01:00"
draft: false
---
Configuring RADIUS authentication on Citrix NetScaler is pretty simple and takes just few minutes.

In the example below, two groups will be configured:

* `admins` with superuser privileges;
* `users` with read-only privileges.

Before starting remember that local users are always working. A local user can always authenticate despite of RADIUS servers status.

Connect to the NetScaler using the `nsroot` user:

~~~
add authentication radiusAction RADIUS-NPS-1 -serverIP 10.0.0.101 -serverPort 1812 -radKey longpassword -radVendorID 3845 -radAttributeType 25 -accounting ON
add authentication radiusAction RADIUS-NPS-2 -serverIP 10.0.0.102 -serverPort 1812 -radKey longpassword -radVendorID 3845 -radAttributeType 25 -accounting ON
add authentication radiusAction RADIUS-NPS-3 -serverIP 10.1.0.101 -serverPort 1812 -radKey longpassword -radVendorID 3845 -radAttributeType 25 -accounting ON
add authentication radiusAction RADIUS-NPS-4 -serverIP 10.1.0.102 -serverPort 1812 -radKey longpassword -radVendorID 3845 -radAttributeType 25 -accounting ON
add authentication radiusPolicy POLICY-RADIUS-NPS-PD-1 ns_true RADIUS-NPS-1
add authentication radiusPolicy POLICY-RADIUS-NPS-PD-2 ns_true RADIUS-NPS-2
add authentication radiusPolicy POLICY-RADIUS-NPS-MO-1 ns_true RADIUS-NPS-3
add authentication radiusPolicy POLICY-RADIUS-NPS-MO-2 ns_true RADIUS-NPS-4
bind system global POLICY-RADIUS-NPS-PD-1 -priority 201
bind system global POLICY-RADIUS-NPS-PD-2 -priority 202
bind system global POLICY-RADIUS-NPS-MO-1 -priority 203
bind system global POLICY-RADIUS-NPS-MO-2 -priority 204
add system group admins
add system group users
bind system group admins -policyName superuser 1
bind system group users -policyName read-only 1
~~~

Remeber that the following RADIUS attribute must also be configured:

* Vendor Code: `3845`
* Attribute number: `25`
* Attribute value: (string) `admins` or `users`
