---
title: "Switching to GitHub pages
Switching to GitHub pages"
date: "2015-06-05T09:00:00+01:00"
draft: false
---
Because of an high load on my website, Wordpress hosted by OVH seems no more suitable for my needs.
Because of an high load on my website, Wordpress hosted by OVH seems no more suitable for my needs.

## Jekyll installation

Install Ruby version 2, then use gem to install Jekyll:

~~~
# apt-get install ruby ruby-dev
# gem install jekyll
# gem install jekyll-sitemap
~~~

Start Jekyll:

~~~
# jekyll s --port 8080 --incremental -s /home/jekyll/ -d /var/www/html/
~~~

## Header and filename

The header of a page could be like the following:

~~~
~~~

The filename should be `2015-06-05-switching-to-github-pages.md`.

## Titles

#### Example

# Title 1

## Title 2

### Title 3

#### Title 4

##### Title 5

###### Title 6

#### Code

~~~
# Title 1

## Title 2

### Title 3

#### Title 4

##### Title 5

###### Title 6
~~~

## Paragraph

The following examples are used inside a paragraph.

### Bold text

#### Example

This is a ***bold*** text.

#### Code

~~~
This is a ***bold*** text.
~~~

### Inline code

#### Example

This is an `inline code`.

#### Code

~~~
This is an `inline code`.
~~~

### Internal link ###

#### Example

This is an [internal link]({% post_url 2015-06-05-switching-to-github-pages%} "link title").

#### Code

~~~
This is an [internal link]({% post_url 2015-06-05-switching-to-github-pages%} "link title").
~~~

### External link ###

#### Example

This is an [external link](http://www.google.com/ "Link title").

#### Code

~~~
This is an [external link](http://www.google.com/ "Link title").
~~~

### Image ###

#### Example

This is an image:

![Alt Text](/assets/images/logo_ad.png "Image title")

#### Code

~~~
![Alt Text](/assets/images/logo_ad.png "Image title")
~~~

### Image link ###

#### Example

This is a linked image:

[![Alt Text](/assets/images/logo_ad.png "Image title")](/2015/06/switching-to-github-pages/ "Link title")

#### Code

~~~
[![Alt Text](/assets/images/logo_ad.png "Image title")](/2015/06/switching-to-github-pages/ "Link title")
~~~

## Ordered list

### Example

1. Element 1
2. Element 2
    1. Nested element 2.1
    2. Nested element 2.2
3. Element 3

### Code

~~~
1. Element 1
2. Element 2
    1. Nested element 2.1
    2. Nested element 2.2
3. Element 3
~~~

## Unordered list

### Example

* Element 1
* Element 2
    - Nested element 2.1
    - Nested element 2.2
* Element 3

### Code

~~~
* Element 1
* Element 2
    - Nested element 2.1
    - Nested element 2.2
* Element 3
~~~

## Preformatted text (code)

### Example

~~~
This is a generic
multiline
code
~~~

### Code

<pre>~~~
This is a generic
multiline
code
~~~</pre>

## Quote (blockquote)

### Example

> This is
> a multiline
> quote

### Code

<pre>~~~
> This is
> a multiline
> quote
~~~</pre>

## Table

### Example

| Header 1 | Header 2 |
|:--|:--|
| Data 1.1 | Data 1.2 |
| Data 2.1 | Data 2.2 |
{: rules="groups"}

### Code

~~~
| Header 1 | Header 2 |
|:--|:--|
| Data 1.1 | Data 1.2 |
| Data 2.1 | Data 2.2 |
{: rules="groups"}
~~~

## References

* [Jekyll installation](https://jekyllrb.com/docs/installation/ "Jekyll installation")
* [Markdown syntax](https://daringfireball.net/projects/markdown/syntax "Markdown syntax")
