---
title: "Are Cisco ACI contracts stateful?"
date: "2018-03-26T09:00:00+01:00"
draft: false
---
An important question about contracts on Cisco ACI is: are contracts stateful or are they stateless? Or, in other words, do are contracts simple ACLs?

Let's assume two VMs, one in each specific EPG. VM2 is a web server, VM1 is a client.
Define a contract so the client (consumer) can connect to the web server (provider) using the port 80, and also apply on both direction (reversing filter ports, and missing the stateful flag).

Now VM1 can connect to VM2 using TCP 80 as destination port with any source port.

![Client to Web Server connection](/images/posts/2018/03/cisco_aci_contracts-1.png "Client to Web Server connection")

But can VM2 connect to VM1 to any port, using TCP 80 as a source port?

![Web Server to Client (reverse) connection](/images/posts/2018/03/cisco_aci_contracts-2.png "Web Server to Client connection")

The answer is yes (if stateful flag is not set), because contracts are simple ACLs.
Can we implement a stateful ACLs?

![Web Server to Client (reverse) connection](/images/posts/2018/03/cisco_aci_contracts-2.png "Web Server to Client connection")

Yes, setting the stateful flag in the filter.

Can an ICMP filter configured to match initiator and responser (stateful)? No, stateful flag is not available for non TCP protocols.
