---
title: "Shrinking VMware VMDK virtual hard disks"
date: "2012-05-10T09:00:00+01:00"
draft: false
---
In this post we'll see how to shrink a virtual (VMDK) disk before release the OVF/OVA image.

Developing a VM which will be distributed online, require to save space. After deleting cache, log files and so on, vmdk files won't became smaller.

Here how vmdk disks can be shrinked:

* (obviously) free all space you can;
* zero (set to zero) free blocks;
* manually shrink your vmdk disk.

Under Linux free block can be set to zero creating the biggest zeroed file disk can fit:

~~~
# dd if=/dev/zero of=zeroedfile
# rm -f zeroedfile
~~~

This procedure will securely delete all previously deleted file. In other words all deleted files became irrecoverable.

Under Windows [Secure Delete under Microsoft Windows](http://technet.microsoft.com/en-us/sysinternals/bb897443 "Secure Delete under Microsoft Windows") from Microsoft can be used, and it securely delete all previously deleted files:

~~~
C:>sdelete -c C:
~~~

Now vmdk disks became larger. They can be shrinked using vmware-vdiskmanager.exe from [VMware vSphere 5.0 Virtual Disk Development Kit](https://my.vmware.com/group/vmware/details?downloadGroup=VDDK50&productId=229 "VMware vSphere 5.0 Virtual Disk Development Kit"):

~~~
C:>vmware-vdiskmanager.exe -k "c:UsersadaineseVirtual Machinesvmvm.vmdk"
~~~

Now vmdk should be smaller.
