---
title: "Moving a disconnected VM from an unmanageable VMware ESXi host"
date: "2013-05-15T09:00:00+01:00"
draft: false
---
In this example management agents on a ESXi are not working anymore. VMs are up and running but they appear as disconnected. Suppose that sfcbd (the ESXi web server) is not working so, the ESXi host is completely unmanageable.

A VM need to be powered off and started on another working ESXi host.

Connect to the broken ESXi host using SSH and find the World ID of the VM:

~~~
# esxcli vms vm list
[...]
examplevm
    World ID: 73506118
    Process ID: 0
    VMX Cartel ID: 73547074
    UUID: 42 1c fc 60 92 12 85 3c-ec 69 1f c7 06 e7 ec 92
    Display Name: examplevm
    Config File: /vmfs/volumes/3334a421-c1470e95/examplevm/examplevm.vmx
[...]
~~~

Power off the VM using a soft (OS shutdown) or a hard (Power Off) flag:

~~~
~ # esxcli vms vm kill --type soft --world-id 73506118
~ # esxcli vms vm list | grep -B1 73506118
~~~

The VM does not appear anymore as running.

Now, if ESXi has a working sfcbd/hostd the VM should be unregistered (supposed not working in this example, so skip this two steps):

~~~
~ # vim-cmd vmsvc/getallvms
~ # vim-cmd vmsvc/unregister <vmid>
~~~

On the working host the VM must be registered using the same vmx file:

~~~
~ # vim-cmd solo/registervm /vmfs/volumes/3334a421-c1470e95/examplevm/examplevm.vmx
3472
~~~

The printed ID will be used to power on the VM:

~~~
~ # vim-cmd vmsvc/power.on 3472 &
~~~

The background (&) char is needed because a question must be answered:

~~~
~ # vim-cmd vmsvc/message 3472
Virtual machine message 0:
msg.uuid.altered:This virtual machine might have been moved or copied.
In order to configure certain management and networking features, VMware ESX needs to know if this virtual machine was moved or copied.

If you don't know, answer "I copied it".

   0. Cancel (Cancel)
   1. I moved it (I moved it)
   2. I copied it (I copied it) [default]
~~~

The answer to the question 0 is 1 ("I moved it").

~~~
~ # vim-cmd vmsvc/message 3472 0 1
~~~

## References

* [esxcli vm Commands](http://pubs.vmware.com/vsphere-50/index.jsp?topic=%2Fcom.vmware.vcli.ref.doc_50%2Fesxcli_vm.html "esxcli vm Commands")
* [How to Power-Off / Shutdown Virtual Machine on VMware ESXi5](http://dailyvmtech.wordpress.com/2012/11/11/how-to-power-off-shutdown-virtual-machine-on-vmware-esxi5/ "How to Power-Off / Shutdown Virtual Machine on VMware ESXi5")
