---
title: "Pay for support system with PayPal integration"
date: "2015-09-18T09:00:00+01:00"
draft: false
---
For another project I leaded, I needed a support ticket system integrated with PayPal. Sometimes that is referred as Pay for Support System.

## Scenario

There are many open and closed software available as Ticketing System, but none of them was able to address the following scenario:

* a one time user request for help opening a ticket;
* a guy from support team evaluate the ticket and ask to the user for a fee via PayPal;
* the requesting user pay the fee;
* the guy from support receive the notification about the payment and can support the user;
* past fees can be refunded, or more fees can be requested.

The only solution I was able to find involves [FreshDesk](http://freshdesk.com/ "FreshDesk: Everything you need to Start supporting customers") (other services are supported), [PayPal](https://www.paypal.com/ "PayPal") (other services are supported), [ChargeDesk](https://chargedesk.com/ "ChargeDesk: Discover Remarkable Billing Support") (that's the only glue I found).  

## PayPal

Let's start from [PayPal](https://www.paypal.com/ "PayPal"). It's the most famous payment platform, mostly used on [eBay](https://www.ebay.com/ "eBay"), but it's available as payment method on many eShop too. Even if [PayPal](https://www.paypal.com/ "PayPal") takes high fees for the services, it's still the preferred solution, because of popularity.

## FreshDesk

[FreshDesk](http://freshdesk.com/ "FreshDesk: Everything you need to Start supporting customers") is a customer supported platform provided as a PAAS (Platform As A Service) solution. There is a [SPROUT](http://freshdesk.com/pricing "SPROUT Licensing") license that allows up to three agents for free.

The product is very simple and self-explanatory:

![FreshDesk Dashboard](/images/posts/2015/09/chargedesk-1.png "FreshDesk Dashboard")

A dedicated URL is provided, users can customized the platform, and ticket can be opened from different channel, included email and web portal.

## ChargeDesk

[ChargeDesk](https://chargedesk.com/ "ChargeDesk: Discover Remarkable Billing Support") is the glue between [PayPal](https://www.paypal.com/ "PayPal") and [FreshDesk](http://freshdesk.com/ "FreshDesk: Everything you need to Start supporting customers"). The idea is very simple: a [browser extension](https://chrome.google.com/webstore/detail/chargedesk-for-stripe-pay/mkjdcoeddifgnbbafjppfcabiggcfhmo "ChargeDesk for Stripe, PayPal & Braintree") integrate a payment gateway ([PayPal](https://www.paypal.com/ "PayPal")) inside the the ticket platform ([FreshDesk](http://freshdesk.com/ "FreshDesk: Everything you need to Start supporting customers")).

[ChargeDesk](https://chargedesk.com/ "ChargeDesk: Discover Remarkable Billing Support") bills 3c per imported charge, Each month first 50 charges are free.

### How to make it working

1. Create a [ChargeDesk](https://chargedesk.com/ "ChargeDesk: Discover Remarkable Billing Support") account and configure payment gateway and platform under `Setup`:
 ![ChargeDesk Setup](/images/posts/2015/09/chargedesk-2.png "ChargeDesk Setup")
2. Be sure the [Chrome extension](https://chrome.google.com/webstore/detail/chargedesk-for-stripe-pay/mkjdcoeddifgnbbafjppfcabiggcfhmo "ChargeDesk for Stripe, PayPal & Braintree") has been installed and configured. Open any website and login to ChargeDesk by clicking on the ChargeDesk extesion icon:
 ![ChargeDesk Chrome extension](/images/posts/2015/09/chargedesk-3.png "ChargeDesk Chrome extension")
3. Open the [FreshDesk](http://freshdesk.com/ "FreshDesk: Everything you need to Start supporting customers") website, and a new menu will be available on the right:
 ![ChargeDesk within Freshdesk](/images/posts/2015/09/chargedesk-4.png "ChargeDesk within Freshdesk")

That's all! From the [ChargeDesk](https://chargedesk.com/ "ChargeDesk: Discover Remarkable Billing Support") menu added to any webpage from the [Chrome extension](https://chrome.google.com/webstore/detail/chargedesk-for-stripe-pay/mkjdcoeddifgnbbafjppfcabiggcfhmo "ChargeDesk for Stripe, PayPal & Braintree"), [PayPal](https://www.paypal.com/ "PayPal") within our [FreshDesk](http://freshdesk.com/ "FreshDesk: Everything you need to Start supporting customers") instance!

## References

* [ChargeDesk](https://chargedesk.com/ "ChargeDesk: Discover Remarkable Billing Support")
* [ChargeDesk for Freshdesk](https://chargedesk.com/integrate/paypal-payments/freshdesk "ChargeDesk for Freshdesk")
* [ChargeDesk API Documentation](https://chargedesk.com/api-docs "ChargeDesk API Documentation")
* [ChargeDesk pricing](https://chargedesk.com/pricing "ChargeDesk pricing")
* [FreshDesk](http://freshdesk.com/ "FreshDesk: Everything you need to Start supporting customers")
* [PayPal](https://www.paypal.com/ "PayPal")
