---
title: "Automatic webserver deploy based on requests"
date: "2017-03-02T09:00:00+01:00"
draft: false
---
Usually companies deploy few number of webservers to serve an estimated number of users. What about if we can increment or reduce the number of webservers based on real active users?

Suppose a simple php script like the following:

~~~
<?php
	sleep(1);
?>
~~~

The above script can simulate a http request which requires some elaborations in the background.

Suppose we have a single webserver, it can serves up to 200 concurrent users. If more users will try to access the same webserver, some of them will get errors:

![Errors by request rate](/images/posts/2017/03/dynamiclb-1.png "Errors by request rate")

The above requests show the number of replies/errors while a single webserver is serving 10000 requests using different rate (requests per second).

Now suppose we deploy a NGINX load balancer behind two webservers and let's automate the deploy:

* deploy an additional webserver if `CURRENT_REQUEST > TOTAL_WEBSERVERS * 120` (in an ideal world threshold will be 200, but the deploy phase will take a few);
* remove a webserver if `CURRENT_REQUEST < TOTAL_WEBSERVERS * 120`, but:
	* the minimum number of configured webservers must be 2;
	* wait at least 15 seconds from last webserver deploy/undeploy.

![Webservers by request rate](/images/posts/2017/03/dynamiclb-2.png "Webservers by request rate")

As you can show from the above graph, the number of deployed webservers automatic floats between 2 and 6.

## A quick and dirty solution

This is a very quick and dirty solution, only for demonstration purpose. Please check my [GitHub repository](https://github.com/dainok/rrlabs/tree/master/docker/dynamiclb "GitHub repository") for required files.

Deploy two webservers:

~~~
# docker build -t rrlabs/webserver:latest -f webserver.dockerfile .
# docker run -d --name webserver1 rrlabs/webserver
# docker run -d --name webserver2 rrlabs/webserver
~~~

Deploy the load balancer based on NGINX:

~~~
docker build -t rrlabs/loadbalancer:latest -f loadbalancer.dockerfile .
WEB1=$(docker inspect -f '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' webserver1)
WEB2=$(docker inspect -f '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' webserver2)
docker run -d -e IP="${WEB1} ${WEB2}" --name loadbalancer rrlabs/loadbalancer
~~~

Use `auto.sh` and `tester.sh loadbalancer` to start the automation script and test what happens while lot of requests are generated.

## References

* [My GitHub repository](https://github.com/dainok/rrlabs/tree/master/docker/dynamiclb "My GitHub repository")
