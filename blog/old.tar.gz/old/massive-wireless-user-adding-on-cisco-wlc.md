---
title: "Massive wireless user adding on Cisco WLC using Linux BASH"
date: "2014-01-23T09:00:00+01:00"
draft: false
---
Just an easy script to massive add guest user on a Cisco WLC using Linux BASH:

~~~
while read line; do
	LIFETIME=86400
	USER=$(echo $line | sed 's/[^ a-zA-Z0-9]//g' | tr 'A-Z' 'a-z' | sed 's/\(^[a-z]\).* /\1/g')
	PASS=$(cat /dev/urandom | tr -dc "A-Za-z0-9" | head -c 10)
	echo "config netuser add $USER $PASS wlan 6 userType guest lifetime $LIFETIME description \"$line\""
done < user_db
~~~

Few notes:

* user_db contains all users in the form (only A-Z and a-z chars are used):

~~~
John Doe
Jane Roe
~~~

* lifetime is 1 day;
* user takes the first char from First Name and the Last Name:

~~~
jdoe
jroe
~~~

* password is an alphanumeric strings 10 chars long;

It should be easy for everyone integrate this script where properly needed.
