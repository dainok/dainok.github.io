---
title: "Cisco Wireless Controller with a Proxy Server"
date: "2013-03-26T09:00:00+01:00"
draft: false
---
The configuration of a Wireless LAN using an auto discovered Proxy Server can be tricky, because not all options are available from the Web Configuration. The following environment will be explained:

![WLC/Proxy Topology](/images/posts/2013/03/wlc_proxy_topology1.png "WLC/Proxy Topology")

WiFi Client is a generic wireless client configured with DHCP and Proxy Auto Configuration enabled. An internal company server acts as a DHCP/DNS/Web/Proxy server. Web Server use TCP Port 80 and Proxy Server use TCP Port 8080.

The desired behavior is:

* The client connects to the WLAN and acquires IP Address, DNS Server and "example.com" domain from the internal server.
* The client will look for "http://wpad.example.com/wpad.dat" and download it from the internal server. A Preauthentication ACL will allow unauthenticated client to get it. The PAC file instructs the client that a proxy server exists and must be used using the TCP port 8080.
* The user can now open a browser and ask for Google website using a Proxy Server.
* The WLC intercept the request and redirects the user to the Web Authentication page (usually https://1.1.1.1/login.html?redirect=www.google.com).
* After the authentication the client can reach the server using the TCP Port 8080 and access to the Google website.
* Users without Proxy Auto Configuration should receive a warning page asking to configure the browser in a proper way.

## Web Proxy Autodiscovery Protocol

The Web Proxy Auto-Discovery Protocol (WPAD) is a method to instruct clients that a Web Proxy exists and how it should be used. Two method are available to discover a proxy: DHCP (trough option 252) and DNS. The DNS method requires clients get http://wpad.example.com/wpad.dat file, where "example.com" is the domain name of the client (usually assigned trough DHCP), and wpad.dat contains the rules to find and use the proxy server (it's a JavaScript file). The Proxy auto-config (PAC) file is wpad.dat, discovered by browser through Web Proxy Auto-Discovery (WPAD) method.

The scenario requires that clients must use Web Proxy for all traffic but WLC Web Auth Page. The following PAC (wpad.dat) file will be used:

~~~
function FindProxyForURL(url, host) {
	if (shExpMatch(host, "1.1.1.1")) {
		return "DIRECT";
	}
	return "PROXY proxy.example.com:8080";
}
~~~

The PAC file can be tested using [pacparser](https://code.google.com/p/pacparser/ "pacparser"):

~~~
$ pactester -p wpad.dat -u http://1.1.1.1/
DIRECT
$ pactester -p wpad.dat -u http://www.google.com/
PROXY proxy.example.com:8080
~~~

## Standard WLC configuration (without Preauthentication ACL)

A basic WLC setup has no Preauthentication ACL and Web Authentication Portall will listen to TCP Port 80 only. Under this situation:

* The client connects to the WLAN and acquires IP Address, DNS Server and "example.com" domain from the internal server.
* The client will look for "http://wpad.example.com/wpad.dat" but request is denied because no Preauthentication ACL is configured.
* The user can now open a browser and ask for Google website (no proxy server is used).
* The WLC intercept the request and redirects the user to the Web Authentication page (usually https://1.1.1.1/login.html?redirect=www.google.com).
* After the authentication the user can't reach the Google page because no proxy server is used.

## Standard WLC configuration (with Preauthentication ACL)

Because Internet Explorer looks for wpad.dat once, a Preauthentication ACL is needed. This ACL will allow traffic only from clients to the internal server using TCP Port 80 only. The Web Proxy service is active on TCP Port 8080 only. Under this situation:

* The client connects to the WLAN and acquires IP Address, DNS Server and "example.com" domain from the internal server.
* The client will look for "http://wpad.example.com/wpad.dat" and download it from the internal server. A Preauthentication ACL will allow unauthenticated client to get it. The PAC file instructs the client that a proxy server exists and must be used using the TCP port 8080.
* The user can now open a browser and ask for Google website using the Proxy Server.
* The WLC cannot intercept the request because the client is using TCP Port 8080 and not TCP Port 80, and user cannot get the Web Auth Page.

## Proposed solution: WLC configuration listening to the TCP Port 8080 (with Preauthentication ACL)

By default WLC intercept HTTP requests with Destination TCP Port 80 only. The solution requires that WLC intercepts HTTP requests with Destination TCP Port 8080. The following command must be configured through CLI:

~~~
config network web-auth port 8080
~~~

Under this situation:

* The client connects to the WLAN and acquires IP Address, DNS Server and "example.com" domain from the internal server.
* The client will look for "http://wpad.example.com/wpad.dat" and download it from the internal server. A Preauthentication ACL will allow unauthenticated client to get it. The PAC file instructs the client that a proxy server exists and must be used using the TCP port 8080.
* The user can now open a browser and ask for Google website using the Proxy Server.
* The WLC intercept the request and redirects the user to the Web Authentication page (usually https://1.1.1.1/login.html?redirect=www.google.com).
* After the authentication the client can reach the server using the TCP Port 8080 and access to the Google website using the Proxy Server.

Users without Proxy Auto Configuration will access Google website without using the Proxy Server. WLC still intercept requests and users can login, but Google website is not reachable without proxy.
The "WebAuth Proxy Redirection Mode" feature can help user using a different and static TCP Proxy Port other than 80/8080. Unfortunately this feature can't be used to redirect direct Internet connection (using TCP port 80).

## References

* [Web Proxy Autodiscovery Protocol](http://en.wikipedia.org/wiki/Web_Proxy_Autodiscovery_Protocol "Web Proxy Autodiscovery Protocol")

* [Example PAC File](http://findproxyforurl.com/example-pac-file/ "Example PAC File")
* [pacparser](https://code.google.com/p/pacparser/ "pacparser")
* [Web Authentication Proxy on a Wireless LAN Controller Configuration Example](http://www.cisco.com/en/US/products/ps10315/products_configuration_example09186a0080b8a909.shtml "Web Authentication Proxy on a Wireless LAN Controller Configuration Example")
