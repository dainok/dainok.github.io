---
title: "A programmable per-port PVLAN using SDN on Cisco XNC/OpenDaylight and Floodlight"
date: "2013-11-12T09:00:00+01:00"
draft: false
---
This post will show how to implement a simple per-port PVLAN / "switchport protected" within an SDN controller. H1 will be able to communicate with both H2 and H3, but H2 won't be able to communicate with H3.

![single](/images/posts/2013/11/single.png "single")

So port facing H1, H2 and H3 will be configured as follow:

* H1 will be connected to a promiscous port
* H2 and H3 will be connected to isolated ports.


## Programming a per-port PVLAN using MiniNet

MiniNet is the test platform for SDN applications, but can be also used as a simple controller.
Let's start the MiniNet lab with the above topology:

~~~
sudo mn --topo=single,3
~~~

Then three flows must be configured:

~~~
mininet> dpctl add-flow in_port=1,actions=output:2,output:3
mininet> dpctl add-flow in_port=2,actions=output:1
mininet> dpctl add-flow in_port=3,actions=output:1
mininet> dpctl dump-flows
*** s1 ------------------------------------------------------------------------
NXST_FLOW reply (xid=0x4):
 cookie=0x0, duration=5.015s, table=0, n_packets=0, n_bytes=0, idle_age=5, in_port=3 actions=output:1
 cookie=0x0, duration=5.026s, table=0, n_packets=0, n_bytes=0, idle_age=5, in_port=1 actions=output:2,output:3
 cookie=0x0, duration=5.021s, table=0, n_packets=0, n_bytes=0, idle_age=5, in_port=2 actions=output:1
~~~

Now H1 can ping both H2 and H3 but H2 won't be able to reach H3:

~~~
mininet> pingall
*** Ping: testing ping reachability
h1 -> h2 h3
h2 -> h1 X
h3 -> h1 X
*** Results: 33% dropped (4/6 received)
~~~

Using this implementation, data from H1 will be flooded to both H2 and H3. So it's behave like an Ethernet hub rather than a switch.

## Programming a per-port PVLAN using Cisco XNC/OpenDaylight

Let's start the MiniNet lab connected to the Cisco XNC controller (or OpenDaylight) with the above topology:

~~~
sudo mn --controller=remote,ip=192.168.32.129 --topo=single,3
~~~

Let's go to Flows -> Add Flow Entry and create three flows with the following parameters:

* Name: flow1to23, Node: OF|00:00:00:00:00:00:00:01, Input Port: s1-eth1(1), Add Output Ports s1-eth2(2),s1-eth3(3)
* Name: flow2to1, Node: OF|00:00:00:00:00:00:00:01, Input Port: s1-eth2(2), Add Output Ports s1-eth1(1)
* Name: flow3to1, Node: OF|00:00:00:00:00:00:00:01, Input Port: s1-eth3(3), Add Output Ports s1-eth1(1)


By default Ethernet Type 0x800 (IP) is configured, the field must be cleared because we want all traffic flows between isolated and promiscous ports.

Now select each flow and install it to the switch.

And again H1 can ping both H2 and H3, but H2 cannot ping H3:

~~~
mininet> dpctl dump-flows
*** s1 ------------------------------------------------------------------------
NXST_FLOW reply (xid=0x4):
 cookie=0x0, duration=35.727s, table=0, n_packets=0, n_bytes=0, idle_age=35, priority=500,in_port=3 actions=output:1
 cookie=0x0, duration=34.286s, table=0, n_packets=0, n_bytes=0, idle_age=34, priority=500,in_port=1 actions=output:2,output:3
 cookie=0x0, duration=37.46s, table=0, n_packets=0, n_bytes=0, idle_age=37, priority=500,in_port=2 actions=output:1
mininet> pingall
*** Ping: testing ping reachability
h1 -> h2 h3
h2 -> h1 X
h3 -> h1 X
*** Results: 33% dropped (4/6 received)
~~~

## Programming a switch using Flowlight

Let's start the MiniNet lab connected to the Floodlight controller with the above topology:

~~~
sudo mn --controller=remote,ip=192.168.32.129 --topo=single,3
~~~

Floodlight must be programmed via API/curl:

~~~
curl -d '{"switch":"00:00:00:00:00:00:00:01", "name":"flow-123", "ingress-port":"1", "actions":"output=2,output=3"}' http://127.0.0.1:8080/wm/staticflowentrypusher/json
curl -d '{"switch":"00:00:00:00:00:00:00:01", "name":"flow-21", "ingress-port":"2", "actions":"output=1"}' http://127.0.0.1:8080/wm/staticflowentrypusher/json
curl -d '{"switch":"00:00:00:00:00:00:00:01", "name":"flow-31", "ingress-port":"3", "actions":"output=1"}' http://127.0.0.1:8080/wm/staticflowentrypusher/json
~~~

And once again H1 can ping both H2 and H3, but H2 cannot ping H3:

~~~
mininet> dpctl dump-flows
*** s1 ------------------------------------------------------------------------
NXST_FLOW reply (xid=0x4):
 cookie=0xffffffffdbbe7842, duration=18.047s, table=0, n_packets=0, n_bytes=0, idle_age=18, priority=32767,in_port=3 actions=output:1
 cookie=0xa000001dfbc39a, duration=19.901s, table=0, n_packets=0, n_bytes=0, idle_age=19, priority=32767,in_port=1 actions=output:2,output:3
 cookie=0xffffffffdbbe776f, duration=19.886s, table=0, n_packets=0, n_bytes=0, idle_age=19, priority=32767,in_port=2 actions=output:1
mininet> pingall
*** Ping: testing ping reachability
h1 -> h2 h3
h2 -> h1 X
h3 -> h1 X
*** Results: 33% dropped (4/6 received)
~~~

## References

* [MiniNet as an SDN test platform](http://www.routereflector.com/en/2013/11/mininet-as-an-sdn-test-platform/ "MiniNet as an SDN test platform")
* [OpenDaylight as an SDN controller: overview and installation](http://www.routereflector.com/en/2013/11/opendaylight-as-an-sdn-controller-overview-and-installation/ "OpenDaylight as an SDN controller: overview and installation")
* [Cisco Extensible Network Controller (XNC): overview and installation](http://www.routereflector.com/en/2013/10/cisco-extensible-network-controller-xnc-overview-and-installation/ "Cisco Extensible Network Controller (XNC): overview and installation")
* [Floodlight SDN controller: overview and installation](http://www.routereflector.com/en/2013/11/floodlight-sdn-controller-overview-and-installation/ "Floodlight SDN controller: overview and installation")
