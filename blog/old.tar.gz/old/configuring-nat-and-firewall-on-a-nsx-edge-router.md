---
title: "Configuring NAT and firewall on a NSX Edge Router"
date: "2015-01-19T09:00:00+01:00"
draft: false
---
In this post we'll see how to configure NAT and firewall policies on a NSX Edge Router.

## Introduction

On a [previous post]({% post_url 2015-01-15-connecting-edge-router-to-physical-lan-using-vmware-nsx %}) the edge router has been connected to external network:

![NSX OSPF Topology](/images/posts/2015/01/nsx_ospf-2.png "NSX OSPF Topology")

In this post NAT and Firewall will be configured to allow SSH access to VM1 from external networks.

Go to "Networking & Security -> NSX Edges", double click on the edge router and follow "Manage -> NAT". Add a DNAT role so the VM1's IP address (172.31.31.11 port 22) can be reached using the Edge router gateway address (172.31.30.21 port 2220):

![Edit DNAT rule](/images/posts/2015/01/nsx_nat-1.png "Edit DNAT rule")

Publish changes and go to the "Firewall" tab. Add a role to allow traffic from "any" to 2220 port:

![Manage Firewall](/images/posts/2015/01/nsx_nat-2.png "Manage Firewall")

The rule is pretty "large" but it's out of scope.

Now a SSH to the IP address of the edge router using port 2220 will connect to one of the internal VMs.

Internal VMs must be able to connect to external networks using the edge public IP address. So go back to the "NAT" tab and add a new rule:

![Edit SNAT rule](/images/posts/2015/01/nsx_nat-3.png "Edit SNAT rule")

Now connect to the internal VM from an external network, and ping back an external IP address:

~~~
client$ ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -p 2220 ubuntu@172.31.30.21
ubuntu@172.31.30.21's password:
ubuntu@ubuntu1:~$ ping -c3 172.31.30.1
PING 172.31.30.1 (172.31.30.1) 56(84) bytes of data.
64 bytes from 172.31.30.1: icmp_seq=1 ttl=62 time=0.601 ms
64 bytes from 172.31.30.1: icmp_seq=2 ttl=62 time=0.670 ms
64 bytes from 172.31.30.1: icmp_seq=3 ttl=62 time=0.642 ms

--- 172.31.30.1 ping statistics ---
3 packets transmitted, 3 received, 0% packet loss, time 2005ms
rtt min/avg/max/mdev = 0.601/0.637/0.670/0.040 ms
~~~
