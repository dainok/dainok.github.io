---
title: "Monitoring Cisco WAAS using Nagios"
date: "2014-01-27T09:00:00+01:00"
draft: false
---
In this post we'll see how to monitor a Cisco WAAS using Nagios and SNMP. There are a lot of SNMP information available, but we want to check: alert and warning messages and active connections (must be lower than licensed ones).

## Cisco WAAS OIDs

The [official manual](http://www.cisco.com/en/US/docs/app_ntwk_services/waas/waas/v441/configuration/guide/SNMP.html#wp1119310 "Cisco Wide Area Application Services Configuration Guide (Software Version 4.4.1)") shows which are the OID we need:

* Messages:
    * [cceAlarmCriticalCount](http://tools.cisco.com/Support/SNMP/do/BrowseOID.do?objectInput=cceAlarmCriticalCount&translate=Translate&submitValue=SUBMIT&submitClicked=true "cceAlarmCriticalCount") (1.3.6.1.4.1.9.9.178.1.6.2.1): The value of this object specifies the number of alarms currently raised with a severity of "critical".
    * [cceAlarmMajorCount](http://tools.cisco.com/Support/SNMP/do/BrowseOID.do?objectInput=cceAlarmCriticalCount&translate=Translate&submitValue=SUBMIT&submitClicked=true "cceAlarmMajorCount") (1.3.6.1.4.1.9.9.178.1.6.2.2): The value of this object specifies the number of alarms currently raised with a severity of "major".
    * [cceAlarmMinorCount](http://tools.cisco.com/Support/SNMP/do/BrowseOID.do?objectInput=cceAlarmMinorCount&translate=Translate&submitValue=SUBMIT&submitClicked=true "cceAlarmMajorCount") (1.3.6.1.4.1.9.9.178.1.6.2.3): The value of this object specifies the number of alarms currently raised with a severity of "minor".
* Connections
    * [cwoTfoStatsMaxActiveConn](http://tools.cisco.com/Support/SNMP/do/BrowseOID.do?objectInput=cwoTfoStatsMaxActiveConn&translate=Translate&submitValue=SUBMIT&submitClicked=true "cwoTfoStatsMaxActiveConn") (1.3.6.1.4.1.9.9.762.1.2.1.3): This object contains maximum number of active TCP connections that this device can optimize.
	* [cwoTfoStatsActiveOptConn](http://tools.cisco.com/Support/SNMP/do/BrowseOID.do?objectInput=cwoTfoStatsActiveOptConn&translate=Translate&submitValue=SUBMIT&submitClicked=true "cwoTfoStatsActiveOptConn") (1.3.6.1.4.1.9.9.762.1.2.1.2): This object contains number of currently active TCP connections getting optimized.
	* [cwoTfoStatsActivePTConn](http://tools.cisco.com/Support/SNMP/do/BrowseOID.do?objectInput=cwoTfoStatsActivePTConn&translate=Translate&submitValue=SUBMIT&submitClicked=true "cwoTfoStatsActivePTConn") (1.3.6.1.4.1.9.9.762.1.2.1.10): This object contains number of active Pass Through TCP connections. Connections which are not selected for optimization are called Pass Through.

We check connection values first. Active, Maximum and Pass-Through connections are fetched using snmpgetnext:

~~~
OUTPUT=$(snmpgetnext -m /dev/null -c $COMMUNITY -v $VERSION $HOST $cwoTfoStatsMaxActiveConn $cwoTfoStatsActiveOptConn $cwoTfoStatsActivePTConn)
~~~

Then output is parsed:

~~~
MAX=$(echo $OUTPUT | sed 's/.*: \([0-9]*\) .*: \([0-9]*\) .*: \([0-9]*\)/\1/')
OPT=$(echo $OUTPUT | sed 's/.*: \([0-9]*\) .*: \([0-9]*\) .*: \([0-9]*\)/\2/')
PT=$(echo $OUTPUT | sed 's/.*: \([0-9]*\) .*: \([0-9]*\) .*: \([0-9]*\)/\3/')
~~~

And finally the right status is raised:

~~~
CURRENT_PERC=$(echo "100*($OPT)/$MAX" | bc)
WARNING=$(echo "$MAX*0.$WARNING_PERC" | bc)
CRITICAL=$(echo "$MAX*0.$CRITICAL_PERC" | bc)

if [ "$CURRENT_PERC" -ge "$CRITICAL_PERC" ]; then
    STATUS="CRITICAL"
    RC=2
elif [ "$CURRENT_PERC" -ge "$WARNING_PERC" ]; then
    STATUS="WARNING"
    RC=1
elif [ "$CURRENT_PERC" -ge 0 ]; then
    STATUS="OK"
    RC=0
else
    STATUS="UNKNOWN"
    RC=3
fi
~~~

On the second step Critical, Major and Minor alerts are fetched:

~~~
vOUTPUT=$(snmpgetnext -m /dev/null -c $COMMUNITY -v $VERSION $HOST $cceAlarmCriticalCount $cceAlarmMajorCount $cceAlarmMinorCount)
~~~

Then output is parsed:

~~~
MSG_CRITICAL=$(echo $OUTPUT | sed 's/.*: \([0-9]*\) .*: \([0-9]*\) .*: \([0-9]*\)/\1/')
MSG_MAJOR=$(echo $OUTPUT | sed 's/.*: \([0-9]*\) .*: \([0-9]*\) .*: \([0-9]*\)/\2/')
MSG_MINOR=$(echo $OUTPUT | sed 's/.*: \([0-9]*\) .*: \([0-9]*\) .*: \([0-9]*\)/\3/')
~~~

And the right status is raised, according to the previous one:

~~~
if [ "$MSG_CRITICAL" -gt 0 ] && [ "$RC" -le 3 ]; then
    STATUS="CRITICAL"
    RC=2
elif [ "$MSG_MAJOR" -gt 0 ] && [ "$RC" -le 2 ]; then
    STATUS="WARNING"
    RC=2
fi
~~~

The last line of the script prints a messages and performance data:

~~~
echo -n "$STATUS (Msg $MSG_CRITICAL/$MSG_MAJOR/$MSG_MINOR) * Connections $OPT/$MAX (PT=$PT) | conn=$OPT;$WARNING;$CRITICAL;0;$MAX"
exit $RC
~~~

Performance data must be in the following form: varname=value;warn;crit;min;max

## Configuring check_waas within Nagios

Nagios users should be able to integrate check_waas in a Nagios environment. A command template should be defined:

~~~
define command {
    #$ARG1$: SNMP Version
    #$ARG2$: SNMP Community
    #$ARG3$: Warning Limit (connections)
    #$ARG4$: Critical Limit (connections)
    command_name    check-waas
    command_line    $USER1$/check_waas -H $HOSTADDRESS$ -v $ARG1$ -C $ARG2$ -w $ARG3$ -c $ARG4$
}
~~~

Then a service must be added to a host:

~~~
define service {
    use                 generic-service
    host_name           wave.example.com
    service_description WAAS status
    check_command       check-waas!2c!public!75!90
    servicegroups       waas-status
}
~~~

Other configurations are missing, please refers to the Nagios manuals.

## References

* [The complete check_waas script for Nagios](https://github.com/dainok/rrlabs/blob/master/scripts/check_waas.sh "The complete check_waas script for Nagios")
