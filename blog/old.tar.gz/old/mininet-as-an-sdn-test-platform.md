---
title: "MiniNet as an SDN test platform"
date: "2013-11-06T09:00:00+01:00"
draft: false
---
MiniNet is

> a realistic virtual network, running real kernel, switch and application code, on a single machine in seconds, with a single command.

In other words MiniNet is an OpenFlow testing platform. MiniNet can be used with OpenDaylight project, Cisco XNC Controller and Floodlight (maybe more are available).

## Installation and configuration

Download the latest MiniNet OVF Release from the [MiniNet Download](https://bitbucket.org/mininet/mininet-vm-images/downloads "MiniNet Download").
Unpack the zip file, and import the OVF using, for example, VMware Player ot Workstation.

A X server should be used to export applications from MiniNet VM. Windows users should consider [XMing](http://sourceforge.net/projects/xming/ "XMing").
Be sure to Enable X11 Forwarding from PuTTY configuration.
Login to the MiniNet VM using PuTTY, and launch xterm. If Xming and PuTTY are correctly configured, a xterm window will appear to the Windows desktop:

## Using MiniNet

MiniNet VM default user is "mininet", with password "mininet". Login as mininet and start the MiniNet CLI:

~~~
sudo mn
*** Creating network
*** Adding controller
*** Adding hosts:
h1 h2
*** Adding switches:
s1
*** Adding links:
(h1, s1) (h2, s1)
*** Configuring hosts
h1 h2
*** Starting controller
*** Starting 1 switches
s1
*** Starting CLI:
mininet>
~~~

If no parameters are specified, by default will be created two hosts (h1 and h2), connected by one switch (s1).

~~~
mininet> nodes
available nodes are:
c0 h1 h2 s1
mininet> net
h1 h1-eth0:s1-eth1
h2 h2-eth0:s1-eth2
s1 lo:  s1-eth1:h1-eth0 s1-eth2:h2-eth0
c0
mininet> dump
<Host h1: h1-eth0:10.0.0.1 pid=8683>
<Host h2: h2-eth0:10.0.0.2 pid=8684>
<OVSSwitch s1: lo:127.0.0.1,s1-eth1:None,s1-eth2:None pid=8687>
<OVSController c0: 127.0.0.1:6633 pid=8675>
~~~

The above commands will give an overview of MiniNet current topology.
Nodes console are avaible using xterm:

~~~
mininet> xterm h1 h2 s1
~~~

By default a 10.0.0.0/8 network is used, host nodes are automatically configured:

~~~
mininet> pingall
*** Ping: testing ping reachability
h1 -> h2
h2 -> h1
*** Results: 0% dropped (2/2 received)
~~~

Ping is successful, but if h1-s1 link goes down, then ping fails:

~~~
mininet> link h1 s1 down
mininet> h1 ping -c 1 h2
connect: Network is unreachable
~~~

## Default MiniNet topologies

MiniNet can easily creates more complex topologies. Few template are available by default: minimal, single, reversed, linear and tree.

### Minimal

It's a simple topology with one switch and two host:

![minimal](/images/posts/2013/11/minimal.png "minimal")

~~~
sudo mn --topo minimal
mininet> net
h1 h1-eth0:s1-eth1
h2 h2-eth0:s1-eth2
s1 lo:  s1-eth1:h1-eth0 s1-eth2:h2-eth0
~~~

### Single

It's a simple topology with one switch and N hosts:
![single](/images/posts/2013/11/single.png "single")

~~~
sudo mn --topo single,3
mininet> net
h1 h1-eth0:s1-eth1
h2 h2-eth0:s1-eth2
h3 h3-eth0:s1-eth3
s1 lo:  s1-eth1:h1-eth0 s1-eth2:h2-eth0 s1-eth3:h3-eth0
~~~

### Reversed

Like Single, but connection order is reversed:
![reversed](/images/posts/2013/11/reversed.png "reversed")

~~~
sudo mn --topo reversed,3
mininet> net
h1 h1-eth0:s1-eth3
h2 h2-eth0:s1-eth2
h3 h3-eth0:s1-eth1
s1 lo:  s1-eth1:h3-eth0 s1-eth2:h2-eth0 s1-eth3:h1-eth0
~~~

### Linear
A serial connection with N switches and N hosts:
![linear](/images/posts/2013/11/linear.png "linear")

~~~
sudo mn --topo linear,3
mininet> net
h1 h1-eth0:s1-eth1
h2 h2-eth0:s2-eth1
h3 h3-eth0:s3-eth1
s1 lo:  s1-eth1:h1-eth0 s1-eth2:s2-eth2
s2 lo:  s2-eth1:h2-eth0 s2-eth2:s1-eth2 s2-eth3:s3-eth2
s3 lo:  s3-eth1:h3-eth0 s3-eth2:s2-eth3
~~~

### Tree

A multiple level topology with N levels and two hosts per switch:

>![tree](/images/posts/2013/11/tree.png "tree")

~~~
sudo mn --topo tree,3
mininet> net
h1 h1-eth0:s3-eth1
h2 h2-eth0:s3-eth2
h3 h3-eth0:s4-eth1
h4 h4-eth0:s4-eth2
h5 h5-eth0:s6-eth1
h6 h6-eth0:s6-eth2
h7 h7-eth0:s7-eth1
h8 h8-eth0:s7-eth2
s1 lo:  s1-eth1:s2-eth3 s1-eth2:s5-eth3
s2 lo:  s2-eth1:s3-eth3 s2-eth2:s4-eth3 s2-eth3:s1-eth1
s3 lo:  s3-eth1:h1-eth0 s3-eth2:h2-eth0 s3-eth3:s2-eth1
s4 lo:  s4-eth1:h3-eth0 s4-eth2:h4-eth0 s4-eth3:s2-eth2
s5 lo:  s5-eth1:s6-eth3 s5-eth2:s7-eth3 s5-eth3:s1-eth2
s6 lo:  s6-eth1:h5-eth0 s6-eth2:h6-eth0 s6-eth3:s5-eth1
s7 lo:  s7-eth1:h7-eth0 s7-eth2:h8-eth0 s7-eth3:s5-eth2
~~~

## Custom MiniNet topology

Additional topologies can be created with extenral scripts. The following example will create a two network separated by a router:

![custom](/images/posts/2013/11/custom.png "custom")

The following Python file implement the above topology:

~~~
from mininet.topo import Topo

class Router_Topo(Topo):
    def __init__(self):
        "Create P2P topology."

        # Initialize topology
        Topo.__init__(self)

        # Add hosts and switches
        H1 = self.addHost('h1')
        H2 = self.addHost('h2')
        H3 = self.addHost('h3')
        S1 = self.addSwitch('s1')
        S2 = self.addSwitch('s2')

        # Add links
        self.addLink(H1, S1)
        self.addLink(H2, S1)
        self.addLink(H2, S2)
        self.addLink(H3, S2)

topos = {
        'router': (lambda: Router_Topo())
}
~~~

~~~
sudo mn --custom /home/mininet/Router.py --topo router
mininet> net
h1 h1-eth0:s1-eth1
h2 h2-eth0:s1-eth2 h2-eth1:s2-eth1
h3 h3-eth0:s2-eth2
s1 lo: s1-eth1:h1-eth0 s1-eth2:h2-eth0
s2 lo: s2-eth1:h2-eth1 s2-eth2:h3-eth0
~~~

Let's how to configure all nodes for routing:

~~~
mininet> h1 ifconfig h1-eth0 192.168.12.1 netmask 255.255.255.0
mininet> h2 ifconfig h2-eth0 192.168.12.2 netmask 255.255.255.0
mininet> h2 ifconfig h2-eth1 192.168.23.2 netmask 255.255.255.0
mininet> h3 ifconfig h3-eth0 192.168.23.3 netmask 255.255.255.0
mininet> h1 route add default gw 192.168.12.2
mininet> h3 route add default gw 192.168.23.2
mininet> h2 sysctl net.ipv4.ip_forward=1
~~~

And now ping should be routed correctly:

~~~
mininet> h1 ping -c 1 192.168.23.3
~~~

## Connecting MiniNet to a SDN controller

A MiniNet topology can be created and connected to a SDN controller like OpenDaylight, XNC or FloodLight (default port is 6633):

~~~
sudo mn --controller=remote,ip=192.168.32.129 --topo=tree,3
~~~

![mininet_on_sdn_controller](/images/posts/2013/11/mininet_on_sdn_controller.png "mininet_on_sdn_controller")

## References

* [Project Floodlight](http://www.projectfloodlight.org/ "Project Floodlight")
* [OepnDaylight Project](http://www.opendaylight.org/ "OepnDaylight Project")
* [Mininet Walkthrough](http://mininet.org/walkthrough/ "Mininet Walkthrough")
