---
title: "VMware Update Managet (VUM) fail after upgrade"
date: "2014-11-11T09:00:00+01:00"
draft: false
---
Sometimes after a vSphere upgrade Update Manager (VUM) can fail with the following error:

>  There was an error connecting VMware vSphere Update Manager - [vcenter.example.com:443].
> Database temporarily unavailable or has network problems.

The easiest way is to reconfigure the VUM using the `VMwareUpdateManagerUtility.exe` utility installed in the VMware Update Manager program path (usually `C:\Program Files (x86)\VMware\Infrastructure\Update Manager`):

![vum error](/images/posts/2014/11/vum-error.png "vum error")

Then restart the VMware vSphere Update Manager service.
