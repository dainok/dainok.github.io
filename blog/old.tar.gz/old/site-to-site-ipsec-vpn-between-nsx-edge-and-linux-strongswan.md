---
title: "Site to Site IPSEC VPN between NSX Edge and Linux strongSwan"
date: "2015-03-26T09:00:00+01:00"
draft: false
---
The following post will show how to configure a L3 VPN between VMware NSX Edge and a Linux box with strongSwan.

## L3 VPN with Pre-Shared Key (PSK) authentication

The first example will show a L3 VPN configured with a Pre-Shared Key. The NSX Edge configuration is pretty simple. Open the Web Client and go to "Networking & Security -> NSX Edges" and open the selected NSX Edge. Go then to the VPN tab and select IPSec VPN. Add a new VPN with the following parameters:

![VMware NSX: Edit IPSec VPN](/images/posts/2015/03/l3vpn-1.png "VMware NSX: Edit IPSec VPN")

* **Name:** nsx-linux-psk (a simple name for the VPN)
* **Local Id:** 172.31.30.30 (can be the NSX Edge IP address, hostname or just an ID)
* **Local Endpoint:** 172.31.30.30 (the NSX Edge outside IP address)
* **Local Subnets:** 10.0.253.0/24 (all NSX Edge local subnets defined for the VPN, separated by comma)
* **Peer Id:** 172.31.30.28 (can be the Linux Box IP address, hostname or just an ID)
* **Peer Endpoint:** 172.31.30.28 (the Linux Box outside IP address)
* **Peer Subnets:** 192.168.0.0/24 (all Linux box local subnets defined for the VPN, separated by comma)
* **Encryption Algorithm:** AES (can be AES, AES256, Triple DES, AES-GCM)
* **Authentication:** PSK
* **Pre-Shared Key:** VMware1!
* **Diffie-Hellman Group:** DH2
* **Enable perfect forward secrecy (PFS):** enabled

The local networks must be locally attached to the NSX Edge or statically defined (no dynamic protocols allowed on 6.0.2).

The Linux box (Ubuntu 14.04) is using strongSwan. Configuration file is `ipsec.conf`:

~~~
# /etc/ipsec.conf
config setup
    # strictcrlpolicy=yes
    # uniqueids = no
conn linux-nsx-psk
    authby=secret
    auto=start
    leftid=172.31.30.28
    left=172.31.30.28           # strongSwan ouside address
    leftsubnet=192.168.0.0/24   # networks behind strongSwan
    rightid=172.31.30.30
    right=172.31.30.30          # NSX Edge outside address
    rightsubnet=10.0.253.0/24   # networks behind NSX Edge
    ike=aes128-md5-modp1024     # Phase 1: AES, modp1024 = DH group 2
    ikelifetime=28800           #          SA lifetime of 28800 seconds
    keyexchange=ikev2           #          IKEv2, always use PFS
    esp=aes128-sha1-modp1024    # Phase 2: AES, SHA1, DH Group 2
    lifebytes=0                 #          no kbytes rekeying
    lifepackets=0               #          no packets rekeying
    lifetime=1h                 #          SA lifetime of 3600 seconds
~~~

PSKs are defined in `ipsec.secrets` file:

~~~
# /etc/ipsec.secrets
172.31.30.28 172.31.30.30 : PSK "VMware1!"
~~~

Finally be sure strongSwan service is running and enable the VPN:

~~~
service strongswan status
strongswan start/running
ipsec update
ipsec rereadsecrets
ipsec up nsxpsk
~~~


## L3 VPN with certificates authentication

First we need to create certificates. Let's start with three RSA keys:

~~~
openssl genrsa -out /etc/ssl/private/ca.key 2048
openssl genrsa -out /etc/ssl/private/172.31.30.28.key 2048
openssl genrsa -out /etc/ssl/private/172.31.30.30.key 2048
~~~

Add a small section to the openssl.cnf file:

~~~
# /etc/ssl/openssl.cnf
[ v3_ca ]
subjectKeyIdentifier=hash
authorityKeyIdentifier=keyid:always,issuer
basicConstraints = CA:true
keyUsage = cRLSign, keyCertSign
~~~

Then create the CA certificate:

~~~
# /etc/ssl/openssl.cnf
openssl req -new -x509 -sha256 -days 3650 -key /etc/ssl/private/ca.key -out /etc/ssl/certs/ca.crt -extensions v3_ca
~~~

Fill the form as following:

* **Country Name (2 letter code) [AU]:** IT
* **State or Province Name (full name) [Some-State]:** Italy
* **Locality Name (eg, city) []:** Padova
* **Organization Name (eg, company) [Internet Widgits Pty Ltd]:** RR Labs
* **Organizational Unit Name (eg, section) []:** Security
* **Common Name (e.g. server FQDN or YOUR name) []:** Andrea Dainese

Then create two CSR (Certificate Signing Request), one for each VPN peer:

~~~
openssl req -new -sha256 -key /etc/ssl/private/172.31.30.28.key -out /etc/ssl/certs/172.31.30.28.csr
~~~

Fill the form as following:

* **State or Province Name (full name) [Some-State]:** Italy
* **Locality Name (eg, city) []:** Padova
* **Organization Name (eg, company) [Internet Widgits Pty Ltd]:** RR Labs
* **Organizational Unit Name (eg, section) []:** Security
* **Country Name (2 letter code) [AU]:** IT
* **Common Name (e.g. server FQDN or YOUR name) []:** 172.31.30.28
* **Email Address []:** andrea.dainese@gmail.com

~~~
openssl req -new -sha256 -key /etc/ssl/private/172.31.30.30.key -out /etc/ssl/certs/172.31.30.30.csr
~~~

Fill the form as following:

* **State or Province Name (full name) [Some-State]:** Italy
* **Locality Name (eg, city) []:** Padova
* **Organization Name (eg, company) [Internet Widgits Pty Ltd]:** RR Labs
* **Organizational Unit Name (eg, section) []:** Security
* **Country Name (2 letter code) [AU]:** IT
* **Common Name (e.g. server FQDN or YOUR name) []:** 172.31.30.30
* **Email Address []:** andrea.dainese@gmail.com

And sign IPSec peer certificates using CA certificate:

~~~
openssl x509 -req -days 360 -in /etc/ssl/certs/172.31.30.28.csr -CA /etc/ssl/certs/ca.crt -CAkey /etc/ssl/private/ca.key -CAcreateserial -out /etc/ssl/certs/172.31.30.28.crt
openssl x509 -req -days 360 -in /etc/ssl/certs/172.31.30.30.csr -CA /etc/ssl/certs/ca.crt -CAkey /etc/ssl/private/ca.key -CAcreateserial -out /etc/ssl/certs/172.31.30.30.crt
~~~

Finally verify IPSec certificates with CA certificate:

~~~
openssl verify -CAfile /etc/ssl/certs/ca.crt /etc/ssl/certs/172.31.30.28.crt /etc/ssl/certs/172.31.30.30.crt
~~~

Now open a Web Client and go to "Networking & Security -> NSX Edges" and open the selected NSX Edge. Go then to the Settings tab and select Certificates. Add both CA and 172.31.30.30 certificate created above:

![VMware NSX: Add Certificate](/images/posts/2015/03/l3vpn-2.png "VMware NSX: Add Certificate")

Select now the VPN tab and configure global parameters. Enable certificate authentication and select 172.31.30.30 certificate. Select the CA certificate also, on the CA tab:

![VMware NSX: VPN Global Configuration](/images/posts/2015/03/l3vpn-3.png "VMware NSX: VPN Global Configuration")

Then add a new VPN:

![VMware NSX: Edit IPSec VPN](/images/posts/2015/03/l3vpn-4.png "VMware NSX: Edit IPSec VPN")

Fill the form as following:

* **Name:** nsx-linux-psk (a simple name for the VPN)
* **Local Id:** C=IT, ST=Italy, L=Padova, O=RR Labs, OU=Security, CN=172.31.30.30 (must be the DN of the NSX cert)
* **Local Endpoint:** 172.31.30.30 (the NSX Edge outside IP address)
* **Local Subnets:** 10.0.253.0/24 (all NSX Edge local subnets defined for the VPN, separated by comma)
* **Peer Id:** C=IT, ST=Italy, L=Padova, O=RR Labs, OU=Security, CN=172.31.30.28 (must be the DN of the NSX cert)
* **Peer Endpoint:** 172.31.30.28 (the Linux Box outside IP address)
* **Peer Subnets:** 192.168.0.0/24 (all Linux box local subnets defined for the VPN, separated by comma)
* **Encryption Algorithm:** AES (can be AES, AES256, Triple DES, AES-GCM)
* **Authentication:** Certificate
* **Diffie-Hellman Group:** DH2
* **Enable perfect forward secrecy (PFS):** enabled

The local networks must be locally attached to the NSX Edge or statically defined (no dynamic protocols allowed on 6.0.2).

The Linux box (Ubuntu 14.04) is using strongSwan. The first step is convert certificates from PEM format to DER:

~~~
openssl x509 -outform der -in /etc/ssl/certs/ca.crt -out /etc/ipsec.d/cacerts/ca.der
openssl rsa -outform der -in /etc/ssl/private/172.31.30.28.key -out /etc/ipsec.d/private/172.31.30.28.der
openssl x509 -outform der -in /etc/ssl/certs/172.31.30.28.crt -out /etc/ipsec.d/certs/172.31.30.28.der
~~~

Configuration file is ipsec.conf:

~~~
# cat /etc/ipsec.conf
config setup
        # strictcrlpolicy=yes
        # uniqueids = no
conn linux-nsx-certs
        authby=rsasig
        auto=start
        leftid="C=IT, ST=Italy, L=Padova, O=RR Labs, OU=Security, CN=172.31.30.28"
        left=172.31.30.28               # strongSwan ouside address
        leftsubnet=192.168.0.0/24       # networks behind strongSwan
        leftcert=172.31.30.28.der
        leftsendcert=always
        rightid="C=IT, ST=Italy, L=Padova, O=RR Labs, OU=Security, CN=172.31.30.30"
        right=172.31.30.30              # NSX Edge outside address
        rightsubnet=10.0.253.0/24       # networks behind NSX Edge
        rightca=%any
        rightrsasigkey=%cert
        ike=aes128-md5-modp1024         # Phase 1: AES, modp1024 = DH group 2
        ikelifetime=28800               #          SA lifetime of 28800 seconds
        keyexchange=ikev2               #          IKEv2, always use PFS
        esp=aes128-sha1-modp1024        # Phase 2: AES, SHA1, DH Group 2
        lifebytes=0                     #          no kbytes rekeying
        lifepackets=0                   #          no packets rekeying
        lifetime=1h                     #          SA lifetime of 3600 seconds
~~~

Define also private key:

~~~
# /etc/ipsec.secrets
172.31.30.28 172.31.30.30 : RSA /etc/ipsec.d/private/172.31.30.28.der
~~~

## Errors I got

During tests I got many errors. So let me discuss one by one:

~~~
2015-03-26T07:58:10+00:00 vShield-edge-2-1 ipsec[14621]: [default]:  [authpriv.warning] "172.31.30.30_10.0.253.0/24-172.31.30.28_192.168.0.0/24/1x1" #561: IKEv2 mode peer ID is ID_DER_ASN1_DN: 'C=IT, ST=Italy, L=Padova, O=RR Labs, OU=Security, CN=172.31.30.28, E=andrea.dainese@gmail.com'
2015-03-26T07:58:10+00:00 vShield-edge-2-1 ipsec[14621]: [default]:  [authpriv.warning] "172.31.30.30_10.0.253.0/24-172.31.30.28_192.168.0.0/24/1x1" #561: no crl from issuer "C=IT, ST=Italy, L=Padova, O=RR Labs, OU=Security, CN=Andrea Dainese, E=andrea.dainese@gmail.com" found (strict=no)
2015-03-26T07:58:10+00:00 vShield-edge-2-1 ipsec[14621]: [default]:  [authpriv.warning] "172.31.30.30_10.0.253.0/24-172.31.30.28_192.168.0.0/24/1x1" #561: no RSA public key known for 'C=IT, ST=Italy, L=Padova, O=RR Labs, OU=Security, CN=172.31.30.28'
2015-03-26T07:58:10+00:00 vShield-edge-2-1 ipsec[14621]: [default]:  [authpriv.warning] "172.31.30.30_10.0.253.0/24-172.31.30.28_192.168.0.0/24/1x1" #561: RSA authentication failed
~~~

It took me a while to find out what happened. The reason is simple and (IMHO) buggy:

* NSX Edge is receiving the remote certificate with the following DN `C=IT, ST=Italy, L=Padova, O=RR Labs, OU=Security, CN=Andrea Dainese, E=andrea.dainese@gmail.com`
* NSX Edge is using the rightid as following `C=IT, ST=Italy, L=Padova, O=RR Labs, OU=Security, CN=172.31.30.28`

There is a mismatch so be sure you're not using email address when creating certificates with openssl.

~~~
2015-03-26T09:06:36+00:00 vShield-edge-2-0 ipsec[21345]: [default]:  [authpriv.warning] "172.31.30.30_10.0.253.0/24-172.31.30.28_192.168.0.0/24/1x1" #5: IKEv2 mode peer ID is ID_DER_ASN1_DN: 'C=IT, ST=Italy, L=Padova, O=RR Labs, OU=Security, CN=172.31.30.28'
2015-03-26T09:06:36+00:00 vShield-edge-2-0 ipsec[21345]: [default]:  [authpriv.warning] "172.31.30.30_10.0.253.0/24-172.31.30.28_192.168.0.0/24/1x1" #5: issuer cacert not found
2015-03-26T09:06:36+00:00 vShield-edge-2-0 ipsec[21345]: [default]:  [authpriv.warning] "172.31.30.30_10.0.253.0/24-172.31.30.28_192.168.0.0/24/1x1" #5: X.509 certificate rejected
2015-03-26T09:06:36+00:00 vShield-edge-2-0 ipsec[21345]: [default]:  [authpriv.warning] "172.31.30.30_10.0.253.0/24-172.31.30.28_192.168.0.0/24/1x1" #5: no RSA public key known for 'C=IT, ST=Italy, L=Padova, O=RR Labs, OU=Security, CN=172.31.30.28'
2015-03-26T09:06:36+00:00 vShield-edge-2-0 ipsec[21345]: [default]:  [authpriv.warning] "172.31.30.30_10.0.253.0/24-172.31.30.28_192.168.0.0/24/1x1" #5: RSA authentication failed
~~~

Be sure the CA certificate has signed both peer certificate.

## References

* [VMware NSX IPSec VPN Overview](http://pubs.vmware.com/NSX-61/index.jsp?topic=%2Fcom.vmware.nsx.admin.doc%2FGUID-6152B56B-2119-48E7-B2F2-BDDCF58B3F14.html&src=vmw_so_vex_adain_773 "VMware NSX IPSec VPN Overview")
* [VMware NSX IKE Phase 1 and Phase 2](http://pubs.vmware.com/NSX-61/index.jsp?topic=%2Fcom.vmware.nsx.admin.doc%2FGUID-2FDA8948-148B-4600-BA10-69C2BEF6D3C4.html?src=vmw_so_vex_adain_773 "VMware NSX IKE Phase 1 and Phase 2")
