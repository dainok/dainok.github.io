---
title: "Twice (double) NAT on Cisco router"
date: "2017-02-01T09:00:00+01:00"
draft: false
---
When different companies must be connected, it's a common request that each company want a the other one present itself with a specific subnet. And usually companies don't agree about IP ranges. A Twice NAT configuration also called double NAT) can help a lot.

In this scenario, the two companies want to be interconnected with a MPLS network for a couple of services:

* CompanyA server (10.1.1.100) must reach CompanyB webserver (10.2.2.200)
* CompanyA is responsible (pay) for the connectivity
* Because of IP address allocations:
    - CompanyA wants CompanyB present itself as 10.1.255.100
    - CompanyA wants to place ISP's router on 10.155.255.0/24
    - CompanyB wants CompanyA present itself as 10.2.255.200
    - CompanyB wants to place ISP's router on 10.255.255.0/24

![Twice NAT topology](/images/posts/2017/02/twicenat-1.png "Twice NAT topology")

The following table describe who NAT what:

| Source Site | Source | Source IP | SNAT@CPB | Destination Site | Destination | Destination IP | DNAT@CPB | Port | Service |
|:--|:--|:--|:--|:--|:--|:--|:--|:--|:--|
| CompanyA | ServerA | 10.1.1.100 | 10.2.255.200 | CompanyB | ServerB | 10.1.255.100 | 10.2.2.200 | 80 | http |

In other words:

* ServerA 10.1.1.100 calls ServerB using 10.1.255.100
* CPEB translate the packages so ServerA's source is 10.2.255.200 and ServerB's destination is 10.2.2.200

Why is that useful?

On many companies I can see internal routing table messed up including external IP addresses without caring about too much. It's obvious that:

* sooner or later you cannot interconnect companies because of overlapping IP addresses
* you cannot interconnect companies that force you a specific IP address as a source

## Relevant Configuration

The following paragraphs show relevant configurations only.

### CompanyA router:

CompanyA router want to reach CompanyB using `10.1.255.0/24`, so a route must be configured:

~~~
ip route 10.1.255.0 255.255.255.0 10.155.255.1
~~~

### CPEA router:

Because CompanyA is providing connectivity, the whole MPLS must know where CompanyA is. So a default gateway could be a good choice:

~~~
ip route 0.0.0.0 0.0.0.0 10.155.255.254
router ospf 1
 default-information originate
~~~

### CPEB router:

CPEB must know where CompanyB is:

~~~
ip route 10.2.2.0 255.255.255.0 10.255.255.254
~~~

If ServerA call ServerB, the CPEB router can see a packet from `10.1.1.100` to `10.1.255.100`. In this case the packet is flowing from the `outside` interface to the `inside` one. Following the [NAT Order of Operation](http://www.cisco.com/c/en/us/support/docs/ip/network-address-translation-nat/6209-5.html "NAT Order of Operation"), the packet is routed before the translation (NAT). But (I guess) because the CPEB does't know where is `10.1.255.100` so the NAT translation cannot be completed. CPEB must also announce the network called from CompanyA (`10.1.255.0/24`):

~~~
ip route 10.1.255.0 255.255.255.0 Null0
ip prefix-list STATIC-TO-OSPF permit 10.1.255.0/24
route-map STATIC-TO-OSPF permit 10
 match ip address prefix-list STATIC-TO-OSPF
router ospf 1
 redistribute static subnets route-map STATIC-TO-OSPF
~~~

The interface facing the customer is configured as inside, the one facing the MPLS is the outside:

~~~
interface Ethernet0/0
 ip address 1.1.1.2 255.255.255.252
 ip nat outside
interface Ethernet0/1
 ip address 10.255.255.1 255.255.255.0
 ip nat inside
~~~

Finally we want to:

* expose the outside ServerA (`10.1.1.100`) using `10.2.255.200`
* expose the inside ServerB (`10.2.2.200`) using `10.1.255.100`

~~~
ip nat outside source static 10.1.1.100 10.2.255.200
ip nat inside source static 10.2.2.200 10.1.255.100
~~~

### CompanyB router

CompanyB router want to reach CompanyA using `10.2.255.0/24`, so a route must be configured:

~~~
ip route 10.2.255.0 255.255.255.0 10.255.255.1
~~~

## Testing

Just ping or start a connection from ServerA to ServerB using (`10.1.255.100`):

~~~
CPEB#show ip nat translations
Pro Inside global      Inside local       Outside local      Outside global
--- ---                ---                10.2.255.200       10.1.1.100
tcp 10.1.255.100:80    10.2.2.200:80      10.2.255.200:46711 10.1.1.100:46711
--- 10.1.255.100       10.2.2.200         ---                ---
~~~

Outside global (translated into outside local) call inside global (translated to inside local).

## References

* [Lab file for UNetLab](https://github.com/dainok/rrlabs/tree/master/labs/Twice%20NAT%20on%20Cisco%20IOS%20routers "Lab file for UNetLab")
* [NAT Order of Operation](http://www.cisco.com/c/en/us/support/docs/ip/network-address-translation-nat/6209-5.html "NAT Order of Operation")
* [IOS Order of Operation](http://etherealmind.com/cisco-ios-order-of-operation/ "IOS Order of Operation")
