---
title: "VMware Standard and Distributed Switch (vSwitch and dvSwitch)"
date: "2014-06-23T09:00:00+01:00"
draft: false
---
By default VMware hypervisors are configured with a standard switch called vSwitch0:

![default_vswitch](/images/posts/2014/06/default_vswitch.png "default_vswitch")

By default the first physical adapter (called vmnic0) is attached to the vSwitch0 and acts as uplink to the physical network. A first network with label "VM Network" is created and dedicated to VMs, and a second label named "Management Network" is dedicated to VMkernel adapters. A VMkernel adapter is a special virtual adapter directly mapped to the hypervisor; inside it flow special types of traffic like: Management, vMotion, FT, vSAN, NFS/iSCSI... Only Management Traffic is enabled by default on first vmk adapter.

Port group is referred to a Network label and is a software isolated group of virtual ports. All ports inside a port group/network label has:

* same VLAN (can be also configured as a trunk even if it's seldom used);
* same security policies (Promiscuous mode, MAC Address Changes, Forged Transmit);
* same traffic shaping policies;
* same failover policies.

No packets can flow between different Network labels using the hypervisor, but if two port group are defined for the same VLAN, communications can still happen using the physical switches.

A distributed virtual switch (dvSwitch) is an enhanced vSwitch where "distributed" refers to the configuration, not to the switching capabilities. A dvSwitch is a centrally managed vSwitch where host configuration is assured to be compliant.

Neither vSwitches or dvSwitches behave like physical switches:

* they don't run Spanning Tree Protocol (STP), they simply ignore BPDU frames;
* each ESXi host presents itself like an end host (portfast and BPDU guard should be used on the switch side);
* Layer 2 loops are avoided because received frames from an uplink adapter are not retransmitted to other uplink adapters.

##  vSwitch and dvSwitch comparison

| Feature | vSwitch | dvSwitch |
|:--|:--|:--|
| Spanning Tree Protocol (STP) | ✕ | ✕ |
| 802.1q (VLAN) support | ✓ | ✓ |
| NIC Teaming/Load Balancing| ✓ (No LACP) | ✓ |
| Cisco Discovery Protocol (CDP) | Receive Only | ✓ |
| Traffic Shaping | Outbound Only | ✓ |
| Private VLAN (PVLAN) | ✕ | ✓ |
| Netflow | ✕ | ✓ |
| SPAN (dvMirror) port | ✕ | ✓ |
| Link Layer Discovery Protocol (LLDP) | ✕ | ✓ |
| Traffic Filtering | ✕ | ✓ |
| Traffic Marking | ✕ | ✓ |
