---
title: "Failed to deploy an OVA"
date: "2014-11-11T09:00:00+01:00"
draft: false
---
Deploying an OVA to a VMware vSphere infrastructure can fail with the following error:

~~~
Failed to deploy OVF package: The request was aborted: The request was cancelled.
~~~

The OVA file can be damaged. Because an OVA file is a TAR, the archive can be tested using 7-Zip. Open the archive, use the verify function and see the result:

![verify_7zip](/images/posts/2014/11/verify_7zip.png "verify_7zip")

The archive is corrupted, and the VMDK file cannot be extracted.
