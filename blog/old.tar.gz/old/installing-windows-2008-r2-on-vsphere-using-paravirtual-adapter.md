---
title: "Installing Windows 2008 R2 on vSphere using Paravirtual adapter"
date: "2014-06-16T09:00:00+01:00"
draft: false
---
Windows 2008 R2 does not include (obviously) VMware Paravirtual drivers by default, so a few more actions are required during install process.

Configure a VM with a Paravirtual adapter:

![vm_w_paravirtual](/images/posts/2014/06/vm_w_paravirtual.png "vm_w_paravirtual")

Start the installation process and map the Floppy drive to a image located within the ESXi hypervisor:

~~~
/vmimages/tools-isoimages/windows.iso
~~~

The disk selection box won't show yo any available disks:

![no_disk_found](/images/posts/2014/06/no_disk_found.png "no_disk_found")

Just load driver from the Floppy image:

![paravirtual_adapter](/images/posts/2014/06/paravirtual_adapter.png "paravirtual_adapter")

And now the boot disk connected to the VMware Paravirtual adapter is available:

![paravirtual_disk](/images/posts/2014/06/paravirtual_disk.png "paravirtual_disk")

Remember to disconnect the Floppy drive after the installation.
