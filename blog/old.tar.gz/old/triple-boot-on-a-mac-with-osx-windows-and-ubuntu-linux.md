---
title: "Triple boot on a Mac with OSX, Windows 10 and Ubuntu Linux 16.04"
date: "2017-02-15T09:00:00+01:00"
draft: false
---
As a network and security architect, I sometimes need to test security and network policies using different OS. A virtual machine can help but what if you need to test policies against physical hardware?

I have a 250GB SSD, and I'm going to allocate:

* 50GB for OS X
* 50GB for Windows
* 150GB for Ubuntu Linux 16.04, my preferred OS

I made lot of tests to make everything working fine, so be sure you follow the steps below carefully.

Mind that you'll need three USB keys:

* Windows 10 installation
* Windows 10 recovery
* Ubuntu 16.04 installation

## Install or prepare OS X

If you have a OSX installed on a single partition, filling the whole disk, go to the next step below in this paragraph.

Otherwise, I suggest to reinstall OS X:

* power off your Mac;
* keep pressing `command + R` while you power on your Mac (release when the apple disappear) and boot into macOS Recovery mode;
* `OS X Utilities` will be loaded:

![OS X Utilities](/images/posts/2017/02/triple-boot-1.png "OS X Utilities")

* open `Disk Utility`, select your main disk and press erase (do that more than once, if first attempt fails);
* name your new partition `OSX`;
* quit `Disk Utility`;
* open `Install OS X` and install it.

When installation is completed, consider to upgrade your OS X to latest version.
After that:

* [download Windows 10 image](https://www.microsoft.com/software-download/windows10 "download Windows 10 image");
* [download Ubuntu Linux 16.04 Desktop image](http://releases.ubuntu.com/16.04/ "download Ubuntu Linux 16.04 Desktop image");
* [download UNetbootin](https://unetbootin.github.io/ "download UNetbootin");
* [download rEFInd Boot Manager](http://www.rodsbooks.com/refind/linux.html "download rEFInd Boot Manager") and unpack it;
* open BootCamp and prepare the first USB key for Windows installation media;
* start UNetbootin and prepare also the second USB key for Ubuntu installation media;
* download refind and unpack it;
* open Disk Utility;
* create another partition, leaving 50GB for OS X partition;
* power off your Mac.

## Install Windows

At the end of this section, you will have a dual boot Mac: OS X and Windows 10. You can boot one OS using `Startup Manager` or via Boot Camp.

Let's begin:

* insert the Windows installation USB key;
* power on holding `option/alt` to open the `Startup Manager`;
* boot from Windows installation USB key;
* in the disk manager, remove the non OS X partition (remove the second one, the bigger one);
* create a new 50GB partition and install Windows on it;
* be sure Boot Camp package is installed too (it contains Mac drivers for Windows);
* create a Windows USB recovery drive;
* power off your Mac.

## Installing ReFind

At the end of this section, we'll install a new bootloader to better manage a multi OS Mac.

Let's begin:

* keep pressing `command + R` while you power on your Mac (release when the apple disappear) and boot into macOS Recovery mode;
* `OS X Utilities` will be loaded;
* open `Disk Utility` and mount OS X partition;
* quit `Disk Utility`;
* open a terminal and install rEFInd (continue even if you got a warning):

~~~
# cd /Volumes/OSX/Users/andrea/Destkop/refind-0.10.2
# ./refind-install
~~~

* power off your Mac.

## Install Ubuntu Linux

At the end of this section, you will have a dual boot Mac: OS X and Ubuntu Linux 16.04. Windows 10 will be broken by Ubuntu installation.

Let's begin:

* insert the Ubuntu installation USB key;
* power on holding `option/alt` to open the `Startup Manager`;
* boot from Ubuntu installation USB key;
* install Ubuntu using the free space (about 150GB);
* power off your Mac.

## Fixing Windows 10 boot (0xc000000e error)

After Ubuntu installation, Windows 10 won't boot anymore. Boot will will fail with 0xc000000e error. Fixing that was the hardest part of this journey.

![0xc000000e Windows 10 error](/images/posts/2017/02/triple-boot-2.png "0xc000000e Windows 10 error")

Let's see how to fix it:

* power on your Mac and boot Ubuntu;
* login, open a shell with administrative privileges;
* edit `/boot/efi/EFI/refind/refind.conf` and include `gptsync`:

~~~
showtools shell, gdisk, memtest, mok_tool, apple_recovery, windows_recovery, about, reboot, exit, firmware, fwupdate, gptsync
~~~

* reboot your Mac and select `Hybrid MBR tool` (`gptsync`) from rEFInd boot loader;
* `gptsync` should detect four partitions:
	- EFI PRotective
	- NTFS/HPFS
	- Linux
	- Linux swap / Solaris
* confirm `gptsync` you want to sync MBR and GPT;
* power off your Mac;
* insert the Windows USB recovery drive;
* power on holding `option/alt` to open the `Startup Manager`;
* boot from Windows USB recovery drive;
* open a command prompt and type:

~~~
bootrec /scanos
bootrec /rebuildbcd
bootrec /fixmbr
bootrec /fixboot
~~~

* power off your Mac.

You can now boot:

* OS X
* Ubuntu
* Windows 10 using legacy mode only

## References

* [Startup key combinations for Mac](https://support.apple.com/HT201255 "Startup key combinations for Mac")
* [macOS Recovery](https://support.apple.com/HT201314 "macOS Recovery")
* [Startup Manager](https://support.apple.com/HT201255 "Startup Manager")
* [Download Windows 10](https://www.microsoft.com/software-download/windows10 "Download Windows 10 image");
* [Download Ubuntu Linux 16.04 Desktop](http://releases.ubuntu.com/16.04/ "Download Ubuntu Linux 16.04 Desktop");
* [Download UNetbootin](https://unetbootin.github.io/ "Download UNetbootin")
* [Download rEFInd Boot Manager](http://www.rodsbooks.com/refind/linux.html "Download rEFInd Boot Manager") and unpack it;
* [Configuring rEFInd Boot Manager](http://www.rodsbooks.com/refind/configfile.html "Configuring rEFInd Boot Manager")
