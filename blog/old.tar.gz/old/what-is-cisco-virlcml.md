---
title: "What is Cisco VIRL/CML?"
date: "2014-02-03T09:00:00+01:00"
draft: false
---
At last Cisco Live 2014 (Milan) there was a lab on Cisco VIRL/CML. Only one PC located in the Walk-in-lab room were available to start a VIRL lab, and I couldn't miss that chance to see what exactly VIRL is. The following post is what I could understand using a VIRL/CML installation during the latest Cisco Live 2014 (Milan).

> Disclaimer: in this post there are many "facts" and also many personal "guesses". Things can change, VIRL/CML is not available yet, so everything is evolving.

## VIRL/CML is not IOU

I can suppose that all readers know what IOU is. By the way let me recap the differences between GNS3, Dynamips, Dynagen, IOU/IOL and iou-web:

* [Dynamips Source Code](https://github.com/GNS3/dynamips/tree/v0.2.10/ "Dynamips Source Code") emulates Cisco routers. That's mean that Dynamips emulates the hardware so a standard IOS can be executed upon it. Dynamips supports both serial and Ethernet interfaces.
* [Dynagen](http://www.dynagen.org/ "Dynagen") is a text-based front-end for Dynamips.
* [GNS3](http://www.gns3.net/ "GNS3"): is a graphical front-end for Dynamips.
* IOU (IOS on Unix)  emulates Cisco IOS: it's an executable files which runs under Sparc/Solaris platform. There is also IOL (IOS on Linux) which runs on x86/Linux platform, and there is should another version which runs on Mac OS platform. IOU supports both serial and Ethernet interfaces. There are also IOU/IOL images which supports a limited subset of Layer 2 features.
* iou-web is a web front-end for IOL (it should works also on Sparc/Solaris, but I never tested it).
* XR4U (XR for Unix): it should emulates Cisco IOS-XR on Unix/Linux platform, I never seen it runs.

Cisco VIRL (Virtual Internet Routing Lab) is the old name of Cisco Modeling Lab  (CML). It's a graphical front-end for Cisco virtualized appliances. Currently VIRL supports:

* [Cisco Cloud Services Router 1000V Series](https://www.cisco.com/en/US/products/ps12559/ "Cisco Cloud Services Router 1000V Series"): based on IOS-XE it runs 3 GigabitEthernet interfaces and requires about 2Gb of RAM (different versions have different requirements).
* vIOS: it should requires less resources than CSR1000v, it's not available for download yet.
* [Cisco IOS XRv](http://www.cisco.com/en/US/products/ps13347/tsd_products_support_general_information.html "Cisco IOS XRv"): based on IOS-XR it should available for download soon.
* Ubuntu Linux: it's a simply Ubuntu Linux Virtual Machine which serves as a server.

All of them are Virtual Machines running x86/x86_64 code.

The main differences between VIRL and IOU are now evident:

* VIRL is not based on IOU, VIRL needs Virtual Machines;
* VIRL won't supports serial interfaces, only Ethernet interfaces will be supported;
* L2 images are not supported, and maybe they won't be supported in the future (explained later).

## What exactly is Cisco VIRL/CML?

Cisco VIRL/CML is a graphical interface to create and manage labs based on virtual/cloud devices. Technically VIRL/CML is based on:

* [OpenStack](https://www.openstack.org/ "OpenStack") and [Linux KVM](http://www.linux-kvm.org/page/Main_Page "Linux KVM"): KVM is the hypervisor who runs Virtual Machines, and OpenStack is the manger.
* [Eclipse](https://www.eclipse.org/ "Eclipse"); don't know it's a Java app or not.
* [Autonetkit](http://www.autonetkit.org/ "Autonetkit"): it can automatically allocate IP addresses, configure routing and generate configuration files with templates.

Let's me clarify: Cisco VIRL/CML is a graphical front-end (like GNS3) which can create labs using x86 images using OpenStack/KVM. It's faster than Dynamips, more flexible than IOU/IOL, but it supports only L3 Ethernet interfaces. The reason is pretty simple: L2 switches are provided by OpenStack/KVM layer.

My opinion is that L2 interfaces could be supported if a L2 IOS is installed within the OpenStack/KVM suite: like Nexus 1000V is installed within the VMware vSphere suite.

Serial interfaces could be supported also (using classic COM/TTYSx ports), but because VIRL/CML is based on production cloud devices, I suppose we'll never see L2 or serial interfaces on VIRL/CML.

A good news is that VIRL/CML could support all cloud devices Cisco will make available:

* [Cisco Virtual Wide Area Application Services (vWAAS)](http://www.cisco.com/en/US/products/ps11231/index.html "Cisco Virtual Wide Area Application Services (vWAAS)")
* [Cisco Virtual Wireless Controller](http://www.cisco.com/en/US/products/ps12723/index.html "Cisco Virtual Wireless Controller")
* [Cisco ASA 1000V Cloud Firewall](http://www.cisco.com/en/US/products/ps12233/ "Cisco ASA 1000V Cloud Firewall")

But VIRL/CML could  support also:

* different type of Linux appliances: Ubuntu is already supported;
* other's vendor appliances like NetScaler, Imperva, SourceFire...

## When VIRL/CML will be released?

Cisco VIRL/CML seems pretty but not completely stable: I can make it crash a couple of time during my test. Rumors say that VIRL/CML will be released not before the end of 2014: someone refers to marketing problems, someone refers to technical problem.

It's pretty sure that VIRL/CML will be available as OVF/OVA Virtual Machine but also as a bare metal installation (a whole server dedicated to VIRL/CML).

**Update (2014-04-29):** Cisco Modeling Labs will be released by **late Summer 2014**:

> **Q.** Is there a hosted or cloud offering?
> **A.** No, there is no hosted or cloud offering.
> **Q.** How do customers purchase Cisco Modeling Labs?
> **A.** The corporate edition will be on the global price list and orderable on the Cisco Commerce Workspace at Cisco.com by late summer 2014.

**Update (2014-05-22):** Cisco Modeling Labs will be released **before the end of July 2014** ([Daniel's blog](http://lostintransit.se/2014/05/22/a-short-update-on-cml-from-clus/ "Daniel's blog")).

## References

* [Cisco&rsquo;s Virtual Internet Routing Lab &ndash; When?](http://blog.ine.com/2013/05/01/ciscos-virtual-internet-routing-lab-when/ "Cisco&rsquo;s Virtual Internet Routing Lab &ndash; When?") by Brian Dennis
* [Cisco Modeling Lab (VIRL) behind the scenes](http://blog.ipspace.net/2013/10/cisco-modeling-lab-virl-behind-scenes.html "Cisco Modeling Lab (VIRL) behind the scenes") by Ivan Pepelnjak
* [Response: Cisco Modeling Lab (VIRL) Behind the Scenes](http://etherealmind.com/response-cisco-modeling-lab-virl-behind-the-scenes-ipspace-net/ "Response: Cisco Modeling Lab (VIRL) Behind the Scenes") by Greg Ferro
* [Cisco Modeling Labs](http://www.cisco.com/web/learning/learning_services/cml.html "Cisco Modeling Labs")
* [Cisco Modeling Labs 1.0 Corporate Edition ](http://www.cisco.com/web/learning/learning_services/courses/docs/CML_Corporate_Edition_DS.pdf "Cisco Modeling Labs 1.0 Corporate Edition ")
* [Cisco Modeling Labs  FAQ](http://www.cisco.com/web/learning/learning_services/courses/docs/Cisco_Modeling_Labs_QA.pdf "Cisco Modeling Labs  FAQ")
