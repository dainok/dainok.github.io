---
title: "GLBP"
date: "2013-09-14T09:00:00+01:00"
draft: false
---
GLBP (Gateway Load Balancing Protocol) is a Cisco proprietary protocol needed to make a default gateway redundant. If HSRP can configure only one active router, GLBP can have up to four active routers in the same time. GLBP allows a better traffic balance than HSRP or VRRP.

![Glbp_topology](/images/posts/2013/09/Glbp_topology.png "Glbp_topology")

The high priority GLBP node becames Active Virtual Gateway (AVG). The second one with high prioriety became AVG Standby.
The AVG answers to the ARP requests made by client, assigning them the Virtual MAC (vMAC). Each vMAC is assigned to an Active Virtual Forwarder (AVF). An AVF is an active router configured with GLBP. AVG and AVG Standby routers are AVF too.
All AVF routers listen to each other: if one AVF fails, the vMAC is reassigned to another AVF.
The GLBP configuration needs a numeric group and the virtual ip address:

~~~
glbp 1 ip 192.168.10.254
~~~

Authentication can be configured to enhance security:

~~~
glbp 1 authentication md5 key-string CCIE
~~~

At this point GLBP is already working. The MAC address 0007.b400.0101 is a vMAC; another three vMAC are availabl for future nodes:

~~~
R1#show glbp brief
Interface   Grp  Fwd Pri State    Address         Active router   Standby router
Et0/0       1    -   100 Active   192.168.10.254  local           unknown
Et0/0       1    1   -   Active   0007.b400.0101  local           -
~~~

Adding two more routers, one of them bacame AVG Standby:

~~~
R1#show glbp brief
Interface   Grp  Fwd Pri State    Address         Active router   Standby router
Et0/0       1    -   100 Active   192.168.10.254  local           192.168.10.3
Et0/0       1    1   -   Active   0007.b400.0101  local           -
Et0/0       1    2   -   Listen   0007.b400.0102  192.168.10.2    -
Et0/0       1    3   -   Listen   0007.b400.0103  192.168.10.3    -
~~~

~~~
R2#show glbp brief
Interface   Grp  Fwd Pri State    Address         Active router   Standby router
Et0/0       1    -   100 Listen   192.168.10.254  192.168.10.1    192.168.10.3
Et0/0       1    1   -   Listen   0007.b400.0101  192.168.10.1    -
Et0/0       1    2   -   Active   0007.b400.0102  local           -
Et0/0       1    3   -   Listen   0007.b400.0103  192.168.10.3    -
~~~

~~~
R3#show glbp brief
Interface   Grp  Fwd Pri State    Address         Active router   Standby router
Et0/0       1    -   100 Standby  192.168.10.254  192.168.10.1    local
Et0/0       1    1   -   Listen   0007.b400.0101  192.168.10.1    -
Et0/0       1    2   -   Listen   0007.b400.0102  192.168.10.2    -
Et0/0       1    3   -   Active   0007.b400.0103  local           -
~~~

R1 is the AVG (first line), the assigned vMAC is 0007.b400.0101. R3 is the AVG Standby, with the vMAC 0007.b400.0103. R2 is an AVF node with the vMAC 0007.b400.0102. The priority is the router priority where the "show" command is typed.
Each router can configure the priority and the weight:

~~~
glbp 1 priority 150
glbp 1 preempt
glbp 1 weighting 50
~~~

The R1 weigth is configured as 50, R2's weight as 20 and R3's weight as 20. In this example 50% of traffic will flows through R1, 30% through R2 and 20% through R3. Mind that weigth is not a percent value, but if sum of all weights is 100, then weight can supposed to be a percent value.

~~~
R1#show glbp
Ethernet0/0 - Group 1
  State is Active
    1 state change, last state change 00:32:30
  Virtual IP address is 192.168.10.254
  Hello time 3 sec, hold time 10 sec
    Next hello sent in 0.832 secs
  Redirect time 600 sec, forwarder timeout 14400 sec
  Authentication MD5, key-string
  Preemption enabled, min delay 0 sec
  Active is local
  Standby is 192.168.10.2, priority 120 (expires in 9.440 sec)
  Priority 150 (configured)
  Weighting 5 (configured 5), thresholds: lower 1, upper 5
  Load balancing: round-robin
  Group members:
    aabb.cc00.0100 (192.168.10.1) local
    aabb.cc00.0200 (192.168.10.2) authenticated
    aabb.cc00.0300 (192.168.10.3) authenticated
  There are 3 forwarders (1 active)
  Forwarder 1
    State is Active
      1 state change, last state change 00:32:19
    MAC address is 0007.b400.0101 (default)
    Owner ID is aabb.cc00.0100
    Redirection enabled
    Preemption enabled, min delay 30 sec
    Active is local, weighting 50
  Forwarder 2
    State is Listen
    MAC address is 0007.b400.0102 (learnt)
    Owner ID is aabb.cc00.0200
    Redirection enabled, 599.456 sec remaining (maximum 600 sec)
    Time to live: 14399.456 sec (maximum 14400 sec)
    Preemption enabled, min delay 30 sec
    Active is 192.168.10.2 (primary), weighting 30 (expires in 10.432 sec)
  Forwarder 3
    State is Listen
    MAC address is 0007.b400.0103 (learnt)
    Owner ID is aabb.cc00.0300
    Redirection enabled, 597.472 sec remaining (maximum 600 sec)
    Time to live: 14397.472 sec (maximum 14400 sec)
    Preemption enabled, min delay 30 sec
    Active is 192.168.10.3 (primary), weighting 20 (expires in 9.184 sec)
~~~

A `weigthing` interval can be configured:

~~~
glbp 1 weighting 20 lower 15 upper 20
glbp 1 weighting track 1 decrement 10
~~~

~~~
R1#show glbp brief

Interface   Grp  Fwd Pri State    Address         Active router   Standby router
Et0/0       1    -   150 Active   192.168.10.254  local           192.168.10.2
Et0/0       1    1   -   Active   0007.b400.0101  local           -
Et0/0       1    2   -   Listen   0007.b400.0102  192.168.10.2    -
Et0/0       1    3   -   Listen   0007.b400.0103  192.168.10.2    -
~~~

In the above example R3 leaves the active mode because the corrent weigth (10) is lower than the minimum acceptable value (15). R2 took the R3 vMAC.
