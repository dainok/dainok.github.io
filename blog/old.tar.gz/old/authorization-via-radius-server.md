---
title: "Authorization via RADIUS server"
date: "2016-07-18T09:00:00+01:00"
draft: false
---
In this post we'll see how to give administrative roles via RADIUS server for some devices, especially using Microsoft NPS server configuration.

## Configured devices

Currently I manage administrative roles for:

* APC PDUs and UPS
* Eaton ePDU
* Cisco IOS based devices (routers and switches)
* Cisco NX-OS based devices (Nexus and MDS)
* Cisco UCS Manager
* [Cisco WLC](/2016/02/configuring-radius-authentication-on-cisco-virtual-wlc-vwlc "Configuring RADIUS authentication on Cisco Virtual WLC (vWLC)")
* [Checkpoint Gaia and Dashboards](/2016/09/radius-authentication-on-checkpoint-vsx "Checkpoint Gaia and Dashboards")
* [Citrix NetScaler](/2016/09/radius-authentication-on-citrix-netscaler "Citrix NetScaler")
* InfoBlox

## Configured attributes

Cisco IOS based routers and switches use a Vendor-Specific Attributes (VSA) called Cisco-AV-Pair:

~~~
shell:priv-lvl=15
~~~

Level 15 is administrative, lower values can be used for other roles.

Cisco NX-OS based devices (Nexus and MDS) use Cisco-AV-Pair too, but with a different syntax:

~~~
shell:roles=vdc-admin,network-admin
~~~

Cisco UCS Manager uses again  Cisco-AV-Pair too:

~~~
shell:roles=admin
~~~

Other devices (like Cisco WLC, APC PDUs and UPS) uses the standard attribute Service-Type:

~~~
Administrative
~~~

Eaton ePDU devices need a custom vendor/attribute:

* Vendor Specific ID: 534
* Vendor Specific Attribute ID: (string) 29
* Value: `ePDUAdmin`

The value `ePDUAdmin` must be also configured within ePDU management interface, under Settings -> Access Accounts -> Multi user access -> Add a Remote Group:

* Group Name: `ePDUAdmin`
* Prodfile: `Admin`
* Access: `Read-write`

Checkpoint Gaia and Dashboards need two custom vendor attributes:

* Vendor Specific ID: 2620
* Vendor Specific Attribute ID: (string) 229
* Value: `adminRole`
* Vendor Specific Attribute ID: (decimal) 230
* Value: `1`

Citrix NetScaler needs a custom ventod attribute configured also on NetScaler side. The suggested one is:

* Vendor Specific ID: 3845
* Vendor Specific Attribute ID: (string) 25
* Value: `admins` or `users`

InfoBlox needs a custom ventod attribute configured as a group on InfoBlox side. The suggested one is:

* Vendor Specific ID: 7779
* Vendor Specific Attribute ID: (string) 9
* Value: `admin-group`

## The suggested configuration

After many tests I suggest a policy for each device type and role, for example:

* Citrix NetScaler administrators (matching devices with `NS-` prefix on friendly name and an `NS-admins` AD group)
* Citrix NetScaler users (matching devices with `NS-` prefix on friendly name and an `NS-users` AD group)
* Checkpoint admnistrators (matching devices with `CP-` prefix on friendly name and an `CP-admins` AD group)
* Checkpoint users (matching devices with `CP-` prefix on friendly name and an `CP-users` AD group)
* Cisco IOS administrators (matching devices with `IOS-` prefix on friendly name and an `IOS-admins` AD group)
* Cisco IOS users (matching devices with `IOS-` prefix on friendly name and an `IOS-users` AD group)
* Cisco WAN administrators (matching devices with `ASR-` prefix on friendly name and an `ASR-admins` AD group)
* Cisco WAN users (matching devices with `ASR-` prefix on friendly name and an `ASR-users` AD group)
* Cisco MDS administrators (matching devices with `MDS-` prefix on friendly name and an `MDS-admins` AD group)
* Cisco MDS users (matching devices with `MDS-` prefix on friendly name and an `MDS-users` AD group)
* Cisco UCS administrators (matching devices with `UCS-` prefix on friendly name and an `UCS-admins` AD group)
* Cisco UCS users (matching devices with `UCS-` prefix on friendly name and an `UCS-users` AD group)
* APC PDU administrators (matching devices with `APC-` prefix on friendly name and an `APC-admins` AD group)
* EATON PDU administrators (matching devices with `EATON-` prefix on friendly name and an `EATON-admins` AD group)
* [...]

The above configuration allows to identify different group for different device type.

For Cisco devices, the suggested configuration to serve all above devices using a single policy, is:

* Service-Type: `Administrative`
* Cisco-AV-Pair: `shell:roles=admin,vdc-admin,network-admin`
* Cisco-AV-Pair: `shell:priv-lvl=15`

![Cisco-AV-Pair on NPS](/images/posts/2016/07/Multitple-RADIUS-1.png "Cisco-AV-Pair on NPS")

For some reasons Cisco UCS will ignore multiple Cisco-AV-Pair, so be sure the order of Cisco-AV-Pair attributes match the above one. Otherwise Cisco UCS Manager will give the `read-only` role only to RADIUS authenticated users.

## Issues

Some old Cisco equipment cannot manage multiple `Cisco-AV-Pair` attributes. In that case a specific network policy should be created with a `Client IPv4 Address` condition. A RegEx can be sed to specify multiple IP addresses, for example `10\.2\.45\.10|10\.2\.45\.11` matches against 10.2.45.10 and 10.2.45.11.

Or, better, you can define some prefix on every client (`Friendly name`), for example:
* `CP-` for Checkpoint
* `APC-` for APC
* `NS-` for NetScaler

And filter as condition on `Network Policies`, using: `CP-|APC-`

## References

* [Configuring Authentication](https://www.cisco.com/c/en/us/td/docs/unified_computing/ucs/sw/gui/config/guide/2-0/b_UCSM_GUI_Configuration_Guide_2_0/b_UCSM_GUI_Configuration_Guide_2_0_chapter_0111.html "Configuring Authentication")
