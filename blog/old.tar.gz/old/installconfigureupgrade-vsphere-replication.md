---
title: "Install/Configure/Upgrade vSphere Replication"
date: "2014-06-18T09:00:00+01:00"
draft: false
---
Download and unpack the VMware-vSphere_Replication-5.5.1.0-1618023.zip file from the VMware portal, then deploy the appliance using vSphere_Replication_OVF10.ovf file on the primary site. The other OVF (vSphere_Replication_AddOn_OVF10.ovf) will be used to deploy an additional replication server on a secondary site. According to README:

> vSphere_Replication_OVF10.ovf - Use this file to install all VR components, including the vSphere Replication Management Server and a vSphere Replication Server.
> vSphere_Replication_AddOn_OVF10.ovf - Use this file to install an optional additional vSphere Replication Server.

Appliance name depends on the OVF file used:

* vSphere Replication Appliance is the one (full) deployed from the vSphere_Replication_OVF10.ovf  file;
* vSphere Replication Server is the one (lite) deployed from the vSphere_Replication_AddOn_OVF10.ovf  file.

Power on the VMware vSphere Replication Appliance (vRA) and point a browser to it using https and port 5480 (https://172.31.30.6:5480/); login using root account and the password provided during the OVF deploy. Default configuration is ready for replication within the same vCenter, be sure VMware Replication Management (VRM) service is running on VRA:

![vra_service](/images/posts/2014/06/vra_service.png "vra_service")

Check service health on vCenter too:

![vsphere_service](/images/posts/2014/06/vsphere_service.png "vsphere_service")

Finally logout from the vSphere Web Client and login again.  On the home page the VMware Replication will be available:

![replication_home](/images/posts/2014/06/replication_home.png "replication_home")

If login on  Virtual Appliance Management Interface (VAMI) fails (Unable to connect to server. Please try again.), try to unregister the VRA extension (com.vmware.vcHms), reinstall VRA and clear the browser cache.

## References

* [VMware vSphere Replication Administration](http://pubs.vmware.com/vsphere-55/topic/com.vmware.ICbase/PDF/vsphere-replication-55-admin.pdf "VMware vSphere Replication Administration")
