---
title: "Troubleshooting invalid path configuration on Cisco ACI"
date: "2018-03-21T09:00:00+01:00"
draft: false
---
One of the most common error while connecting devices to a Cisco ACI fabric is related to an invalid path configuration.

The full error is:

> Fault delegate: Configuration failed for uni/tn-TenantName/ap-AppName/epg-EpgName node 101 PC_to_Switch1 due to Invalid Path Configuration, debug message: invalid-path: vlan-200 :There is no domain, associated with both EPG and Port, that has required VLAN;

In other words, there is a mismaatch/misconfiguration between the tenant view and the fabric view regarding VLAN, physical ports or physical domain:

1. Starts from Tenant -&gt; &lt;tenant name&gt; -&gt; Application Profiles -&gt; &lt;application profile name&gt; -&gt; Application EPGs -&gt; &lt;EPG name&gt; -&gt; Static Ports and check if all ports, facing the external switches, are defined here, and be sure the VLAN is correct.
2.  Go to Tenant -&gt; &lt;tenant name&gt; -&gt; Application Profiles -&gt; &lt;application profile name&gt; -&gt; Application EPGs -&gt; &lt;EPG name&gt; -&gt; Domains and check that the right physical domain is defined here.
3. Go to Fabric -&gt; Access Policies -&gt; Physical and External Domains -&gt; Physical Domain -&gt; &lt;domain name found in #2&gt; and check that the VLAN defined in #2 is included in a VLAN pool.
4. Go to Fabric -&gt; Access Policies -&gt; Switch Policies -&gt; Profiles -&gt; Leaf Profiles -&gt; &lt;leaf profile name&gt; and check that all required leafs and interface profiles are associated.
5. Go to Fabric -&gt; Access Policies -&gt; Interface Policies -&gt; Profiles -&gt; Leaf Profiles -&gt; &lt;interface profiles found in #4&gt; and check that the correct interfaces are associated to each interface profile, and check which policy groups are associated.
6. Go to Fabric -&gt; Access Policies -&gt; Interface Profiles -&gt; Policy Groups -&gt; Leaf Policy Groups -&gt; &lt;policy groups found in #5&gt; and check that AAEP matches.
7. Go to Fabric -&gt; Access Policies -&gt; Global Policies -&gt; Attachable Access Entity Profiles -&gt; &lt;AAEP name found in #6&gt; and check that includes the physical domain found in #2.

## References

* [The Cisco ACI Workflow](/2018/03/cisco-aci-workflow/ "The Cisco ACI Workflow")
