---
title: "Dealing with SNMP on Linux"
date: "2017-03-29T09:00:00+01:00"
draft: false
---
Every time I need to work with Linux SNMP utilities, I have to re-learn some commands. This post summarize useful SNMP commnads for anyone who need a reference guide.

## Common options

Usually I need to build a custom and trusted MIB repository. Every SNMP utility can take the following flags:

* `-M` takes one or more directory where look for MIB file.
* `-m` selectively load MIB files from the above directories. I usually use `ALL`.

## SNMP Translate

Dealing with MIB files can be a pain. Sometimes is faster and simpler to use the numeric OIDs. But how we can find numeric OID from alphabetic ones and back?

Find mathing MIB files given a regex:

~~~
$ snmptranslate -m ALL -M mibs -TB sysName
SNMPv2-MIB::sysName
~~~

Print the numeric OID given an alphabetic ones:

~~~
$ snmptranslate -m ALL -M $HOME/.snmp/mibs -On SNMPv2-MIB::sysName
.1.3.6.1.2.1.1.5
~~~

Print the alphabetic OID given a numeric ones:

~~~
$ snmptranslate -m ALL -M $HOME/.snmp/mibs .1.3.6.1.2.1.1.5
SNMPv2-MIB::sysName
~~~

Print only last symbolic element of an OID (numeric or alphabetic):

~~~
$ snmptranslate -m ALL -M $HOME/.snmp/mibs -Os .1.3.6.1.2.1.1.5
sysName
~~~

Print full alphabetic OID given a numeric ones:

~~~
$ snmptranslate -m ALL -M $HOME/.snmp/mibs -Of .1.3.6.1.2.1.1.5
.iso.org.dod.internet.mgmt.mib-2.system.sysName
~~~

## SNMP Get and Walk

Getting a single SNMP entry:

~~~
$ snmpget -m ALL -M $HOME/.snmp/mibs -v3 -l authNoPriv -u username -a SHA -A password 10.1.1.6 sysName
SNMPv2-MIB::sysName = No Such Instance currently exists at this OID
~~~

The `snmpget` command does not "walk", so the exact OID must be given:

~~~
$ snmpget -m ALL -M $HOME/.snmp/mibs -v3 -l authNoPriv -u username -a SHA -A password 10.1.1.6 sysName.0
SNMPv2-MIB::sysName.0 = STRING: router.example.com
~~~

Because of that, usually `snmpwalk` is preferred:

~~~
$ snmpwalk -m ALL -M $HOME/.snmp/mibs -v3 -l authNoPriv -u username -a SHA -A password 10.1.1.6 sysName
SNMPv2-MIB::sysName.0 = STRING: router.example.com
~~~

## Get a table via SNMP

Some SNMP entry can be retrieved individually or aggregated (in a table): those attributes usually contains `Table` inside the alphabetic OID. Let's retrieve, for example, `ifTable`:

~~~
$ snmptable -m ALL -M $HOME/.snmp/mibs -v3 -l authNoPriv -u username -a SHA -A password -Cf , 10.1.1.6 ifTable
SNMP table: IF-MIB::ifTable

ifIndex,ifDescr,ifType,ifMtu,ifSpeed,ifPhysAddress,ifAdminStatus,ifOperStatus,ifLastChange,ifInOctets,ifInUcastPkts,ifInNUcastPkts,ifInDiscards,ifInErrors,ifInUnknownProtos,ifOutOctets,ifOutUcastPkts,ifOutNUcastPkts,ifOutDiscards,ifOutErrors,ifOutQLen,ifSpecific
1,Ethernet0/0,ethernetCsmacd,1500,10000000,0:2:16:cd:7:a0,up,up,0:13:59:40.11,1933415192,81395,19172271,114,102,7142667,129749909,1081118,186805,0,48,0,ccitt.0
2,Null0,other,1500,4294967295,,up,up,0:0:00:00.00,0,0,0,0,0,0,0,0,0,0,0,0,ccitt.0
~~~

The above example will delimitate columns using a `,`, useful to generate a CSV compatible output.

A large screen readable output can be the following:

~~~
$ snmptable -m ALL -M $HOME/.snmp/mibs -v3 -l authNoPriv -u username -a SHA -A password -Cc 10 10.1.1.6 ifTable
SNMP table: IF-MIB::ifTable

   ifIndex   ifDescr    ifType     ifMtu   ifSpeed ifPhysAdd ifAdminSt ifOperSta ifLastCha ifInOctet ifInUcast ifInNUcas ifInDisca ifInError ifInUnkno ifOutOcte ifOutUcas ifOutNUca ifOutDisc ifOutErro ifOutQLen ifSpecifi
         1 Ethernet0 ethernetC      1500  10000000 0:2:16:cd        up        up 0:13:59:4 193354931     81408  19173500       114       102   7143018 129757359   1081161    186811         0        48         0   ccitt.0
         2     Null0     other      1500 429496729                  up        up 0:0:00:00         0         0         0         0         0         0         0         0         0         0         0         0   ccitt.0
~~~

## References

* [SNMP Object Navigator](http://snmp.cloudapps.cisco.com/Support/SNMP/do/BrowseOID.do?local=en "SNMP Object Navigator")
* [Private Enterprise Numbers](https://www.iana.org/assignments/enterprise-numbers/enterprise-numbers "Private Enterprise Numbers")
* [Private Enterprise Number (PEN) Request](http://pen.iana.org/pen/PenApplication.page "Private Enterprise Number (PEN) Request")
