---
title: "Various SSL errors while using VMware Web Client or vClient"
date: "2015-03-25T09:00:00+01:00"
draft: false
---
Many errors can occur while using a misconfigured VMware Web client or vClient. Below you can find the errors I found.


## Opening console from Web Client

![Thumbprint mismatch SSL error](/images/posts/2015/03/vsphere_ssl_error-1.png "Thumbprint mismatch SSL error")

~~~
SSL verification failure for "vcenter1.example.com" due to a host thumbprint mismatch: stored thumbprint "8d:29:ae:69:87:e5:cc:a0:ff:01:51:25:84:8a:b4:d3:b5:a3:55:33" does not match certificate thumbprint "5B:E9:36:23:44:F0:4D:E5:6A:F3:7E:BC:4F:FE:9D:0D:93:64:03:E0".
~~~

## Opening console from vClient

![Unable to connect to the MKS error](/images/posts/2015/03/vsphere_ssl_error-2.png "Unable to connect to the MKS error")

~~~
Unable to connect to the MKS: Login (username/password) incorrect.
~~~

or

~~~
The server name could not be resolved
~~~

Deploying an OVF/OVA from Web Client (after selecting the datastore):

![Unable to establish an SSL connection error](/images/posts/2015/03/vsphere_ssl_error-3.png "Unable to establish an SSL connection error")

~~~
Unable to establish an SSL connection with vCenter Server
~~~

or

~~~
Unable to validate that the OVF can be imported on the vCenter Serve
~~~

## Solution

The most common reason of all above errors are hostname resolution. Be sure the client where Web/vClient is running, has the same hostname resolution of vCenter. In other words be sure that clients and vServer are using same DNS servers. Be sure you also check hosts file.

