---
title: "Moving a powered off VM from CLI"
date: "2015-01-08T09:00:00+01:00"
draft: false
---
In this short post we'll see how to move a powered off VM from one host to another one using CLI commands.

The first step is list the required VM:

~~~
~ # vim-cmd vmsvc/getallvms
Vmid    Name        File                                      Guest OS                 Version
4       vcenter1    [esx1_datastore] vcenter1/vcenter1.vmx    windows7Server64Guest    vmx-08
~~~

The VM ID is 4. Let's check the power status:

~~~
~ # vim-cmd vmsvc/get.summary 4 | grep powerState
      powerState = "poweredOff",
~~~

The VM is powered off. A good idea is remove unneeded snapshots:

~~~
~ # vim-cmd vmsvc/snapshot.removeall 4
Remove All Snapshots:
~~~

The VM can be safely unregistered:

~~~
~ # vim-cmd vmsvc/unregister 4
~~~

Temporary enable SSH client from source host:

~~~
~ # esxcli network firewall ruleset list | grep ssh
~ # vim-cmd hostsvc/firewall_enable_ruleset sshClient
~~~

Now copy the VM to the new host and disable outgoing SSH connections (SSH server access is supposed to be already enabled):

~~~
~ # scp -pr /vmfs/volumes/esx1_datastore/vcenter1 esxi2.example.com:/vmfs/volume
s/539ec0f4-a0d9072d-f444-001a4bbef6c2
~ # vim-cmd hostsvc/firewall_disable_ruleset sshClient
~~~

Remove source files:

~~~
~ # rm -rf /vmfs/volumes/esx1_datastore/vcenter1
~~~

On the destination host, register the new VM:

~~~
~ # vim-cmd solo/registervm /vmfs/volumes/esxi2_datastore/vcenter1/vcenter1.vmx
~~~

Now power on the VM:

~~~
~ # vim-cmd vmsvc/getallvms
Vmid    Name        File                                      Guest OS                 Version
12      vcenter1    [esx1_datastore] vcenter1/vcenter1.vmx    windows7Server64Guest    vmx-08
~ # vim-cmd vmsvc/power.on 12 &
~ # vim-cmd vmsvc/message 12
Virtual machine message _vmx1:
This virtual machine might have been moved or copied. In order to configure certain management and networking features, VMware ESX needs to know if this virtual machine was moved or copied. If you don't know, answer "I Copied It".
   0. Cancel (Cancel)
   1. button.uuid.movedTheVM (I Moved It)
   2. button.uuid.copiedTheVM (I Copied It) [default]
~ # vim-cmd vmsvc/message 12 _vmx1 1
~~~

The above command require VM ID, Message ID as parameters and answer ID as parameters.
