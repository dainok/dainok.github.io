---
title: "RADIUS authentication on Checkpoint VSX"
date: "2016-09-21T09:00:00+01:00"
draft: false
---
Configuring RADIUS authentication on Checkpoint VSX is pretty simple and takes just few minutes.

Before starting remember that local users are always working. A local user can always authenticate despite of RADIUS servers status.

## Gaia OS/SSH Authentication

The following configuration uses four RADIUS servers:

~~~
add aaa radius-servers priority 1 host 10.0.0.101 port 1812 secret longpassword timeout 2
add aaa radius-servers priority 2 host 10.0.0.102 port 1812 secret longpassword timeout 2
add aaa radius-servers priority 3 host 10.1.0.101 port 1812 secret longpassword timeout 2
add aaa radius-servers priority 4 host 10.1.0.102 port 1812 secret longpassword timeout 2
set aaa radius-servers NAS-IP 10.100.0.15
set aaa radius-servers default-shell /etc/cli.sh
set aaa radius-servers super-user-uid 0
~~~

In this example all RADIUS authenticated users use the CLIsh shell and are allowed to the expert mode (`super-user-uid`).

Remeber that the following RADIUS attributes must also be configured:

* CP-Gaia-User-Role: Vendor Code `2650`, Attribute number `229`, string `adminRole`
	* `adminrole`
	* `backuprole`
	* `securityrole`
* CP-Gaia-SuperUser-Access: Vendor Code `2650`, Attribute number `230`, decimal `1`
	* `0` * This user cannot receive superuser permissions (expert mode)
	* `1` * This user can receive superuser permissions (expert mode)

Mind also that in my tests (R77.30):
* Both VSX nodes send RADIUS requests using the VIP IP address (yes, the passive node too), so be sure you configure the RADIUS server with all node IP addresses and VIP too.
* some additional servers (management, domain-management, smart-event) send RADIUS requests through the management or domain-management host; logserver send RADIUS requests directly. So be sure you configure the same RADIUS secret everywhere (CLIsh, SmartDashboard).

## SmartDomain Manager Authentication

If the installation does not use the multi-domain feature, please skip to the next section. Otherwise open the SmartDomain Manager -> Global Policies, right click on Multi-Domain Security Management -> Launch Global SmartDashboard.

![SmartDomain Manager](/images/posts/2016/09/Checkpoint-RADIUS-1.png "SmartDomain Manager")

Now open Firewall -> Servers and OPSEC, right click on Servers -> New -> RADIUS:

![RADIUS Server Properties](/images/posts/2016/09/Checkpoint-RADIUS-2.png "RADIUS Server Properties")

Go to the Accounting tab and enable accounting if needed:

![RADIUS Server Accounting](/images/posts/2016/09/Checkpoint-RADIUS-3.png "RADIUS Server Accounting")

Confirm and now create a RADIUS group adding all RADIUS servers configured:

![RADIUS Group](/images/posts/2016/09/Checkpoint-RADIUS-4.png "RADIUS Group")

Confirm, exit from the SmartDashboard and go back to the SmartDomain Manager -> Administrators:

![SmartDomain Administrators](/images/posts/2016/09/Checkpoint-RADIUS-5.png "SmartDomain Administrators")

Add all RADIUS users that need to authenticate with administrator privileges:

![Add Administrator](/images/posts/2016/09/Checkpoint-RADIUS-6.png "Add Administrator")

Go to Authentication and select RADIUS:

![Administrator authentication method](/images/posts/2016/09/Checkpoint-RADIUS-7.png "Administrator authentication method")

If some users does not have Multi-Domain privileges, add them to a specific domain. Go to General -> Domain Cotents, right click on the domain -> Configure domain -> Administrators and assign all users that need administrator privileges for that specific domain:

![Domain Configuration](/images/posts/2016/09/Checkpoint-RADIUS-8.png "Domain Configuration")

## SmartDomain Dashboard Authentication

Open the SmartDashboard -> Firewall -> Servers and OPSEC, right click on Servers -> New -> RADIUS:

![RADIUS Server Properties](/images/posts/2016/09/Checkpoint-RADIUS-2.png "RADIUS Server Properties")

Go to the Accounting tab and enable accounting if needed:

![RADIUS Server Accounting](/images/posts/2016/09/Checkpoint-RADIUS-3.png "RADIUS Server Accounting")

Confirm and now create a RADIUS group adding all RADIUS servers configured:

![RADIUS Group](/images/posts/2016/09/Checkpoint-RADIUS-4.png "RADIUS Group")

Confirm, and now open Firewall -> Users and Administrators, right click on users -> New User > Default:

![User Properties](/images/posts/2016/09/Checkpoint-RADIUS-9.png "User Properties")

Go to Authentication and select RADIUS:

![User Authentication Properties](/images/posts/2016/09/Checkpoint-RADIUS-10.png "User Authentication Properties")

Finally assign the right Permissions Profile to each user.

## References

* [How to configure RADIUS authentication on Gaia OS](https://supportcenter.checkpoint.com/supportcenter/portal?eventSubmit_doGoviewsolutiondetails=&solutionid=sk72940 "How to configure RADIUS authentication on Gaia OS")
* [How to configure the SmartDashboard administrator for external RADIUS server authentication](https://supportcenter.checkpoint.com/supportcenter/portal?eventSubmit_doGoviewsolutiondetails=&solutionid=sk40697 "How to configure the SmartDashboard administrator for external RADIUS server authentication")
