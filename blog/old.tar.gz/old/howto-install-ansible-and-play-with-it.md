---
title: "How to install Ansible and play with it"
date: "2017-02-16T09:00:00+01:00"
draft: false
---
Few years ago, I wrote some expect scripts to automatically connect Cisco IOS routers and switches and do some unattended configurations. Now it's time to review those scripts, and check what Ansible can do.

## Installing Ansible

Installing Ansible on a Ubuntu machine is quite easy:

~~~
# apt-get install software-properties-common
# apt-add-repository ppa:ansible/ansible
# apt-get update
# apt-get install ansible
~~~

## Configuring Ansible

Ansible relies on a host file to know which device can be contacted. Let's create a new host file with a test router:

~~~
# cat hosts
[ios]
172.17.0.2
172.17.0.3
~~~

We also need a file with credentials:

~~~
# cat secrets.yaml
---
creds:
  username: eveng
  password: password
~~~

## Using Ansible to check host status (ping)

A first simple command we can use to check if Ansible is working, is the ping module:

~~~
# ansible ios -i hosts -m ping -c local
172.17.0.2 | SUCCESS => {
    "changed": false,
    "ping": "pong"
}
172.17.0.3 | SUCCESS => {
    "changed": false,
    "ping": "pong"
}
~~~

## Single Ansible command to Cisco IOS devices

We need Ansible also for network automation, so we need to check what we can do on, for example, IOS routers:

~~~
# ansible ios -i hosts -u eveng --ask-pass -m raw -c paramiko -a "show ip alias"
SSH password:
172.17.0.3 | SUCCESS | rc=0 >>
Address Type             IP Address      Port
Interface                192.0.2.254

172.17.0.2 | SUCCESS | rc=0 >>

Address Type             IP Address      Port
Interface                192.0.2.254
~~~

Pretty easy, isn't it?

Mind that it's a single command, we cannot go to into configuration mode and type other commands. Se the next post to write a playbook and manage complex configurations.

## References

* [Ansible installation on Ubuntu](https://docs.ansible.com/ansible/intro_installation.html#latest-releases-via-apt-ubuntu "Ansible installation on Ubuntu")
* [My Ansible repository](https://github.com/dainok/rrlabs/tree/master/ansible "[My Ansible repository")
