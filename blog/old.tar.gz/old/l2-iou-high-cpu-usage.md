---
title: "L2 IOU high CPU usage"
date: "2012-09-06T09:00:00+01:00"
draft: false
---
In this post we'll see how to partially fix the high CPU usage while using L2 IOU

L2 IOU 12 causes a lot of CPU usage. Even if iou-web-1.2.0 solve %AMDP2_FE-6-EXCESSCOLL error, L2 IOU causes high CPU usage and can't work properly. The high CPU usage is `System` not `Users`: more debugging shows that L2 IOU causes a lot of loopback traffic.

Loopback traffic can be limited obtaining a L2 IOU usable topology:

~~~
class-map match-all ARP
  match protocol arp

policy-map ARP-limit
  class ARP
   police rate 2 pps burst 20 packets peak-rate 7 pps
     conform-action transmit
     exceed-action drop
     violate-action drop
~~~

On Linux the following line on "/etc/sysctl.conf" file, can help:

~~~
# Mitigate %AMDP2_FE-6-EXCESSCOLL iou error
net.unix.max_dgram_qlen = 2000000
~~~

A reboot or manual set is needed.
