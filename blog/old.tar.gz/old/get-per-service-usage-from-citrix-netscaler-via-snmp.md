---
title: "Get per service usage from Citrix NetScaler via SNMPv3"
date: "2016-05-19T09:00:00+01:00"
draft: false
---
In this post we'll learn how to get per service usage (bytes, requests...) served by a Citrix NetScaler using SNMP from a Linux client.

## Configuring Citrix NetScaler

This post assumes SNMP is already configured on Citrix NetScaler. If not, in short:

* Connecto to the Citrix NetScaler via browser and go to `Configuration -> System -> SNMP`.
* Under `Managers` add a management station; choose `Management Host` if using a hostname (FQDN), choose `Management Network` if using an IP address for both host or networks.
* Under `Views` add a new SNMP View, using `ISO` as `Name` and `1` as `Subtree`.
* Under `Groups` add a new SNMP Group, using `MONITORING` as `Name`, `With Authentication and without Privacy` as `Security Level` and `ISO` as `Read View Name`.
* Under `Users` add a new SNMP User, using `MONITORING` as `Group Name`, `SHA` as `Authentication Type`. Leave blank the `Privacy Type`.

## Testing SNMP from Linux

Before testing you should know how to import external MIBs to a Linux system and test them. Because usually MIBs found around Internet may or may not working fine, I suggest to give a look to my [MIB repository](https://github.com/dainok/rrlabs/tree/master/.snmp/mibs "RRLabs MIB repository").

All Linux SNMP commands check for a MIBDIR environment variable. On my script I prefer a local custom MIB repository:

~~~
client$ export MIBDIRS=/home/andrea/.snmp/mibs
client$ snmpwalk -mALL -v3 -l authNoPriv -a SHA -A password -u user 10.0.0.101 sysName
SNMPv2-MIB::sysName.0 = STRING: NetScaler
~~~

SNMP is correctly configured on Citrix NetScaler and we can get the system name. We'll use the following OIDs:

* NS-ROOT-MIB::vsvrName (`.1.3.6.1.4.1.5951.4.1.3.1.1.1`)
* NS-ROOT-MIB::vsvrIpAddress (`.1.3.6.1.4.1.5951.4.1.3.1.1.2`)
* NS-ROOT-MIB::vsvrPort (`.1.3.6.1.4.1.5951.4.1.3.1.1.3`)
* NS-ROOT-MIB::vsvrType (`.1.3.6.1.4.1.5951.4.1.3.1.1.4`)
* NS-ROOT-MIB::vsvrState (`.1.3.6.1.4.1.5951.4.1.3.1.1.5`)
* NS-ROOT-MIB::vsvrRequestRate (`.1.3.6.1.4.1.5951.4.1.3.1.1.43`)
* NS-ROOT-MIB::vsvrRxBytesRate (`.1.3.6.1.4.1.5951.4.1.3.1.1.44`)
* NS-ROOT-MIB::vsvrTxBytesRate (`.1.3.6.1.4.1.5951.4.1.3.1.1.45`)

We can get all configured services using the first OID:

~~~
scripts$ snmpwalk -mALL -v3 -l authNoPriv -a SHA -A password -u user 10.0.0.101 NS-ROOT-MIB::vsvrName
~~~

Names starting with `IN` followed by 29 alphanumeric chars are internal.
The other services have very long OIDs. The OID parts after `.1.3.6.1.4.1.5951.4.1.3.1.1.1` are specific to the service and can be appended to other OIDs to get other data.

Let's get them all:

~~~
client$ snmpwalk -mALL -v3 -l authNoPriv -a SHA -A password -u user 10.0.0.101 -On NS-ROOT-MIB::vsvrName | egrep -v "IN[A-Za-z0-9]{29}" | sed 's/^.1.3.6.1.4.1.5951.4.1.3.1.1.1//g' | cut -d' ' -f1
~~~

Pick one, save into a var and get others data:

~~~
client$ export SVR=".1.7.7.1.5.4.1.1.1.9.1.9.9.1.1.1.9.9.1.5.5.1.1.9.1.1.1.1.1.1.1.1"
client$ snmpgetnext -Ov -mALL -v3 -l authNoPriv -a SHA -A password -u user 10.0.0.101 NS-ROOT-MIB::vsvrName${SVR} NS-ROOT-MIB::vsvrIpAddress${SVR} NS-ROOT-MIB::vsvrPort${SVR} NS-ROOT-MIB::vsvrType${SVR} NS-ROOT-MIB::vsvrState${SVR} NS-ROOT-MIB::vsvrRequestRate${SVR} NS-ROOT-MIB::vsvrRxBytesRate${SVR} NS-ROOT-MIB::vsvrTxBytesRate${SVR}
STRING: "HTTP-www-80"
IpAddress: 1.1.1.1
INTEGER: 80
INTEGER: http(0)
INTEGER: up(7)
STRING: "0"
STRING: "0"
STRING: "0"
~~~

Now [download a fancy script](https://github.com/dainok/rrlabs/blob/master/scripts/snmp_vsvr_stats.sh "snmp_vsvr_stats.sh") to get a better output:

~~~
client$ ./snmp_vsvr_stats.sh 10.0.0.101 user password
Name,Address,Port,Type,State,Request Rate,RX Bytes Rate,TX Bytes Rate
HTTP-www-80,1.1.1.1,80,http,up,1,690,229
HTTPS-www-443,1.1.1.1,443,sslBridge,up,0,612,535
[...]
~~~

## PRTG

The script is not so good for monitoring, so let's see how to automatically create PRTG sensors. We're using the following API:

* Get the password hash for a specific PRTG account (`/api/getpasshash.htm?username=username&password=password`).
* Get a specific device from an IP address(`/api/table.xml?username=username&passhash=0123456789&content=devices&columns=objid,device,host&output=csvtable&filter_host=1.1.1.1`).
* Get a specific sensor configured within a device (`/api/table.xml?username=username&passhash=0123456789&content=sensor&columns=sensor&output=csvtable&id=1234&filter_name=HTTP-www-80`).
* Duplicate a sensor (`/api/duplicateobject.htm?username=username&passhash=0123456789&id=5678&name=newsensor&targetid=1234`).

The idea is:

* Get all services configured on a Citrix NetScaler
* Check each service if already configured in PRTG
* Add sensors not configured cloning a template service

First you need to add sensor used as template, and be sure you know the sensor ID. All NetScaler monitor will be built using that sensor, so be sure you configure properly what is needed. PRTG does not allow to create a sensor from API.
Second you need to get the password hash for a specific service username:

~~~
client$ curl -s "http://prtg.example.com:8080/api/getpasshash.htm?username=scriptuser&password=scriptpassword"
0123456789
~~~

[Download the script](https://github.com/dainok/rrlabs/blob/master/scripts/prtg_vsvr_stats.sh "prtg_vsvr_stats.sh") and enjoy the PRTG monitoring:

~~~
client$ ./prtg_vsvr_stats.sh prtg.example.com 8080 http scriptuser 0123456789 10.0.0.101 user password 6711
Adding HTTP-www-80 to device ID 5230... done
Adding HTTP-www-443 to device ID 5230... done
[...]
~~~
