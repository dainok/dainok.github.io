---
title: "Adding an interface policy via API on Cisco ACI"
date: "2018-03-21T09:00:00+01:00"
draft: false
---
This post summarizes how to create any interface policy on Cisco ACI using API.


Cisco ACI allows to download any object in different formats (json, xml). That downloaded file can be used as a template to create objects.

Using the GUI navigate to Fabric -&gt; Access Policies -&gt; Interface Policies -&gt; Policies and create, for example a new policy for CDP:

* Name: CDP_on
* Description: Enable CDP
* Admin State: Enabled

Confirm then right click on the CDP_on policy and save it:

* Content: Only configuration
* Scope: Tree
* Export Format: json

Now delete the policy CDP_on from the GUI.

The saved json file will be something like the following:

~~~
{
  "totalCount": "1",
  "imdata": [
    {
      "cdpIfPol": {
        "attributes": {
          "adminSt": "enabled",
          "descr": "Enable CDP",
          "dn": "uni/infra/cdpIfP-CDP_on",
          "name": "CDP_on",
          "nameAlias": "",
          "ownerKey": "",
          "ownerTag": ""
        }
      }
    }
  ]
}
~~~

The important content is:

~~~
{
  "cdpIfPol": {
    "attributes": {
      "adminSt": "enabled",
      "descr": "Enable CDP",
      "dn": "uni/infra/cdpIfP-CDP_on",
      "name": "CDP_on"
    }
  }
}
~~~

Now [login to the APIC using API](/2018/03/login-to-cisco-aci-using-api/ "Login to Cisco ACI using API") and POST the same content:

~~~
curl -c /tmp/cookie -b /tmp/cookie -k -s -X POST -d '{"cdpIfPol":{"attributes":{"adminSt":"enabled","descr":"Enable CDP","dn":"uni/infra/cdpIfP-CDP_on","name":"CDP_on"}}}' -H 'Content-type: application/json' 'https://172.25.82.1/api/mo/uni.json?challenge=557c50785a8a6e759f39f139db86b4cafbaefe0e984305a1173c0cc4396cc474' | python -m json.tool
~~~

## References

* [Cisco APIC REST API Configuration Guide
](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/2-x/rest_cfg/2_1_x/b_Cisco_APIC_REST_API_Configuration_Guide/b_Cisco_APIC_REST_API_Configuration_Guide_chapter_01.html 'Cisco APIC REST API Configuration Guide
')
* [The Cisco ACI Workflow](/2018/03/cisco-aci-workflow/ "The Cisco ACI Workflow")
* [The Cisco ACI script repository](https://github.com/dainok/rrlabs/tree/master/aci "he Cisco ACI script repository")
* [Login to Cisco ACI using API](/2018/03/login-to-cisco-aci-using-api/ "Login to Cisco ACI using API")
