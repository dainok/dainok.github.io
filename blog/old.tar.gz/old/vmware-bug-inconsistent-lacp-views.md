---
title: "VMware bug: inconsistent LACP views"
date: "2014-07-18T09:00:00+01:00"
draft: false
---
There is a bug which makes LACP related views inconsistent. Latest 5.5U1 vCenter is still affected

Create a LAG interface (dvSwitch -> Settings -> LACP):

![add_lag](/images/posts/2014/07/add_lag.png "add_lag")

Now open the "Migrate network traffic to LAGs" and enable lag1 interface as standby port (Manage Distributed Port Groups -> Teaming and failover -> select the port group):

![move_lag1_as_standby](/images/posts/2014/07/move_lag1_as_standby.png "move_lag1_as_standby")

Let the process complete and reopen the same window:

![inconsitent_view1](/images/posts/2014/07/inconsitent_view1.png "inconsitent_view1")

The lag1 interface is still marked as unused.

If lag1 is deleted, an error occur (The resource 'lag1' is in use. Uplink or Link Aggregation group name lag1 is in use by the teaming policy defined at DVPortgroup dvpg-153.):

![error_on_delete](/images/posts/2014/07/error_on_delete.png "error_on_delete")

Now edit settings on the involved port group (dvSwitch -> Distributed Port Groups -> right click on the port group), and select Teaming and failover:

![inconsitent_view2](/images/posts/2014/07/inconsitent_view2.png "inconsitent_view2")

The lag1 interface is marked ad standby. Move it as unused and now the lag1 interface can be deleted.
