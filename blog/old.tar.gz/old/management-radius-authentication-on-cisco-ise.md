---
title: "Management RADIUS authentication on Cisco ISE"
date: "2017-05-22T09:00:00+01:00"
draft: false
---
Configuring RADIUS authentication on Cisco ISE for management access is pretty simple and takes just few minutes.

Login to ISE as administrator, and go to Administration -> External Identity Sources -> Radius Token.
Add a new source:

![Cisco ISE External Identity](/images/posts/2017/05/Cisco-ISE-RADIUS-1.png "Cisco ISE External Identity")

Go now to Administration -> Admin Access -> Admin Users and add all administrator as external user:

![Cisco ISE Admin users](/images/posts/2017/05/Cisco-ISE-RADIUS-2.png "Cisco ISE Admin users")

Remember to set at least one admin group.
