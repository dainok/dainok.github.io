---
title: "Running Wireshark in a jail/sandbox"
date: "2016-12-01T09:00:00+01:00"
draft: false
---
Firejail is a powerful tool which can be use to sandboxing lot of applications. By default Firejail provides profiles for Chrome, Firefox, Telegram and other famous applications. Wireshark is still missing.


We want to limit the interfaces a user can sniff. To be more specific, we want users capture from bridges interfaces only.

## Installing Firejail

On Ubuntu 16.04 Firejail is available universe repository:

~~~
# apt-get -y install firejail
~~~

All profiles are stored under `/etc/firejail/*.profile`.
We can run a `bash` using a generic profile:

~~~
$ firejail --profile=/etc/firejail/generic.profile bash
~~~

## Wireshark under Firejail

Wireshark is a little bit more complicated:

* Wireshark call dumpcap to capture packets without root privileges;
* dumpcap has few capabilities so every user in the `wireshark` group has some advanced privileges:

~~~
# getcap /usr/bin/dumpcap
/usr/bin/dumpcap = cap_net_admin,cap_net_raw+eip
~~~

Let's add a new profile:

~~~
# cat /etc/firejail/wireshark-gtk.profile
# Wireshark profile

private-bin bash,ls,wireshark-gtk,reordercap,dumpcap,editcap,rawshark,mergecap,text2pcap,capinfos
private-dev
private-etc fonts,group,gtk-3.0,hosts,machine-id,wiresharck
private-tmp

noblacklist /bin
noblacklist /dev
noblacklist /etc
noblacklist /home
noblacklist /lib
noblacklist /lib64
noblacklist /sys
noblacklist /tmp
noblacklist /usr
blacklist /*

caps.drop all
netfilter
noroot
seccomp
shell none
~~~

The above profiles:

* maps all `bin` and `sbin` directories importing few binaries;
* maps an almost empty `/dev` directory;
* maps an almost empty `/etc` directory;
* maps an empty `/tmp` directory;
* blacklists (disables) all directories except the one required by Wireshark;
* enforces more the jail.

Users must not be part of the `wireshark` group, or they'll get privileges to captures from any interface.
Now add at least one rule for `sudo`:

~~~
@brcapture ALL=(root) NOPASSWD: /usr/bin/dumpcap -s0 -i br0 -P -w -
~~~

Mind that `dumpcap` can capture from multiple interfaces at the same time, so you should not use the `*` symbol,

From any user in the `brcapture` group you can now capture packets without any risk;

~~~
$ sudo /usr/bin/dumpcap -s0 -i br0 -P -w - | firejail wireshark-gtk -n -k -i -
~~~

![Wireshak inside a jail](/images/posts/2016/12/firejail-1.png "Wireshak inside a jail")

If the user stop the capture from the Wireshark UI and try to start the capture on a different interface, he will get a `You don't have permission to capture on that device` error.
Moreover if the user will try to browse the filesystem, he will get a `Could not read the content` error on most of the directories.

To check what is inside the Wireshark jail, just try to start a `bash` using that profile:

~~~
$ firejail --profile=/etc/firejail/wireshark-gtk.profile bash
~~~

For example you will see an almost empty `/etc`:

~~~
$ ls /etc/
fonts  group  gtk-3.0  hosts  machine-id
~~~

## References

* [Firejail Security Sandbox](https://firejail.wordpress.com/ "Firejail Security Sandbox")
* [Desktop / Laptop privacy & security of web browsers on Linux part 2: firejail based sandboxes](https://www.nexlab.net/2016/08/06/desktop-laptop-privacy-security-of-web-browsers-on-linux-part-2-firejail-based-sandboxes/ "Desktop / Laptop privacy & security of web browsers on Linux part 2: firejail based sandboxes")

