---
title: "Restart DSL connection on a CRC threshold using EEM"
date: "2014-03-06T09:00:00+01:00"
draft: false
---
My Internet connection is cheap enough and a little bit crappy. Cisco provides Embedded Event Manager (EEM), useful to manage a situation like mine:

~~~
event manager applet RESTART_ATM
 event interface name "ATM0" parameter input_errors_crc entry-val 3000 entry-op gt entry-val-is-increment true exit-comb or exit-val 1 exit-op le exit-val-is-increment true exit-time 5 poll-interval 3600 maxrun 10
 action 1.0 cli command "enable"
 action 1.1 cli command "configure terminal"
 action 1.2 cli command "interface ATM0"
 action 1.3 cli command "shutdown"
 action 1.4 cli command "yes"
 action 1.5 cli command "no shutdown"
 action 1.6 cli command "end"
 action 1.7 syslog priority warnings msg "ATM0 restarted by EEM"
~~~

In this case EEM will be triggered when an interface event occurs:

* interface selected is ATM0 (nterface name "ATM0");
* input CRC counter (parameter input_errors_crc) is always incremented (entry-val-is-increment true), so a delta must be analyzed not absolute value: applet starts when counter is incremented by 3000 (entry-val  3000 entry-op gt);
* applet ends immediately:
    * when counter is incremented by less than one unit (exit-val 1 exit-op le exit-val-is-increment true);
    * or (exit-comb or) after 5 seconds (exit-time 5);
* interface counter is polled every hour (poll-interval);
* applet will be killed after 10 seconds (maxrun 10).

When interface is restarted a syslog messages is printed.

~~~
#show log | i EEM
007064: Mar  4 12:11:55.343 CET: %SYS-5-CONFIG_I: Configured from console by  on vty1 (EEM:RESTART_ATM)
007065: Mar  4 12:11:55.395 CET: %HA_EM-4-LOG: RESTART_ATM: ATM0 restarted by EEM
007083: Mar  4 12:16:55.344 CET: %SYS-5-CONFIG_I: Configured from console by  on vty0 (EEM:RESTART_ATM)
007084: Mar  4 12:16:55.396 CET: %HA_EM-4-LOG: RESTART_ATM: ATM0 restarted by EEM
007106: Mar  4 12:21:55.350 CET: %SYS-5-CONFIG_I: Configured from console by  on vty1 (EEM:RESTART_ATM)
007107: Mar  4 12:21:55.402 CET: %HA_EM-4-LOG: RESTART_ATM: ATM0 restarted by EEM
007272: Mar  4 13:29:37.821 CET: %SYS-5-CONFIG_I: Configured from console by  on vty0 (EEM:RESTART_ATM)
007273: Mar  4 13:29:37.873 CET: %HA_EM-4-LOG: RESTART_ATM: ATM0 restarted by EEM
008559: Mar  5 18:29:40.154 CET: %SYS-5-CONFIG_I: Configured from console by  on vty0 (EEM:RESTART_ATM)
008560: Mar  5 18:29:40.230 CET: %HA_EM-4-LOG: RESTART_ATM: ATM0 restarted by EEM
~~~

## References

* [Cisco IOS Embedded Event Manager Command Reference](http://www.cisco.com/c/en/us/td/docs/ios-xml/ios/eem/command/eem-cr-book/eem-cr-e1.html "Cisco IOS Embedded Event Manager Command Reference")
