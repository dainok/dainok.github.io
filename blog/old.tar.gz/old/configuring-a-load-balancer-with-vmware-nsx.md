---
title: "Configuring a load balancer with VMware NSX"
date: "2015-01-19T09:00:00+01:00"
draft: false
---
In this post we'll see how to configure a load balancer on a NSX Edge Router.

## Introduction

In the [previous post]({% post_url 2015-01-19-configuring-nat-and-firewall-on-a-nsx-edge-router %}) a NAT has been configured to allow access from external networks:

![NSX OSPF Topology](/images/posts/2015/01/nsx_ospf_2.png "NSX OSPF Topology")

Now the edge router will act as a load balancer too: connection to the edge router with destination port 2222 will be balanced on both internal VM using the port 22.

Go to "Networking & Security -> NSX Edges", double click over the edge router and go to "Load Balancer -> Application Profiles". Add a new TCP profile:

![Edit Profile](/images/posts/2015/01/nsx_lb-1.png "Edit Profile")

Other options are available when choosing HTTP or HTTPS protocols. Go now to "Pools" and create a new pool with both internal VMs:

![Edit Pool](/images/posts/2015/01/nsx_lb-3.png "Edit Pool")

Go to "Virtual Servers" and add a TCP virtual server bound to the TCP_wo_persistence profile and to the SSH_2222_Pool:

![Edit Virtual Server](/images/posts/2015/01/nsx_lb-2.png "Edit Virtual Server")

Finally go to "Global Configuration" and enable the load balancer:

![Global Configuration](/images/posts/2015/01/nsx_lb-4.png "Global Configuration")

Remind that the firewall must allow connection to the load balancer IP address.

Now SSH connection from external networks to the IP address of the edge router using the port 2222 will be balanced to both VMs using a round-robin algorithm:

~~~
client$ ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -p 2222 ubuntu@172.31.30.21 hostname
ubuntu1
client$ ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -p 2222 ubuntu@172.31.30.21 hostname
ubuntu3
~~~
