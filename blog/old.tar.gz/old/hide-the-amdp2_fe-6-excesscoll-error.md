---
title: "Hide the %AMDP2_FE-6-EXCESSCOLL error"
date: "2013-06-02T09:00:00+01:00"
draft: false
---
The IOU %AMDP2_FE-6-EXCESSCOLL error can be [L2 IOU high CPU usage](http://www.routereflector.com/en/2012/09/l2-iou-high-cpu-usage/ "L2 IOU high CPU usage"). To completely hide that error a user (thank you, Marius) suggests the following configuration on each L2 device:

~~~
logging discriminator EXCESS severity drops 6 msg-body drops EXCESSCOLL
logging buffered 50000
logging console discriminator EXCESS
~~~
