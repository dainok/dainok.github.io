---
title: "Deploying VMware vCenter Operations (vCOPS)"
date: "2014-11-11T09:00:00+01:00"
draft: false
---
Deploying the VMware vCOPS appliance is an easy task with only one prerequisite: IP pool. An IP pool is

> IP pools provide a network identity to vApps. An IP pool is a network configuration that is assigned to a network used by a vApp. The vApp can then leverage vCenter Server to automatically provide an IP configuration to its virtual machines.

In other words an IP pool is a network configuration for vApps. Define an IP pool for the network where vCOPS will be installed. Open the vClient, open the data center, choose the IP Pools tab then add a new IP Pool:

![New IP Pool Properties](/images/posts/2014/11/New-IP-Pool-Properties.png "New IP Pool Properties")


An IP Pool must include subnet and gateway and can include other parameters like DNS, Proxy and so on. See references above for more information on IP Pools.

Now the vCOPS  appliance can be deployed: only two IP addresses will be required for UI and Analytic VM. Other network information will be taken from IP Pool created above.

Start the vApp, point the browser to the UI IP address using https protocol (complete URL is **https://<UI IP Address>/admin/**), and login as **"admin"** (default password is **"admin"**). Now the vCOPS appliance can be configured and bound to the vCenter:

![vcops 1](/images/posts/2014/11/vcops-1.png "vcops 1")

Next step will require to change both admin and root passwords. The default root password is **"vmware"**, but it must be changed before the root login is allowed. If the root account has been locked for many authentication attempts, just login as admin using SSH and unlock the root user:

~~~
$ su -
Password:
Account locked due to 8 failed logins
$ sudo pam_tally2 --user=root --reset
~~~

Now the root password can be set using the web interface.

The next step will require to add a vCenter:

![vcops 2](/images/posts/2014/11/vcops-2.png "vcops 2")

Moreover we want to:

* select the full profile, so all metrics from all registered vCenter Servers are collected;
* set the SMTP server and from settings.

From now users can login using the following URL: **https://<UI IP Address>/vcops-vsphere/**. Custom dashboard can be created using the following URL: **https://<UI IP Address)/vcops-custom/** (Advanced license is required).

## URLs and password summary

* User** "root"**: used for OS management through SSH. Default password is **"vmware"**, login is disabled until password is changed via web interface.
* User** "admin"**: unprivileged  OS user, used also for the first configuration. Default password is **"admin"**.
* Admin Url **"https://<UI IP Address>/admin/"** (use the admin user).
* Dashboard Url **"https://<UI IP Address>/vcops-vsphere/".**
* Custom Dashboard Url: **"https://<UI IP Address)/vcops-custom/".**

## References

* [Understanding and Configuring vSphere IP Pools](http://wahlnetwork.com/2012/12/11/understanding-and-configuring-vsphere-ip-pools/ "Understanding and Configuring vSphere IP Pools")
* [Collecting a subset of vCenter Server metrics in vRealize Operations Manager 5.7](http://kb.vmware.com/selfservice/microsites/search.do?language=en_US&cmd=displayKC&externalId=2049349&src=vmw_so_vex_adain_773 "Collecting a subset of vCenter Server metrics in vRealize Operations Manager 5.7")
