---
title: "Configuration versioning using RANCID"
date: "2013-09-19T09:00:00+01:00"
draft: false
---
RANCID is an open source software developed to save networking device configuration with versioning. RANCID was especially developed for Cisco device, but can be also used with other vendor.

Installation is simple enough:

~~~
yum -y install make gcc expect cvs
~~~

~~~
wget -q -O- ftp://ftp.shrubbery.net/pub/rancid/rancid-2.3.8.tar.gz | tar -xz -C /usr/src/
cd /usr/src/rancid-2.3.8/
./configure --prefix=/opt/rancid
make
make install
~~~

~~~
chown -R rancid:rancid /opt/rancid/
adduser -M -d /opt/rancid rancid
~~~

The software will be installed under /opt/rancid:

* bin: contains all executables;
* etc: contains configuration files;
* share: contains docs and man pages;
* var: will contain the CVS tree where all configurations will be saved.

## Configuration

The main confutation file is rancid.conf which is self-explanatory. The only one line that should be modified is the following:

~~~
LIST_OF_GROUPS="dep1 dep2"
~~~

We want to make a group for each department, but any other configuration can be implemented.
At this point, as rancid user, let's create the CVS repository:

~~~
su - rancid
bin/rancid-cvs
~~~

A repository for each LIST_OF_GROUPS variable will be created.

### Device autentication

Under the rancid home directory the .cloginrc file must be created. This file will contain authentication credential and method needed for login to remote devices:

~~~
add method *.dep1.example.com ssh
add user *.dep1.example.com backup_user
add password *.dep1.example.com {backup_password}
add autoenable *.dep1.exaomple.com 1
~~~

~~~
add user *.dep2.example.com admin
add password *.dep2.example.com {password} {secret}
~~~

The first example describes authentication for all devices under dep1.example.com domain:

* authentication will use SSH protocol;
* the username backup_user has the "enable" privilege.

The second example describes authentication for dep2 devices:

* authentication will use telnet protocol;
* the username admin requires "enable" password.

Permissions of .cloginrc should be restricted:

~~~
chmod 600 /opt/rancid/.cloginrc
chown rancid:rancid /opt/rancid/.cloginrc
~~~

### Notifications

RANCID forwards emails using the local email system. The following aliases should be configured under /etc/aliases also:

~~~
rancid-admin-dep1: noc@example.com
rancid-dep1: noc@dep1.example.com
rancid-admin-dep2: noc@example.com
rancid-dep2: noc@dep1.example.com
[...]
~~~

After adding the aliases, the configuration must be updated:

~~~
newaliases
~~~

### Devices

For each department devices must be added to router.db under /opt/rancid/var. That file contains device IP/hostname, type and status.
Let's add a Cisco device to the dep1 group:

~~~
echo "router.dep1.example.com|cisco|up" >> /opt/rancid/var/dep1/router.db
~~~

RANCID will save get the configuration from router.dep1.example.com using authentication info defined in .cloginrc (see before). The router is defined as cisco device and is in up state. The status is important because deleting a device from router.db file will delete all configuration. An inactive device should be marked as "down" if configuration must be retained.
Many plugins are available for different vendor/type:

~~~
%vendortable = (
    'agm'               => 'agmrancid',
    'alteon'            => 'arancid',
    'arista'            => 'arrancid',
    'avocent'           => 'avorancid',
    'baynet'            => 'brancid',
    'cat5'              => 'cat5rancid',
    'cisco'             => 'rancid',
[...]
    'tnt'               => 'tntrancid',
    'zebra'             => 'zrancid'
);
~~~

### Test

Authentication is the most critical process; it can be tested:

~~~
su - rancid
bin/clogin router.dep1.example.com
~~~

The authentication sequenze will be shown. A complete debug session can be invocated with the following:

~~~
su - rancid
bin/rancid -d router.dep1.example.com
~~~

The complete execution for a group can be invoked:

~~~
su - rancid
bin/rancid-run dep1
~~~

All devices under dep1 group will be saved and logs will be available under /opt/rancid/var/log.

## Automation

The RANCID process can be automated using cron:

~~~
0 */4 * * * /opt/rancid/bin/rancid-run > /dev/null 2>&1
30 * * * * /usr/bin/find /opt/rancid/var/logs -type f -mtime +2 -exec rm {} \;  > /dev/null 2>&1
~~~

The previous example will invoke RANCID every four hours, and log will be cleaned.

## Web Access

Last step makes configurations availalble using a web browser. There are a lot of CVS Web viewer, in this case CVSWeb will be used:

~~~
yum -y install httpd perl-IPC-Run perl-URI rcs
wget -q -O- ftp://ftp.freebsd.org/pub/FreeBSD/ports/local-distfiles/scop/cvsweb-3.0.6.tar.gz | tar -xz -C /usr/src/
mkdir -p /usr/local/etc/cvsweb/ /var/www/html/css/
cp -a /usr/src/cvsweb-3.0.6/cvsweb.cgi /var/www/cgi-bin/
cp -a /usr/src/cvsweb-3.0.6/css/cvsweb.css /var/www/html/css/cvsweb.css
cp -a /usr/src/cvsweb-3.0.6/cvsweb.conf /usr/local/etc/cvsweb/
chmod 755 /var/www/cgi-bin/cvsweb.cgi
~~~

The cvsweb.conf file must be properly configured:

~~~
[...]
@CVSrepositories = (
        'local'   => ['Local Repository', '/var/cvs'],
        'rancid'   => ['RANCID Repository', '/opt/rancid/var/CVS'],
);
[...]
~~~

RANCID repository will be available using the URL http://rancid.example.com/cgi-bin/cvsweb.cgi/?cvsroot=rancid. The Web Server configuration should be properly secured.

## References

* [RANCID - Really Awesome New Cisco confIg Differ](http://www.shrubbery.net/rancid/ "RANCID - Really Awesome New Cisco confIg Differ")
* [Modules for other devices](ftp://ftp.shrubbery.net/pub/rancid/contrib/ "Modules for other devices")
* [Various device types for Rancid](http://www.linuxhomenetworking.com/wiki/index.php/Quick_HOWTO_:_Ch1_:_Network_Backups_With_Rancid#Table_1-2_:_Various_device_types_for_Rancid "Various device types for Rancid")
* [Alteon/Radware/Netscreen Addon](http://www.linkdown.org/en/rancidaddons.html "Alteon/Radware/Netscreen Addon")
