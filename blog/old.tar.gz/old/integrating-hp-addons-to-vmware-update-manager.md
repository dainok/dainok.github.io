---
title: "Integrating HP addons to VMware Update Manager"
date: "2014-11-11T09:00:00+01:00"
draft: false
---
Honestly I don't like customized ISO images for VMware ESXi. I prefer to know what software is installed and how to upgrade it. This short guide will show how to integrate HP addons for VMware in the Update Manager (VUM).

Open the vClient -> Home -> Update Manager -> Download Settings -> Add Download source:

* Source URL: http://vibsdepot.hp.com/index.xml
* Description: HP

The validate the URL and confirm the dialog box:

![Add Download Source](/images/posts/2014/11/Add-Download-Source.png "Add Download Source")

Create another download source:

* Source URL: http://vibsdepot.hp.com/index-drv.xml
* Description: HP Custom Image Drivers

Force the download of the new repository pressing the Download Now button:

![VUM 1](/images/posts/2014/11/VUM-1.png "VUM 1")

From the Baselines and Groups create a new baseline:

* Name: HP agents for ESXi 5.5
* Description: Addons for HP servers.
* Baseline Type: Host Extension
* Extensions to Add:
    * HP Agentless Management Service Bundle (hpq-ams-esxi5.5-bundle)
    * HP Utility Bundle (hpq-utility-esxi5.5-bundle)
    * HP NMI Sourcing module (hpq-esx-5.5.0-hpnmi)
    * HP ESXi Management Bundle (hpq-esxi5.5uX-bundle)

According to the [HP Recipe](http://vibsdepot.hp.com/hpq/recipes/HP-VMware-Recipe.pdf "HP Recipe"), other drivers can be required. The full list for ESXi 5.5 should be the following one:

* HP SmartArray controllers (hpsa, cciss, hpvsa)
* HP Broadcom based networking (tg3)
* HP Brocade based networking (bfa)
* HP Emulex based networking (be2net, elxnet, be2iscsi, lpfc820, lpfc)
* HP Intel based networking (e1000e, igb, ixgbe)
* HP LSI based storage (mpt2sas)
* HP Mellanox based networking (mlx4)
* HP QLogic based networking (qlcnic, nx-nic, qla4xxx, bnx2i, qla2xxx, qlnativefc, bnx2fc
* HP System Management Software
    * HP ESXi Offline Bundle for VMware vSphere (hp-esxi5.5uX-bundle)
    * HP Agentless Management Service Offline Bundle (hp-ams-esxi5.5-bundle)
    * HP ESXi Utilities Offline Bundle (hp-HPUtil-esxi5.5-bundle)
    * HP NMI Sourcing Driver (hp-nmi-esxi5.5-bundle)
* HP SR-IOV Guest OS support (elxnet, ixgbe, bnx2x)

All drivers are available within the **"Device Driver for HP Custom ESXi 5.5.0"** extension.

Finally attach the baseline to a vCenter/Datacenter/Cluster/Host and apply what needed. I suggest to apply ESXi updates/patches before, then extensions. Both patches and extensions cannot be applied on the same job.

## References

* [VMware FW and Software Recipe](http://vibsdepot.hp.com/hpq/recipes/HP-VMware-Recipe.pdf "VMware FW and Software Recipe")
* [Software Delivery Repository * vibsdepot (aka HP Online Depot)](http://vibsdepot.hp.com/ "Software Delivery Repository * vibsdepot (aka HP Online Depot)")
