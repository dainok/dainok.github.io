---
title: "Connecting Edge Router to physical LAN using VMware NSX"
date: "2015-01-15T09:00:00+01:00"
draft: false
---
In this post we'll see how to connect an Edge Router to a physical LAN.

## Introduction

In the [previous post]({% post_url 2015-01-15-configuring-ospf-between-logical-and-edge-routers-on-vmware-nsx %}) an Edge router has been deployed and configured with OSPF.

## Configuring the Edge router

Now the edge router must be connected to external networks:

![NSX OSPF Topology](/images/posts/2015/01/nsx_ospf-2.png "NSX OSPF Topology")

An uplink interface needs to be bound to a PortGroup not configured for NSX. In other words a PortGroup named 172.31.30./27 has been manually added to the same Distributed vSwitch used for NSX:

![Standard PortGroup](/images/posts/2015/01/nsx_bridge_1.png "Standard PortGroup")

Now go to `Networking & Security -> NSX Edges`, double click on the edge and go to `Manage -> Settings -> Interfaces`. Select an available interface and configure it as `Uplink`, bound to the distributed PortGroup created above:

![Edit NSX Edge Interface](/images/posts/2015/01/nsx_bridge_2.png "Edit NSX Edge Interface")

Go now to `Routing -> Global Configuration` and press the Edit button to set the default gateway:

![Edit NSX Edge default gateway](/images/posts/2015/01/nsx_bridge_3.png "Edit NSX Edge default gateway")

Now the edge router can reach the external network 172.31.30.0/27 and will use the 172.31.30.2 as a default gateway. The default gateway will now be redistributed via OSPF.

See the [next post]({% post_url 2015-01-19-configuring-nat-and-firewall-on-a-nsx-edge-router %}) for configuring firewall and bidirectional NAT.
