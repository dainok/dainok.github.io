---
title: "Cisco Champion Data Center"
date: "2013-11-15T09:00:00+01:00"
draft: false
---
I had always been extremely passionate about Data Center technologies. When Cisco started the UCS project, I realized that my approach won't be never the same: Cisco vision is a step beyond.

I'm not affirming that all Cisco products are the best, I'm just saying that I love Cisco wide vision, and yes, I love many Cisco products. The reason is quite simple: Cisco simplify my day-by-day job. Also VMware, NetApp and Linux do, and I love them too.

![cisco_champions BADGE_200x200](/images/posts/2013/11/cisco_champions-BADGE_200x200.png "cisco_champions BADGE_200x200")

And I'm proud to be a [Cisco Champions](http://www.cisco.com/web/about/facts_info/champions.html "Cisco Champions").
