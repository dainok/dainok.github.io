---
title: "Draggable Cisco ACI Workflow"
date: "2018-03-25T09:00:00+01:00"
draft: false
---
The diagram is available from [Web Archive](https://web.archive.org/web/20180730144438/http://www.routereflector.com/2018/03/draggable-cisco-aci-workflow#main "Web Archive").
