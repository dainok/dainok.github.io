---
title: "Network ping with delay, jitter and MOS"
date: "2014-08-06T09:00:00+01:00"
draft: false
---
I found a Python [ping.py &ndash; Python Implementation of the ping command](http://www.g-loaded.eu/2009/10/30/python-ping/ "ping.py &ndash; Python Implementation of the ping command") to ping a remote system. I added a very short piece of code to print out Jitter and MOS data.

~~~
# ./ping.py -c 1000 -t 1 -d 8.8.8.8
Statistics for 8.8.8.8:
 - packet loss: 2 (0.20%)
 - latency (MIN/MAX/AVG): 46/281/52
 - jitter: 2.1583
 - MOS: 4.3
~~~

A Nagios compatible output is available:

~~~
# ./ping.py -c 1000 -t 1 -d 8.8.8.8 -o nagios
OK | lost=0.10 delay=51;75;100;0;1000 jitter=2.94 mos=4.3;4.0;3.0;0.0;5.0
~~~

Because MOS should be applied to VoIP packets only, the MOS output is an estimate of a VoIP call using the G.711 codec.

The script (and libs) can be downloaded from the [ping.py](http://www.routereflector.com/public/nagios/ping.tar.gz "ping.py").

## References:

* [A ping.py version with Delay, Jitter and MOS data](http://www.routereflector.com/public/nagios/ping.tar.gz "A ping.py version with Delay, Jitter and MOS data")
* [ping.py &ndash; Python Implementation of the ping command](http://www.g-loaded.eu/2009/10/30/python-ping/ "ping.py &ndash; Python Implementation of the ping command")
* [The previous ping.py version (by Jens Diemer)](http://www.python-forum.de/post-69122.html#69122 "The previous ping.py version (by Jens Diemer)")
* [The original ping.py version by (Dixon Cowles)](ftp://ftp.visi.com/users/mdc/ping.py "The original ping.py version by (Dixon Cowles)")
