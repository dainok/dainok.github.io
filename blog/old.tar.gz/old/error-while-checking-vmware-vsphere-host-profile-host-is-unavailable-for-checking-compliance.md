---
title: "Error while checking VMware vSphere Host Profile ('Host is unavailable for checking compliance.')"
date: "2013-11-05T09:00:00+01:00"
draft: false
---
After a major vSphere upgrade (from 4.1 to 5.1) host profiling does not work anymore. The error is "Host is unavailable for checking compliance.".

The solution is simple: update reference host again (right click over the incriminated profile).

![HostProfile](/images/posts/2013/11/HostProfile.jpg "HostProfile")
