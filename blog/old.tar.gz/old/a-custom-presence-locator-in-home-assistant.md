---
title: "A custom presence locator in Home Assistant"
date: "2016-10-28T09:00:00+01:00"
draft: false
---
This post will show how to configure a custom presence locator in Home Assistant using GPSLogger and a personal server.

Presence service based on mobile phones in Home Assistant is now available using Owntracks or Locative. Owntracks works enough, but it's too much battery consuming. Locative simply does not fit my needs.

I found another simple Android application for GPS trackinig: GPSLogger. Every Android device, with geolocation feature enabled, tracks itself using GPS sensors or WiFi networks. Installing another GPS app will lead to battery drain for sure unless it will use cached data.

GPSLogger can use multiple source: the passive one just get the latest Android known location, without activating GPS sensors or scanning for WiFi networks.

On my mobile phone, GPSLogger is using about 4% of battery so it's the best tool in my opinion.

## Installing the GPSLogger patch

I developed a [small patch](https://github.com/home-assistant/home-assistant/pull/4089 "Support for GPSLogger platform") for Home Assistant, and  it has been included in the offical repo.

## Configuring Home Assistant

Check [the old post](/2016/10/configuring-presence-locator-in-home-assistant/ "Configuring presence locator in Home Assistant") and configures zones and automation.

Configure presence using GPSLogger:

~~~
device_tracker:
    * platform: gpslogger
~~~

MQTT configuration and daemon can be removed.

## Configuring GPSLogger on Android

Install [Logger GPS per Android](https://play.google.com/store/apps/details?id=com.mendhak.gpslogger "Logger GPS per Android") and configure it like the following:

* General Options:
	* Start on boot: yes
	* Start on app launch: yes
	* Display Imperial units: as you wish
	* Hide notification buttons: yes
	* Enable/Disable GPS: yes
	* Write to debug file: no
* Logging details:
	* Log to GPX: no
	* Log to KML: no
	* Log to custom URL: yes and set `https://username:password@example.moo.com/api/gpslogger?latitude=%LAT&longitude=%LON&battery=%BATT&device=%SER&accuracy=%ACC`
	* Log to OpenGTS Server: no
	* Log to Plain Text: no
	* Log to NMEA: no
	* Performance:
		* Location providers:
			* GPS: no
			* Network: no
			* Passive: yes
		* Time before logging: 60
		* Keep GPS on between fixes: no
		* Distance filter: 0
		* Accuracy Filter: 40
		* Retry time interval for accuracy filter: 60
		* Absolute Timeout: 3

Custom URL can also use API password, just add it to the URL (remember I prefer another security type, and check my [previous post](/2016/10/exposing-home-assistant-in-a-secure-way/ "Exposing Home Assistant in a secure-way")).

Start logging, check your `known_devices.yaml` file and enjoy your light location service.

## References

* [Logger GPS per Android](https://play.google.com/store/apps/details?id=com.mendhak.gpslogger "Logger GPS per Android")
* [Home Assistant - Owntracks](https://home-assistant.io/components/device_tracker.owntracks/ "Home Assistant - Owntracks")
* [Home Assistant - Locative](https://home-assistant.io/components/device_tracker.locative/ "Home Assistant - Locative")
* [Home Assistant - GPSLogger patch](https://github.com/home-assistant/home-assistant/pull/4089 "Home Assistant * GPSLogger patch")
