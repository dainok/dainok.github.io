---
title: "Login to Cisco ACI using API"
date: "2018-03-19T09:00:00+01:00"
draft: false
---
This post summarizes how to login to a Cisco ACI fabric using API via curl.

## Login

The login process set a cookie and give a token. Both are needed to send other API requests:

~~~
# curl -c /tmp/cookie -b /tmp/cookie -k -s -X POST -d '{"aaaUser":{"attributes":{"name":"admin","pwd":"password"}}}' -H 'Content-type: application/json' 'https://172.25.82.1/api/aaaLogin.json?gui-token-request=yes' | python -m json.tool | grep urlToken
~~~

## Refresh

A refresh is used to reset the session timer:

~~~
# curl -c /tmp/cookie -b /tmp/cookie -k -s -X GET 'https://172.25.82.1/api/class/aaaUser.json?challenge=557c50785a8a6e759f39f139db86b4cafbaefe0e984305a1173c0cc4396cc474' | python -m json.tool
~~~

Default session timer is 300 seconds.

## Logout

Logout ends a session but doesn't delete the token:

~~~
# curl -c /tmp/cookie -b /tmp/cookie -k -s -X POST -d '{"aaaUser":{"attributes":{"name":"admin"}}}' -H 'Content-type: application/json' 'https://172.25.82.1/api/aaaLogout.json?challenge=557c50785a8a6e759f39f139db86b4cafbaefe0e984305a1173c0cc4396cc474' | python -m json.tool
~~~

## References

* [Cisco APIC REST API Configuration Guide
](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/2-x/rest_cfg/2_1_x/b_Cisco_APIC_REST_API_Configuration_Guide/b_Cisco_APIC_REST_API_Configuration_Guide_chapter_01.html 'Cisco APIC REST API Configuration Guide
')
* [The Cisco ACI Workflow](/2018/03/cisco-aci-workflow/ "The Cisco ACI Workflow")
* [The Cisco ACI script repository](https://github.com/dainok/rrlabs/tree/master/aci "he Cisco ACI script repository")
