---
title: "Compiling QEMU on VMware Photon OS"
date: "2016-11-15T09:00:00+01:00"
draft: false
---
VMware Photon OS is a light stripped Linux VM suitable for Docker and cloud apps.

Because Photon OS comes with very few available software, it's useful know how to compile additional software. This document will use Docker.

## Prepare a Docker environment

This document won't cover how to install Docker, but on many Linux distributions a single command is enough:

~~~
# curl -sSL https://get.docker.com/ | sh
~~~

Download the VMware Photon OS image for Docker:

~~~
# docker pull vmware/photon
~~~

Photon OS is now available for Docker:

~~~
# docker images
vmware/photon       latest              84681184df2e        5 months ago        127.5 MB
~~~

Finally start a new Docker instance:

~~~
# docker run -ti  vmware/photon:latest /bin/bash
~~~

## Installing the required software

Once the Photon OS instance is started, some additional software must be downloaded:

~~~
# tdnf -y install autoconf automake binutils diffutils gawk gcc glib-devel glibc-devel gzip libtool linux-api-headers make ncurses-devel sed tar util-linux-devel zlib-devel
~~~

Download and unpack QEMU:

~~~
# mkdir /usr/src
# curl -s http://wiki.qemu-project.org/download/qemu-2.7.0.tar.bz2 | tar -xj -C /usr/src
# cd cd /usr/src/qemu-2.7.0/
~~~

Compile and install it:

~~~
# ./configure --prefix=/usr/local --sysconfdir=/etc --target-list="x86_64-softmmu" --enable-vnc --disable-xen --enable-curses --enable-kvm --enable-uuid --audio-drv-list="alsa oss"
# make
# make install
~~~

QEMU is now installed into `/usr/local`.

## Building via Dockerfile

A simple Dockerfile could automate the entire process:

~~~
FROM vmware/photon:latest
MAINTAINER Andrea Dainese <andrea.dainese@gmail.com>

# Installing dependencies
RUN tdnf -y install autoconf automake binutils diffutils gawk gcc glib-devel glibc-devel gzip libtool linux-api-headers make ncurses-devel sed tar util-linux-devel zlib-devel &> /dev/null || exit 1
RUN mkdir /usr/src/ || exit 1

# Installing QEMU
RUN curl -s http://wiki.qemu-project.org/download/qemu-2.7.0.tar.bz2 | tar -xj -C /usr/src || exit 1
WORKDIR "/usr/src/qemu-2.7.0/"
RUN ./configure --prefix=/usr/local --target-list="x86_64-softmmu" --enable-vnc --disable-xen --enable-curses --enable-kvm --audio-drv-list="oss" --enable-uuid &> /dev/null || exit 1
RUN make &> /dev/null || exit 1
RUN make install &> /dev/null || exit 1

# Cleaning
WORKDIR "/root/"
RUN rm -rf /usr/src/ &> /dev/null || exit 1
RUN tdnf -y erase autoconf automake gcc gdbm glibc-devel glib-devel libgcc-devel libgomp-devel libstdc++-devel linux-api-headers m4 make ncurses-devel pcre-devel perl python2 python2-libs util-linux-devel zlib-devel &> /dev/null || exit 1
RUN tdnf clean all &> /dev/null || exit 1
RUN history -c &> /dev/null || exit 1
~~~

Build it using:

~~~
# docker build -t rrlabs/qemu -f Dockerfile .
~~~

And start a container using:

~~~
# docker run -t -i rrlabs/qemu /bin/bash
~~~

## References

* [Install Docker Engine](https://docs.docker.com/engine/installation/ "Install Docker Engine")
