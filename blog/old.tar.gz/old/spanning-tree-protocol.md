---
title: "STP"
date: "2013-05-27T09:00:00+01:00"
draft: false
---
The Spanning Tree Protocol is used to avoid L2 loops withing the same Ethernet broadcast domain. STP is needed because frames do not have Time To Live (TTL): if a loop is formed, frames will continue to flow between switches, which multiply them over and over until a network collapse.
Because a link between switches must be redundant, a mechanism is needed to temporary disable all paths but one: this is the purpose of STP.

There are many STP protocols:

* STP: Spanning Tree Protocol (802.1d), defined for simple networks with only one VLAN (802.1q was not developed yet). STP is also known as MST or Mono Spanning Tree (rarely used).
* PVST: Per VLAN Spanning Tree (Cisco), defined by Cisco to enhance 802.1d and support multiple VLANs on ISL trunks.
* CST: Common Spanning Tree (802.1q), defined for networks with more than one VLAN (and with 802.1q trunks), a single (common) instance configure just one topology for all VLANs.
* PVST+: Per VLAN Spanning Tree Plus (Cisco), enhance PVST to support 802.1q trunks. PVST is the default STP on Cisco Catalyst switches and it is compatible with CST.
* RSTP: Rapid Spanning Tree (802.1W), enhance STP reducing convergence time. It is compatible with STP.
* RPVST+: Rapid Per VLAN Spanning Tree Plus (Cisco), enhance PVST+ reducing convergence time. It is compatible with RSTP and it is a default on Cisco Nexus switches.
* MST: Multiple Spanning Tree (Cisco), is a 802.1s pre-standard.
* MIST: Multiple Instance Spanning Tree (802.1s), uses RSTP.

Cisco Catalyst switches allows only 3 out of 7 discussed protocols:

* pvst: it configures PVST+ (with 802.1q support), compatible with PVST, STP e CST.
* rapid-pvst: compatible with RSTP.
* mst: standard and pre-standard.

## References

* [Spanning Tree Protocol](http://en.wikipedia.org/wiki/Spanning_Tree_Protocol "Spanning Tree Protocol")
* [Overview of STP family](http://www.cisco.com/en/US/tech/tk389/tk621/tsd_technology_support_protocol_home.html "Overview of STP family")
* [Differences between PVST and PVST+](http://cciethebeginning.wordpress.com/2008/10/15/differences-between-pvst-and-pvst/ "Differences between PVST and PVST+")
