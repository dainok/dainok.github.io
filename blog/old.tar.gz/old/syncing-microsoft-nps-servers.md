---
title: "Synching Microsoft NPS (RADIUS) servers"
date: "2016-07-04T09:00:00+01:00"
draft: false
---
In this post we'll see a short PowerShell script to synch remote Microsoft NPS (RADIUS) server configuration.

## How it works

The script should be self-explanatory, but here a short description about how it works:

1. Backup the local NPS configuration.
2. Retrieve all available NPS servers.
3. Backup each remote NPS server and push to it the configuration.

## The script

~~~
Export-NpsConfiguration -Path C:\TEMP\LocalNPSExportedConfig.xml

$CurrentServerNPS = $env:computername

$NPServers = Get-ADGroupMember "RAS and IAS Servers"
$NPServers | ForEach-Object {

	$NPServerName = $_.Name

	if ($NPServerName -ne $CurrentServerNPS) {
		$NPServerName
		copy-item Export-NpsConfiguration -Path  \\$NPServerName\C$\TEMP\LocalNPSExportedConfig.xml
		Invoke-Command -ComputerName $NPServerName -ScriptBlock {Export-NPSConfiguration -Path C:\TEMP\BackupNPSExportedConfig.xml
		Invoke-Command -ComputerName $NPServerName -ScriptBlock {Import-NPSConfiguration -Path C:\TEMP\LocalNPSExportedConfig.xml
	}
}
~~~

## References

* [Michele Sensalari](https://www.linkedin.com/in/michele-sensalari-4988b7 "Michele Sensalari")
* [nps_sync script](https://github.com/dainok/rrlabs/blob/master/scripts/nps_sync.ps1 "NPS Sync Script")
