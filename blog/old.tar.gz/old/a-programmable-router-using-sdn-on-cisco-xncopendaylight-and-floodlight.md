---
title: "A programmable router using SDN on Cisco XNC/OpenDaylight and Floodlight"
date: "2013-11-13T09:00:00+01:00"
draft: false
---
This post will show how to implement L3 routing inside an SDN switch.

![single](/images/posts/2013/11/single.png "single")

H1 and H2 are hosts placed on different networks, H3 acts as a fake router:

* H1: ip 192.168.1.1/24, mac 00:00:00:00:00:01, gateway 192.168.1.254
* H2: ip 192.168.2.2/24, mac 00:00:00:00:00:02, gateway 192.168.2.254
* H3: ip 192.168.1.254/24 192.168.2.254/24, mac 00:00:00:00:00:03

The MiniNet must be started with the "--mac" flag, and hosts inside must be configured as following:
~~~
mininet> h1 ifconfig h1-eth0 192.168.1.1 netmask 255.255.255.0
mininet> h1 route add default gw 192.168.1.254

mininet> h2 ifconfig h2-eth0 192.168.2.2 netmask 255.255.255.0
mininet> h2 route add default gw 192.168.2.254

mininet> h3 ifconfig h3-eth0:1 192.168.1.254
mininet> h3 ifconfig h3-eth0:2 192.168.2.254
~~~
Here the data flow between H1, H2 and H3 when H1 wants to reach H2:
<ol>
* because H1 and H2 resides on diffenret networks, H1 asks for default gateway's MAC Address using an ARP query with broadcast destination;
* H3 answers to H1 with his own MAC Address
* H1 encapsulates data usding H2's destination IP address and H3's MAC Address
* H3 receives H1 packet, rewrites destination MAC Address using H2 ones (after an ARP request), and send data to H2
* H2 answers to H1 following the same, inverted process
</ol>
Then four flows must be configured:

* ARP must be enabled
* prerouted data from H1 (MAC source 00:00:00:00:00:01) to H2 (destination ip 192.168.2.2 and destination MAC 00:00:00:00:00:03) must be redirected to H2 with the H2's MAC address;
* prerouted data from H2 (MAC source 00:00:00:00:00:02) to H1 (destination ip 192.168.1.1 and destination MAC 00:00:00:00:00:03) must be redirected to H1 with the H1's MAC address;
* all traffic to H3's MAC address must be dropped: H3 is a fake router, useful for ARP answers only.

## Programming a router using MiniNet
MiniNet is the test platform for SDN applications, but can be also used as a simple controller.
Let's start the MiniNet lab with the above topology:
~~~
sudo mn --topo=single,3 --mac
~~~
Let's configure the four flows:
~~~
mininet> dpctl add-flow arp,actions=flood
mininet> dpctl add-flow ip,dl_src=00:00:00:00:00:01,dl_dst=00:00:00:00:00:03,nw_dst=192.168.2.2,actions=mod_dl_dst:00:00:00:00:00:02,output:2
mininet> dpctl add-flow ip,dl_src=00:00:00:00:00:02,dl_dst=00:00:00:00:00:03,nw_dst=192.168.1.1,actions=mod_dl_dst:00:00:00:00:00:01,output:1
mininet> dpctl add-flow dl_dst=00:00:00:00:00:03,actions=drop
mininet> dpctl dump-flows
*** s1 ------------------------------------------------------------------------
NXST_FLOW reply (xid=0x4):
 cookie=0x0, duration=7.191s, table=0, n_packets=0, n_bytes=0, idle_age=7, ip,dl_src=00:00:00:00:00:02,dl_dst=00:00:00:00:00:03,nw_dst=192.168.1.1 actions=mod_dl_dst:00:00:00:00:00:01,output:1
 cookie=0x0, duration=11.103s, table=0, n_packets=0, n_bytes=0, idle_age=11, ip,dl_src=00:00:00:00:00:01,dl_dst=00:00:00:00:00:03,nw_dst=192.168.2.2 actions=mod_dl_dst:00:00:00:00:00:02,output:2
 cookie=0x0, duration=14.712s, table=0, n_packets=0, n_bytes=0, idle_age=14, arp actions=FLOOD
 cookie=0x0, duration=3.296s, table=0, n_packets=0, n_bytes=0, idle_age=3, dl_dst=00:00:00:00:00:03 actions=drop
~~~
The operation order is important in OpenFlow 1.0: MAC bust me rewritten before the output action.
Now H1 can ping H2:
~~~
mininet> h1 ping -c1 192.168.2.2
PING 192.168.2.2 (192.168.2.2) 56(84) bytes of data.
64 bytes from 192.168.2.2: icmp_req=1 ttl=64 time=0.787 ms

--- 192.168.2.2 ping statistics ---
1 packets transmitted, 1 received, 0% packet loss, time 0ms
rtt min/avg/max/mdev = 0.787/0.787/0.787/0.000 ms
~~~
Using the above config, there is no host isolation: 192.168.1.0/24 and 192.168.2.0/24 are not isolated. In other words if H4 host is added, and configured with both 192.168.1.4 and 192.168.2.4, it will be able to reach both H1 and H2 directly.
## Programming a router using Cisco XNC/OpenDaylight
Let's start the MiniNet lab connected to the Cisco XNC controller (or OpenDaylight) with the above topology:
~~~
sudo mn --controller=remote,ip=192.168.32.129 --topo=single,3 --mac
~~~
Let's go to Flows -> Add Flow Entry and create four flows with the following parameters:

* Name: arp, Node: OF|00:00:00:00:00:00:00:01, Ethernet Type: 0x806, Actions: Flood
* Name: flow1to2, Node: OF|00:00:00:00:00:00:00:01, Ethernet Type: 0x800, Source MAC Address: 00:00:00:00:00:01, Destination MAC Address: 00:00:00:00:00:03, Destination IP Address: 192.168.2.2, Destination MAC: 00:00:00:00:00:02, Add Output Ports: s1-eth2(2)
* Name: flow2to1, Node: OF|00:00:00:00:00:00:00:01, Ethernet Type: 0x800, Source MAC Address: 00:00:00:00:00:02, Destination MAC Address: 00:00:00:00:00:03, Destination IP Address: 192.168.1.1, Destination MAC: 00:00:00:00:00:01, Add Output Ports: s1-eth1(1)
* Name: drop3, Node: OF|00:00:00:00:00:00:00:01, Destination MAC Address: 00:00:00:00:00:03, Actions: Drop

~~~
mininet> dpctl add-flow arp,actions=flood
mininet> dpctl add-flow ip,dl_src=00:00:00:00:00:01,dl_dst=00:00:00:00:00:03,nw_dst=192.168.2.2,actions=mod_dl_dst:00:00:00:00:00:02,output:2
mininet> dpctl add-flow ip,dl_src=00:00:00:00:00:02,dl_dst=00:00:00:00:00:03,nw_dst=192.168.1.1,actions=mod_dl_dst:00:00:00:00:00:01,output:1
mininet> dpctl add-flow dl_dst=00:00:00:00:00:03,actions=drop
mininet> dpctl dump-flows
*** s1 ------------------------------------------------------------------------
NXST_FLOW reply (xid=0x4):
 cookie=0x0, duration=104.658s, table=0, n_packets=0, n_bytes=0, idle_age=104, priority=500,ip,dl_src=00:00:00:00:00:02,dl_dst=00:00:00:00:00:03,nw_dst=192.168.1.1 actions=mod_dl_dst:00:00:00:00:00:01,output:1
 cookie=0x0, duration=176.982s, table=0, n_packets=0, n_bytes=0, idle_age=176, priority=500,ip,dl_src=00:00:00:00:00:01,dl_dst=00:00:00:00:00:03,nw_dst=192.168.2.2 actions=mod_dl_dst:00:00:00:00:00:02,output:2
 cookie=0x0, duration=335.036s, table=0, n_packets=0, n_bytes=0, idle_age=335, priority=500,arp actions=FLOOD
 cookie=0x0, duration=27.682s, table=0, n_packets=0, n_bytes=0, idle_age=27, priority=500,ip,dl_dst=00:00:00:00:00:03 actions=drop
~~~
And again H1 can ping H2:
~~~
mininet> h1 ping -c 1 192.168.2.2
PING 192.168.2.2 (192.168.2.2) 56(84) bytes of data.
64 bytes from 192.168.2.2: icmp_req=1 ttl=64 time=0.048 ms

--- 192.168.2.2 ping statistics ---
1 packets transmitted, 1 received, 0% packet loss, time 0ms
rtt min/avg/max/mdev = 0.048/0.048/0.048/0.000 ms
~~~

## Programming a router using Floodlight

Let&rsquo;s start the MiniNet lab connected to the Floodlight controller with the above topology:

~~~
sudo mn --controller=remote,ip=192.168.32.129 --topo=single,3 --mac
~~~

Floodlight must be programmed via API/curl:

~~~
curl -d '{"switch":"00:00:00:00:00:00:00:01", "name":"arp", "ether-type":"0x0806", "actions":"output=flood"}' http://127.0.0.1:8080/wm/staticflowentrypusher/json
curl -d '{"switch":"00:00:00:00:00:00:00:01", "name":"flow-12", "ether-type":"0x0800", "src-mac": "00:00:00:00:00:01", "dst-mac": "00:00:00:00:00:03", "dst-ip": "192.168.2.2", "actions":"set-dst-mac=00:00:00:00:00:02,output=2"}' http://127.0.0.1:8080/wm/staticflowentrypusher/json
curl -d '{"switch":"00:00:00:00:00:00:00:01", "name":"flow-21", "ether-type":"0x0800", "src-mac": "00:00:00:00:00:02", "dst-mac": "00:00:00:00:00:03", "dst-ip": "192.168.1.1", "actions":"set-dst-mac=00:00:00:00:00:01,output=1"}' http://127.0.0.1:8080/wm/staticflowentrypusher/json
curl -d '{"switch":"00:00:00:00:00:00:00:01", "name":"drop3", "dst-mac": "00:00:00:00:00:03", "actions":"output=drop"}' http://127.0.0.1:8080/wm/staticflowentrypusher/json
~~~

And once again H1 can ping H2:

~~~
mininet> dpctl dump-flows
*** s1 ------------------------------------------------------------------------
NXST_FLOW reply (xid=0x4):
 cookie=0xffffffffdbbe776f, duration=2.62s, table=0, n_packets=0, n_bytes=0, idle_age=2, priority=32767,ip,dl_src=00:00:00:00:00:02,dl_dst=00:00:00:00:00:03,nw_dst=192.168.1.1 actions=mod_dl_dst:00:00:00:00:00:01,output:1
 cookie=0xffffffffdbbe769d, duration=2.633s, table=0, n_packets=0, n_bytes=0, idle_age=2, priority=32767,ip,dl_src=00:00:00:00:00:01,dl_dst=00:00:00:00:00:03,nw_dst=192.168.2.2 actions=mod_dl_dst:00:00:00:00:00:02,output:2
 cookie=0xa000000e3d07fc, duration=2.65s, table=0, n_packets=0, n_bytes=0, idle_age=2, priority=32767,arp actions=FLOOD
 cookie=0xffffffff965f7929, duration=2.114s, table=0, n_packets=0, n_bytes=0, idle_age=2, priority=32767,dl_dst=00:00:00:00:00:03 actions=drop
~~~

## References

* [MiniNet as an SDN test platform](http://www.routereflector.com/en/2013/11/mininet-as-an-sdn-test-platform/ "MiniNet as an SDN test platform")
* [OpenDaylight as an SDN controller: overview and installation](http://www.routereflector.com/en/2013/11/opendaylight-as-an-sdn-controller-overview-and-installation/ "OpenDaylight as an SDN controller: overview and installation")
* [Cisco Extensible Network Controller (XNC): overview and installation](http://www.routereflector.com/en/2013/10/cisco-extensible-network-controller-xnc-overview-and-installation/ "Cisco Extensible Network Controller (XNC): overview and installation")
* [Floodlight SDN controller: overview and installation](http://www.routereflector.com/en/2013/11/floodlight-sdn-controller-overview-and-installation/ "Floodlight SDN controller: overview and installation")
* [Floodlight Static Flow Pusher API](http://docs.projectfloodlight.org/display/floodlightcontroller/Static+Flow+Pusher+API "Floodlight Static Flow Pusher API")
