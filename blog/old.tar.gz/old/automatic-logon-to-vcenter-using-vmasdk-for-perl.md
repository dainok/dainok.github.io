---
title: "Automatic logon to vCenter using vMA/SDK for Perl"
date: "2014-11-11T09:00:00+01:00"
draft: false
---
One of the most useful appliance for vSphere administration is a Linux based VM called vMA (vSphere Management Assistant ). It's a simple SUSE Linux installation with the vSphere SDK for Perl installed.

Both method will provide useful tools like esxcli, vmkfstools, vicfg-* and so on. Each command can read credentials as parameters:

~~~
$ esxcli --server vcenter.example.com --username example\\vsphereadmin --password vspherepassword --vihost esxi01.example.com system version get
   Product: VMware ESXi
   Version: 5.1.0
   Build: Releasebuild-2000251
   Update: 2
~~~

Or credentials can be read from stdin:

~~~
$ esxcli --server vcenter.example.com --vihost esxi01.example.com system version get
Enter username: example\vsphereadmin
Enter password:
   Product: VMware ESXi
   Version: 5.1.0
   Build: Releasebuild-2000251
   Update: 2
~~~

There are to better method to login. The first one read username, password and vcenter hostname parameters from environment:

~~~
export VI_USERNAME=example\vsphereadmin
export VI_PASSWORD=vspherepassword
export VI_SERVER=vcenter.example.com
esxcli --vihost esxi01.example.com system version get
   Product: VMware ESXi
   Version: 5.1.0
   Build: Releasebuild-2000251
   Update: 2
~~~

The second and suggested method allow to store credentials to a XML file:

~~~
$ /usr/lib/vmware-vcli/apps/general/credstore_admin.pl add --server vcenter.example.com --username example\\vsphereadmin --password vspherepassword
New entry added successfully
~~~

Multiple credentials can be stored:

~~~
$ /usr/lib/vmware-vcli/apps/general/credstore_admin.pl add --server vcenterdr.example.com --username example\\vsphereadmin --password vspherepassword
New entry added successfully
~~~

On Linux the credential file is stored as ~/.vmware/credstore/vicredentials.xml. Passwords are encrypted.

~~~
$ esxcli --server vcenter.example.com --vihost esxi01.example.com system version get
   Product: VMware ESXi
   Version: 5.1.0
   Build: Releasebuild-2000251
   Update: 2
~~~

## Example

A quick example to automate a mount of a NFS datastore on a ten host farm can be the following:

~~~
for i in $(seq --format="%02g" 01 10); do
  echo esxi${i}.example.com
  esxcli --server vcenter.example.com --vihost esxi${i}.example.com storage nfs add --host nas01.example.com --volume-name=NETAPP_T1_SHARE --share=/vol/NETAPP_T1_SHARE
done
~~~

## References

* [vSphere Management Assistant Documentation](https://www.vmware.com/support/developer/vima/ "vSphere Management Assistant Documentation")
* [vSphere SDK for Perl Documentation](https://www.vmware.com/support/developer/viperltoolkit/ "vSphere SDK for Perl Documentation")
