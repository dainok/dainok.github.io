---
title: "Configuring RADIUS authentication on Cisco Virtual WLC (vWLC)"
date: "2016-02-24T09:00:00+01:00"
draft: false
---
On enterprise networks, a central authentication is mandatory for accessing network devices.

## Cisco Virtual WLC configuration

Both WiFi users and management users are authenticated against the same RADIUS servers. Under `Security` -> `AAA` -> `RADIUS` -> `Authentication`, be sure:

* Auth Called Station ID Type: `IP Address`
* MAC Delimiter: `Colon`

![Cisco WLC RADIUS servers](/images/posts/2016/02/vWLC-RADIUS-1.png "Cisco WLC RADIUS servers")

Add all RADIUS server as following:

![Cisco WLC RADIUS server](/images/posts/2016/02/vWLC-RADIUS-2.png "Cisco WLC RADIUS server")

In the current scenario both `Network User` and `Management` are set, because RADIUS servers provide both WiFi (network) and management authentication.
So be sure your settings reflect your sceario.

Moreover on each WLAN, NAS-ID has been customized to reflect the SSID used by clients. Configure them under `WLAN` -> SSID -> `General` -> `NAS-ID`:

![Cisco WLC WLAN](/images/posts/2016/02/vWLC-RADIUS-3.png "Cisco WLC WLAN")

The `NAS-ID` will became useful during RADIUS configuration.

Go back to `Security` -> `AAA` -> `RADIUS` -> `Fallback` and set `passive` as fallback mode, to manage temporary RADIUS downtime:

![Cisco WLC RADIUS Fallback](/images/posts/2016/02/vWLC-RADIUS-4.png "Cisco WLC RADIUS Fallback")

Finally set `RADIUS` then `LOCAL` as authentication method in this exact order, to avoid local configured users to bypass RADIUS authentication. Configure it under `Security` -> `Priority Order` -> `Management User`:

![Cisco WLC authentication order](/images/posts/2016/02/vWLC-RADIUS-5.png "Cisco WLC authentication order")

Before leave the controller, be sure your local admin user has a strong password. If not, change it from CLI:

~~~
(Cisco Controller) >config mgmtuser password admin new_strong_password
~~~

## Microsoft NPS configuration (on Windows 2012 R2)

In this scenario, NPS servers authenticate both WiFi and management users locally, without any redirection to external RADIUS servers. This post will cover management configuration only. Before starting mind that all configurations must be replicated on both NPS servers.

Configure NPS servers so they logs to file (under `NPS` -> `Accounting` -> `Change Log File Properties`), using `ODBC (Legacy)` format:

![Microsoft NPS logs](/images/posts/2016/02/vWLC-RADIUS-6.png "Microsoft NPS logs")

I suggest [IAS Log Viewer Trial](http://www.deepsoftware.com/iasviewer/ "IAS Log Viewer Trial") to read NPS logs and debug RADIUS authentication from the NPS servers.

Add all Cisco WLC controllers as RADIUS Clients (under `NPS` -> `RADIUS Clients and Servers` -> `RADIUS Clients`):

![Microsoft NPS clients](/images/posts/2016/02/vWLC-RADIUS-7.png "Microsoft NPS clients")

Add a new connection request policy (under `NPS` -> `Policies` -> `Connection Request Policies`) as following (only relevant configurations are included):

* `Overview` -> `Policy name`: `Cisco WLC Devices`;
* `Overview` -> `Policy enabled`: set;
* `Overview` -> `Type of network access server`: `Unspecified`;
* `Conditions` -> `NAS Identifier`: the hostname of the Cisco WLC.

During tests, the conditions used was `NAS Port Type` = `Async/Modem`, but for some unknown reasons it didn't match (terminate cause was `Did not match connection request policy`). That's why NAS-ID has been used and customized on each SSID configured on WLC.

![Microsoft NPS connection request policy](/images/posts/2016/02/vWLC-RADIUS-8.png "Microsoft NPS connection request policy")

A pattern matching can be used, for example `^vwlc[0-9]+` to match all NAS-ID starting with `vwlc` and ending with one or more digits.

Configure now a network policy (under `NPS` -> `Policies` -> `Network Policies`) as following (only relevant configurations are included):

* `Overview` -> `Policy name`: `Network Administrators`;
* `Overview` -> `Policy enabled`: set;
* `Overview` -> `Grant access`: set;
* `Overview` -> `Ignore user account dial-in properties`: set;
* `Overview` -> `Type of network access server`: `Unspecified`;
* `Conditions` -> `Windows Groups`: the user group including all network administrators (if you include more groups, mind that they're evaluted using `AND` operator);
* `Constraints` -> `Authentication Method` -> `Unencrypted authentication (PAP, SPAP)`
* `Settings` -> `RADIUS Attributes` -> `Standard`: add `Service-Type` = `Administrative`

![Microsoft NPS network policy](/images/posts/2016/02/vWLC-RADIUS-9.png "Microsoft NPS network policy")

Mind that:

* Cisco WLC can only use PAP authentication, so that must be forced. IOS devices also requires unencrypted authentication too, so the same profile can be reused for all Cisco devices.
* The `Service-Type`attribute can be set to `Administrative` for privileged users, and unset for read-only users.
* if `Ignore user account dial-in properties` is not set, then users won't be able to login because of default user policies (terminate cause will be `DIALIN_DISABLED`).
