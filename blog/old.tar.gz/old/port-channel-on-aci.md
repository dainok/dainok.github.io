---
title: "Connecting an external entity to Cisco ACI (L2Out)"
date: "2018-03-22T09:00:00+01:00"
draft: false
---
The first and important step with a Cisco ACI fabric, is the connection of an external entity (switch, router, firewall...) to the fabric.

An external entity is something not managed directly by the APIC, and it's a mandatory step for brownfield installation.
The connection between the Cisco ACI fabric and the entity is usually called L2Out, because one or more broadcast domain are extended to the entity.
L2Out can be internal or external:

* internal: the external entity will be within the EPG, so no contract is needed to make the entity communicate with anything is already inside the fabric (within the same EPG)
* external: the external entity will be on a dedicated EPG and a contract must be defined to make the entity communicate with anything inside the fabric.

## Topology

Two devices will be connected to the same leaf using L2Out connections:

* Switch1: connected with a port-channel (PC) using an internal L2Out.
* Switch2: connected with a single cable using an internal L2Out.

## Prerequisites

Some elements must be created before starting the configuration, and some of them can be shared:

* Interface policies
* AAEP
* Domains
* VLAN pools

Please see references for additional links.

## Switch1: configuring a port-channel L2Out on Cisco ACI

Always remember [the Cisco ACI Workflow](/2018/03/cisco-aci-workflow/ "The Cisco ACI Workflow").

Switch1 is connected to one leaf with two interfaces.

Steps:
* Create a switch (leaf) profiles "LeafsA1".
  - Create a leaf selector, assigning the LeafA1 leaf only.
  - Create an interface profile "ports_to_Switch1".
    - Create an interface selector "ports_1_15-16" selecting interfaces 1/15-16 and associate to a new policy group "PC_to_Switch1".
      - Associate the policy group PC_to_Switch1 to a valid AAEP and to the following interface policies: CDP_on, LLDP_on, LACP_active.
* Be sure that AAEP is bound to a physical domain (not external).
* Be sure the physical domain is bound to a valid VLAN pool including VLAN 200.

Because the policy group defines (at the end) the port-channel ID, it cannot be reused.

If everything is ok, the port-channel is now up but can be out-of-service, depending on your configuration; out-of-service.
Go to the EPG where the external VLAN must be included: Tenants -&gt; &lt;tenant name&gt; -&gt; Application Profiles -&gt; &lt;application name&gt; -&gt; Static Ports -&gt; Deploy Static EPG on PC, VPC, or Interface:

* Path Type: Direct Port channel
* Path: PC_to_Switch1
* Port Encap (or Secondary VLAN for Micro-Seg): 200
* Mode: Trunk

Now the EPG is extended to the VLAN 200 of the external switch. If a subnet is defined (in the BD bound to the EPG), the switch can now ping it from the SVI (interface VLAN 200).

## Switch2: configuring a single interface L2Out on Cisco ACI

Always remember [the Cisco ACI Workflow](/2018/03/cisco-aci-workflow/ "The Cisco ACI Workflow").

Switch2 is connected to one leaf with a single interface.

Steps:
* Reuse the switch (leaf) profiles "LeafsA1".
  - Create an interface profile "ports_to_Switch2".
    - Create an interface selector "ports_1_18" selecting interfaces 1/18 and linking to a new (leaf access port) policy group named "individualports_to_Switches".
      - Associate the policy group individualports_to_Switches to a valid AAEP and to the following interface policies: CDP_on, LLDP_on.
* Be sure the physical domain is bound to a valid VLAN pool including VLAN 200.

The policy group individualports_to_Switches can be reused for every uplink to external switches, if the interfaces are not grouped (no PC or vPC).

Go to again to the EPG used before: Tenants -&gt; &lt;tenant name&gt; -&gt; Application Profiles -&gt; &lt;application name&gt; -&gt; Static Ports -&gt; Deploy Static EPG on PC, VPC, or Interface:

* Path Type: Port
* Node: LeafsA1
* Path: e1/18
* Port Encap (or Secondary VLAN for Micro-Seg): 200
* Mode: Trunk

## From the APIC

From the APIC we can see the state of the port-channel:

~~~
APIC1# show port-channel map PC_to_Switch1
Legends:
N/D : Not Deployed
PC: Port Channel
VPC: Virtual Port Channel

 Port-Channel Name  Type  Leaf ID, Name                     Fex Id  Port Channel   Ports                            
 ------------       ----  --------------------------------  ------  -------------  --------------------------------
 PC_to_Switch1      PC    101,Leaf_101                              po3            eth1/15-16                       
~~~

And check where the VLAN200 is exported:

~~~
APIC1# show vlan-domain vlan 200 name L2Out_OldDC
Legend:
vlanscope: L (Portlocal). Default is global

vlan-domain : L2Out_OldDC (static)     Domain-Type : 'phys'

vlan : 1-4094(static, external)  

 Leaf          Interface         Vlan  Type         Usage                
 ------------  ----------------  ----  -----------  --------------------
 101           eth1/18           200   App-Epg      Tenant: T1           
                                                    App: AppName              
                                                    Epg: EpgName         

 101           PC:               200   App-Epg      Tenant: T1           
               PC_to_Switch1                        App: AppName                 
                                                    Epg: EpgName         

free static vlans : 1-81, 83-98, 100-199, 201-799, 801-999, 1001-4094
~~~

## Spanning Tree Protocol inside Cisco ACI_NTS_LAB

Because a Cisco ACI fabric does not participate in the root election, both switches forms an "autonomous" spanning tree topology.
The Switch2 sees the Switch1 as the root bridge:

~~~
ACI_SWITCH2#show spanning-tree vlan 200

VLAN0200
  Spanning tree enabled protocol rstp
  Root ID    Priority    4296
             Address     001d.4617.6300
             Cost        4
             Port        1 (GigabitEthernet1/0/1)
             Hello Time   2 sec  Max Age 20 sec  Forward Delay 15 sec

  Bridge ID  Priority    32968  (priority 32768 sys-id-ext 200)
             Address     0013.c32b.2100
             Hello Time   2 sec  Max Age 20 sec  Forward Delay 15 sec
             Aging Time  300 sec

Interface           Role Sts Cost      Prio.Nbr Type
------------------- ---- --- --------- -------- --------------------------------
Gi1/0/1             Root FWD 4         128.1    P2p
~~~

To make STP working across a Cisco ACI fabric, all ports must be configured using the same type. If not, because Cisco ACI does not manipulates BPDUs, one of the switch will block the uplink port:

~~~
*Mar  8 04:27:13.277: %SPANTREE-7-RECV_1Q_NON_TRUNK: Received 802.1Q BPDU on non trunk GigabitEthernet1/0/3 VLAN200.
*Mar  8 04:27:13.277: %SPANTREE-7-BLOCK_PORT_TYPE: Blocking GigabitEthernet1/0/3 on VLAN0200. Inconsistent port type.
~~~

## References

* [Cisco APIC REST API Configuration Guide](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/2-x/rest_cfg/2_1_x/b_Cisco_APIC_REST_API_Configuration_Guide/b_Cisco_APIC_REST_API_Configuration_Guide_chapter_01.html 'Cisco APIC REST API Configuration Guide')
* [The Cisco ACI Workflow](/2018/03/cisco-aci-workflow/ "The Cisco ACI Workflow")
* [The Cisco ACI script repository](https://github.com/dainok/rrlabs/tree/master/aci "he Cisco ACI script repository")
* [Login to Cisco ACI using API](/2018/03/login-to-cisco-aci-using-api/ "Login to Cisco ACI using API")
* [Troubleshooting invalid path configuration on Cisco ACI](/2018/03/troubleshooting-invalid-path-configuration-on-cisco-aci/ "Troubleshooting invalid path configuration on Cisco ACI")
