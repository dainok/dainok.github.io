---
title: "Configuring NetFlow on vSphere 5.5"
date: "2014-07-23T09:00:00+01:00"
draft: false
---
The NetFlow protocol was developed by Cisco to collect traffic statistics. An enabled NetFlow device send to a NetFlow receiver a set of flows via UDP protocol. Each NetFlow contains one or more records:

* Input and output interface index
* Timestamps
* Number of bytes and packets observed in the flow
* Source and destination IP addresses
* Protocol, source and destination port numbers
* ToS
* ...

There are many NetFlow versions: the most supported is v5, IPv6 is supported from v9. VMware vSphere 5.1 and 5.5 support v10, also referred to as Internet Protocol Flow Information eXport (IPFIX), an IETF standard. The previous 5.0 version supports NetFlow v5.

There are very few v10 enabled receiver, I used in my test [NetFlow Analyzer](http://www.manageengine.com/products/netflow/ "NetFlow Analyzer") by Manage Engine. Currently the v10 version is available as beta version. Using a v9 receiver will report an error regarding unknown template ("V9 flows of unknown template are received").

In the VMware vSphere infrastructure, NetFlow can be configured on dvSwitches only:

![Netflow](/images/posts/2014/07/netflow.png "Netflow")

The following fields are available:

* IP address: the NetFlow receiver IP address.
* Port: the NetFlow UDP port.
* Switch IP address: the dvSwitch spans multiple SXi host, each one owns a unique IP address. Setting the switch IP address, all NetFlow data will be sourced from a single IP address.
* Active flow export timeout (Seconds): by default every 60 seconds the dvSwitch reports active flows.
* Idle flow export timeout (Seconds): by default every 15 seconds the dvSwitch reports completed flows.
* Sampling rate: by default each packet is reported. Setting a value of 10, a packet every 10 will be reported.
* Process internal flows only: only flows starting and ending in the dvSwitch will be reported. This option is useful if other flows are already monitored by a physical switch.

NetFlow does not check for duplicated flows. The most common error is enable NetFlow on all devices and obtain duplicated statistics on the NetFlow server. The last options can help to avoid duplicated information.

The next step will require to enable NetFlow on port groups or uplinks:

![netflow_on_portgroup](/images/posts/2014/07/netflow_on_portgroup.png "netflow_on_portgroup")

Enabling NetFlow on  Upinks can be useful to monitor vmkernel ports, if no physical NetFlow enabled switch is available.

After a while the reporter will show collected data:

![report](/images/posts/2014/07/report.png "report")

## References

* [Configuring NetFlow Export on VMware vCenter with ESXi](http://www.flowtraq.com/corporate/blog/tech-thoughts/configuring-netflow-export-vmware-vcenter-esxi/ "Configuring NetFlow Export on VMware vCenter with ESXi")
