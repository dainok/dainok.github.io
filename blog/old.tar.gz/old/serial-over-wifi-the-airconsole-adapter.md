---
title: "Serial over WiFi: the AirConsole adapter"
date: "2013-08-21T09:00:00+01:00"
draft: false
---
A key task for most of network engineer is still connect to blank devices and configure them from scratch. Using a pretty old serial cable, usually to short.

Few weeks ago my friend [Gian Paolo](http://www.ifconfig.it/ "ifconfig.it") convinced me to acquire an [AirConsole adaptreor](http://www.get-console.com/airconsole/ "AirConsole adapter") device which allows wireless serial connection using Linux/Windows/Android or Apple iOS devices.

The AirConsole Standard pack contains:

* a micro USB cable;
* a USB to Serial adapter (FT232);
* an AirConsole device.

## USB to Serial adapter (FT232)

The USB to Serial adapter uses a FT232 chipset:

~~~
Bus 004 Device 003: ID 0403:6001 Future Technology Devices International, Ltd FT232 USB-Serial (UART) IC
~~~

![AirConsole USB Serial Adapter](/images/posts/2013/07/AirConsole_USB_Serial_Adapter.png "AirConsole USB Serial Adapter")

It can be used without AirConsole adpater also: simply plug the adapter into a USB computer port and connect the other end to a console. Check which COM port is used:

![AirConsole Adapter on Windows](/images/posts/2013/07/AirConsole_Adapter_on_Windows.png "AirConsole Adapter on Windows")

Then simply open a PuTTY instance and point it to the right COM port. The FT232 chipset works better than Prolific one under Windows Vista/7/8 computers: if most of the Prolific drivers will crash Windows with a blue screen, the FT232 adapter is more stable.

## AirConsole device

The AirConsole device uses the USB to Serial adapter presenting a Serial port over WiFi/wired connections using Serial Over Telnet  protocol (RFC2177). AirConsole can be used as bridge/router between WiFi and wired connections also.

![AirConsle Adapter](/images/posts/2013/07/AirConsole_Adapter.png "AirConsle Adapter")

The AirConsole will boot in less than 20 seconds, after that connect to the AirConsole-XX Wireless SSID using the default password ("12345678"). XX are the last two hexadecimal digits of AirConsole MAC Address. Then open a browser and point it to `http://192.168.10.1/` (username and password are both `admin`). ...

## Using AirConsole

AirConsole offers a Serial Proxy so any telnet software can use the serial communication through the 3696 TCP port. Just point the telnet client to the AirConsole IP address using the 3696 TCP port: Serial parameters can be changed using the Airconsole Web Interface (by default is 9600 8N1).

![AirConsle Serial Settings](/images/posts/2013/08/AirConsoleSerialSettings.png "AirConsle Serial Settings")

The second connection method offered by AirConsole requires specific software to manage Serial over Telnet parameter/connections.

### Windows (Serial over Telnet)

A good software to manage Serial over Telnet connections under Windows OS is [HW VSP](http://www.hw-group.com/products/hw_vsp/index_en.html "HW VSP"): the single port version is available for free. Install it using the default options and configure a virtual serial port pointing to the AirConsole device (port `3696`):

![Adding a virtual COM](/images/posts/2013/07/AirConsole_adding_a_virtual_COM1.png "Adding a virtual COM")

The new COM port is now available:

![Virtual Adapter on Windows]( >![AirConsole_Virtual_Adapter_on_Windows](/images/posts/2013/07/AirConsole_Virtual_Adapter_on_Windows.png "AirConsole_Virtual_Adapter_on_Windows") Finally open a terminal emulator and point it to the COM port just configured.

### Android (Serial over Telnet)

Under Android devices the simplest way is to install [Serial Bot](https://play.google.com/store/apps/details?id=nz.co.cloudstore.serialbot "Serial Bot") app. I also suggest [Hacker's Keyboard](https://play.google.com/store/apps/details?id=org.pocketworkstation.pckeyboard "Hacker's Keyboard") with [dictionaries](https://play.google.com/store/apps/details?id=org.pocketworkstation.dict.en "English dictionary for Hacker's Keyboard"). Configure the Serial Bot app pointing it to the AirConsole (`3696` TCP port):

![AirConsole on Nexus 7](/images/posts/2013/07/AirConsole_on_Nexus_7.png "AirConsole on Nexus 7")

### Apple iOS (Serial over Telnet)

Under Apple iPhone/iPad a app is available from [Get Console App](https://itunes.apple.com/it/app/get-console/id412067943?mt=8 "Get Console App"). Just install it, and also a connection web sharing will be available from GetConsole website.

![AirConsole on iPhone/iPad](/images/posts/2013/08/NetConsole_iOS.png "AirConsole on iPhone/iPad")

### Linux and Apple Mac OS-X (Serial over Telnet)

Under Linux and Mac OS-X systems use the socat utility. The following line is for Linux (root privileges are required):

~~~
# socat PTY,link=/dev/ttyAC0,user=root,group=tty,mode=660 TCP:192.168.10.1:3696
~~~

The following line should be (I cannot test it) for Mac OS-X:

~~~
# socat GOPEN:/dev/ttyAC0,ignoreeof,user=root,group=tty,mode=660 TCP:192.168.10.1:3696
~~~

Now a local serial port is available and can be used by any terminal emulator software (like PuTTY).

## References

* [RFC2217 Telnet Com Port Control Option (Serial Over Telnet)](http://tools.ietf.org/html/rfc2217 "RFC2217 Telnet Com Port Control Option (Serial Over Telnet)")
* [GetConsole Twitter Account](https://twitter.com/getconsole">GetConsole Twitter Account "GetConsole Twitter Account")
* [AirConsole Home Page](http://www.get-console.com/airconsole/ >AirConsole Home Page")
* [AirConsole PDF Manual](http://www.get-console.com/airconsole/files/Airconsole-User-Manual-Full-v1.02.pdf "AirConsole PDF Manual")
* [What is AirConsole?](http://www.get-console.com/faq/?secid=8 "What is AirConsole?")
* [AirConsole FAQs](http://www.get-console.com/faq/?secid=12 "AirConsole FAQs")
* [HW VSP3 - a Virtual Serial Port for Windows](http://www.hw-group.com/products/hw_vsp/index_en.html "HW VSP3 - a Virtual Serial Port for Windows")
* [Make RS232 Serial Devices Accessible via Ethernet](http://blog.philippklaus.de/2011/08/make-rs232-serial-devices-accessible-via-ethernet/ "Make RS232 Serial Devices Accessible via Ethernet")
