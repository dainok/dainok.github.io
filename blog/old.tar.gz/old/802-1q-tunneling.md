---
title: "802.1q Tunneling"
date: "2013-05-27T09:00:00+01:00"
draft: false
---
A 802.1q tunnel (also known as QinQ), is used on metro-ethernet networks to obtain L2 (802.1q) adjacency between customer devices.

![QinQ topology](/images/posts/2013/05/Dot1q-tunnel.png "QinQ topology")

In the proposed example SW1 and SW2 are owned by the ISP, SW3 and SW4 are located in two different customer sites. The customer need a trunk between SW3 and SW4 switches without a dedicated link.

## ISP configuration
The ISP will dedicate one VLAN (111) to the customer. All customer traffic entering into e0/1 SW1 port will be encapsulated (tagged) with VLAN 111 and will flow within a 802.1q trunk link established between SW1 and SW2:

~~~
!SW1, SW2
system mtu 1504
interface Ethernet0/0
 switchport trunk encapsulation dot1q
 switchport mode trunk
interface Ethernet0/1
 switchport access vlan 111
 switchport mode dot1q-tunnel
 l2protocol-tunnel cdp
 l2protocol-tunnel vtp
 no cdp enable
~~~

System MTU must be increased, because a 802.1q header is 4 bytes long. With a default system MTU, SW3 and SW4 will be able to transmit 1496 packet long.

~~~
SW1#show dot1q-tunnel

dot1q-tunnel mode LAN Port(s)
-----------------------------
Et0/1
~~~

CDP is automatically disabled. The command "l2protocol-tunnel" will allow cdp/vtp/stp between SW3 and SW4 through the QinQ tunnel. In the example above CDP and VTP were enabled so SW3 and SW4 became CDP adjacent and can exchange VLAN configuration using VPT.

## Customer configuration

The customer must configure a 802.1q trunk on e0/0 interfaces on both SW3 and SW4 switches. From the customer perspective, SW3 and SW$ are directly connected:

~~~
!SW3, SW4
interface Ethernet0/0
 switchport trunk encapsulation dot1q
 switchport mode trunk
~~~

~~~
SW3#show cdp neighbors
Capability Codes: R - Router, T - Trans Bridge, B - Source Route Bridge
                  S - Switch, H - Host, I - IGMP, r - Repeater, P - Phone,
                  D - Remote, C - CVTA, M - Two-port Mac Relay

Device ID        Local Intrfce     Holdtme    Capability  Platform  Port ID
SW4              Eth 0/0           159              R S   Linux Uni Eth 0/0
~~~

## References

* [Configuring IEEE 802.1Q Tunneling, VLAN Mapping, and Layer 2 Protocol Tunneling](http://www.cisco.com/en/US/docs/switches/metro/me3400e/software/release/12.2_44_ey/configuration/guide/swtunnel.html "Configuring IEEE 802.1Q Tunneling, VLAN Mapping, and Layer 2 Protocol Tunneling")
* [IEEE 802.1Q-in-Q VLAN Tag Termination](http://www.cisco.com/en/US/docs/ios/lanswitch/configuration/guide/lsw_ieee_802.1q.html "IEEE 802.1Q-in-Q VLAN Tag Termination")
