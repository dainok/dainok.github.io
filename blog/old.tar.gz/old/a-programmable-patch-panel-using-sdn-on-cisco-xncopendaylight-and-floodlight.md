---
title: "A programmable patch panel using SDN on Cisco XNC/OpenDaylight and Floodlight"
date: "2013-11-11T09:00:00+01:00"
draft: false
---
Cisco CCIE, INE, IPexpert and Narbik netowrking labs have a static cabling scheme: usually first Ethernet port of R1 is connected to the first Ethernet port of SW1, and so on. Lab topolotgies are limited, and a manual re-cabling is not a good choice. A software patch-panel is useful to dynamically create test topologies without manually re-cabling all test rack.

A very simple (and expensive) use of SDN is a software programmable patch-panel:

* all R1...R6, SW1...Sw4, BB1...BB3 devices will be connected to a SDN switch;
* the SDN switch will bind couple of ports together: traffic entering from one port will be redirected to the coupled port and vice-versa;
* if a R1 port will go in the down/down state, the coupled port will remain in the up/up state (unless some feature will be supported by the SDN switch).

A simple topology will be implemented using MiniNet, Cisco XNC/OpenDaylight and Floodlight:

![single](/images/posts/2013/11/single.png "single")

By default all host will be able to ping themselves:

~~~
mininet> pingall
*** Ping: testing ping reachability
h1 -> h2 h3
h2 -> h1 h3
h3 -> h1 h2
*** Results: 0% dropped (6/6 received)
~~~

It's required to directly interconnect H1 to H2: flows entering from the port #1 will be redirect to the port #2 and vice-versa.



## Programming a switch using MiniNet

MiniNet is the test platform for SDN applications, but can be also used as a simple controller.
Let's start the MiniNet lab with the above topology:

~~~
sudo mn --topo=single,3
~~~

Then two flows must be configured:

~~~
mininet> dpctl add-flow in_port=1,actions=output:2
mininet> dpctl add-flow in_port=2,actions=output:1
mininet> dpctl dump-flows
*** s1 ------------------------------------------------------------------------
NXST_FLOW reply (xid=0x4):
 cookie=0x0, duration=56.797s, table=0, n_packets=10, n_bytes=532, idle_age=31, in_port=1 actions=output:2
 cookie=0x0, duration=49.75s, table=0, n_packets=10, n_bytes=532, idle_age=28, in_port=2 actions=output:1
~~~

Traffic flow from port #1 will be redirected to the port #2, and traffic flow from port #2 will be redirected to the port #1.
Now H1 can ping H2 and H3 is isolated:

~~~
mininet> pingall
*** Ping: testing ping reachability
h1 -> h2 X
h2 -> h1 X
h3 -> X X
*** Results: 66% dropped (2/6 received)
~~~

## Programming a switch using Cisco XNC/OpenDaylight

Let's start the MiniNet lab connected to the Cisco XNC controller (or OpenDaylight) with the above topology:

~~~
sudo mn --controller=remote,ip=192.168.32.129 --topo=single,3
~~~

Let's go to Flows -> Add Flow Entry and create two flows with the following parameters:

1. Name: flow1to2, Node: OF|00:00:00:00:00:00:00:01, Input: s1-eth1(1), Actions: (Add Output Port) s1-eth2(2)
2. Name: flow2to1, Node: OF|00:00:00:00:00:00:00:01, Input: s1-eth2(2), Actions: (Add Output Port) s1-eth1(1)

By default Ethernet Type 0x800 (IP) is configured, the field must be cleared because we want all traffic flows between port #1 and #2.

Now select each flow and install it to the switch.

![xnc-patch-panel](/images/posts/2013/11/xnc-patch-panel.png "xnc-patch-panel")
And again H1 can ping H2, but H3 is isolated:

~~~
mininet> pingall
*** Ping: testing ping reachability
h1 -> h2 X
h2 -> h1 X
h3 -> X X
*** Results: 66% dropped (2/6 received)
mininet> dpctl dump-flows
*** s1 ------------------------------------------------------------------------
NXST_FLOW reply (xid=0x4):
 cookie=0x0, duration=4.303s, table=0, n_packets=0, n_bytes=0, idle_age=4, priority=500,in_port=1 actions=output:2
 cookie=0x0, duration=6.189s, table=0, n_packets=0, n_bytes=0, idle_age=6, priority=500,in_port=2 actions=output:1
~~~

## Programming a switch using Flowlight

Let's start the MiniNet lab connected to the Floodlight controller with the above topology:

~~~
sudo mn --controller=remote,ip=192.168.32.129 --topo=single,3
~~~

Floodlight must be programmed via API/curl:

~~~
curl -d '{"switch":"00:00:00:00:00:00:00:01", "name":"flow-12", "ingress-port":"1", "actions":"output=2"}' http://127.0.0.1:8080/wm/staticflowentrypusher/json
curl -d '{"switch":"00:00:00:00:00:00:00:01", "name":"flow-21", "ingress-port":"2", "actions":"output=1"}' http://127.0.0.1:8080/wm/staticflowentrypusher/json
~~~

![floodlight-patch-panel](/images/posts/2013/11/floodlight-patch-panel.png "floodlight-patch-panel")
And once again H1 can reach H2 and H3 is isolated:

~~~
mininet> dpctl dump-flows
*** s1 ------------------------------------------------------------------------
NXST_FLOW reply (xid=0x4):
 cookie=0xffffffffdbbe769d, duration=37.515s, table=0, n_packets=0, n_bytes=0, idle_age=37, priority=32767,in_port=1 actions=output:2
 cookie=0xffffffffdbbe776f, duration=36.049s, table=0, n_packets=0, n_bytes=0, idle_age=36, priority=32767,in_port=2 actions=output:1
mininet> pingall
*** Ping: testing ping reachability
h1 -> h2 X
h2 -> h1 X
h3 -> X X
*** Results: 66% dropped (2/6 received)
~~~

## References

* [MiniNet as an SDN test platform](http://www.routereflector.com/en/2013/11/mininet-as-an-sdn-test-platform/ "MiniNet as an SDN test platform")
* [OpenDaylight as an SDN controller: overview and installation](http://www.routereflector.com/en/2013/11/opendaylight-as-an-sdn-controller-overview-and-installation/ "OpenDaylight as an SDN controller: overview and installation")
* [Cisco Extensible Network Controller (XNC): overview and installation](http://www.routereflector.com/en/2013/10/cisco-extensible-network-controller-xnc-overview-and-installation/ "Cisco Extensible Network Controller (XNC): overview and installation")
* [Floodlight SDN controller: overview and installation](http://www.routereflector.com/en/2013/11/floodlight-sdn-controller-overview-and-installation/ "Floodlight SDN controller: overview and installation")
* [Using An OpenFlow Switch As A Programmable Patch Panel](http://virtualnow.net/2012/05/03/using-an-openflow-switch-as-a-programmable-patch-panel/ "Using An OpenFlow Switch As A Programmable Patch Panel")
