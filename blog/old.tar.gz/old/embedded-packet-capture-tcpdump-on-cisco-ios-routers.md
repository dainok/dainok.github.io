---
title: "Embedded Packet Capture (tcpdump) on Cisco IOS routers"
date: "2013-05-27T09:00:00+01:00"
draft: false
---
Embedded Packet Capture, available from IOS 12.4T, can capture packet in tcpdump format. The configuration requires a specific buffer where packets will be stored. Data within the buffer can be exported and analyzed using external tools, like tcpdump or Wireshark.

## Configuration

An ACL must be defined to match interesting traffic only:

~~~
ip access-list extended Monitored-Host
 permit ip 10.0.0.0 0.0.0.255 host 10.1.1.1
~~~

A buffer must be defined and bounded to the previos defined ACL:

~~~
monitor capture buffer BUFFER size 512 max-size 256 circular
monitor capture buffer BUFFER filter access-list Monitored-Host
~~~

The next step requires to define which interfaces must be monitoed and where store data:

~~~
monitor capture point ip cef CAPTURE FastEthernet0/0 both
monitor capture point associate CAPTURE BUFFER
~~~

Finally the capture must be started and stopped when not needed anymore:

~~~
monitor capture point start CAPTURE
monitor capture point stop CAPTURE
~~~

At this point the buffer can be exported to an external system:

~~~
monitor capture buffer BUFFER export ftp://ftp.example.com/CAPTURER.pcap
~~~

The traffic can be analyzed using tcpdump:

~~~
# tcpdump -r CAPTURE.pcap -nn -v
[...]
13:49:40.503712 IP (tos 0xc0, ttl   1, id 0, offset 0, flags [none], proto: EIGRP (88), length: 60) 172.19.14.91 > 224.0.0.10:
        EIGRP v2, opcode: Hello (5), chksum: 0xee9b, Flags: [none]
        seq: 0x00000000, ack: 0x00000000, AS: 50, length: 20
          General Parameters TLV (0x0001), length: 12
            holdtime: 15s, k1 1, k2 0, k3 1, k4 0, k5 0
          Software Version TLV (0x0004), length: 8
            IOS version: 12.3, EIGRP version 1.2
[...]
~~~

The traffic can be analyed into the router itself, even if it's uneasy:

~~~
#show monitor capture buffer BUFFER dump
14:56:56.370 CEST Nov 5 2012 : IPv4 LES CEF    : Fa0/0 None

84387960:                            C4641393              Dd..
84387970: F3AC9CAF CA700F25 08004500 05DC5ABB  s,./Jp.%..E..\Z;
[...]
~~~

BUFFER and CAPUTRE object can be monitored using the followin commands:

~~~
#show monitor capture point all
Status Information for Capture Point CAPTURE
IPv4 CEF
Switch Path: IPv4 CEF            , Capture Buffer: BUFFER
Status : Active

Configuration:
monitor capture point ip cef CAPTURE FastEthernet0/0 both
~~~

~~~
#show monitor capture buffer all parameters
Capture buffer BUFFER (circular buffer)
Buffer Size : 262144 bytes, Max Element Size : 100 bytes, Packets : 1530
Allow-nth-pak : 0, Duration : 0 (seconds), Max packets : 0, pps : 0
Associated Capture Points:
Name : CAPTURE, Status : Active
Configuration:
monitor capture buffer BUFFER size 512 max-size 256 circular
monitor capture point associate CAPTURE BUFFER
monitor capture buffer BUFFER filter access-list Monitored-Host
~~~

At the end, the configuration can be deleted:

~~~
no monitor capture point ip cef CAPTURE FastEthernet0/0 both
no monitor capture buffer BUFFER
~~~

## References

* [Embedded Packet Capture](http://www.cisco.com/en/US/docs/ios/netmgmt/configuration/guide/nm_packet_capture_ps6441_TSD_Products_Configuration_Guide_Chapter.html "Embedded Packet Capture")
* [Wireshark](http://www.wireshark.org/ "Wireshark")
* [Tcpdump](http://www.tcpdump.org/ "Tcpdump")
