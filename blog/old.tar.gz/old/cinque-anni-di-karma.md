---
title: "Cinque anni di karma"
date: "2009-07-18T09:00:00+01:00"
draft: false
---
Sono passati cinque anni, cinque anni da quando ho deciso di affrontare il mio destino karmico e guardarlo in faccia. Cinque anni passati a mandar gi&ugrave; cose che non mi piacevano, cinque anni di sacrifici, di weekend immolati alla conoscenza, cinque anni di pazienza, cinque anni di lavori vari diurni e notturni, cinque anni di Joga, meditazione, insonnia... ma dopo cinque anni finalmente posso dire di aver finito gli esami di ingegneria! Con una rispettabile media di 26, per giunta!

Certo, la cosa non finisce qua, manca ancora un piccolo passo... ma dopo cinque anni posso finalmente avere una scrivania libera, weekend liberi, un'estate spensierata...

Un abbraccio a [Francesco Balzani](http://www.francescobalzani.it/ "Francesco Balzani"), che senza di lui... semplicemente non sarebbe stato possibile!
