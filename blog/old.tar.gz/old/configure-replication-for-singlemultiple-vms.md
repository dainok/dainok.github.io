---
title: "Configure Replication for Single/Multiple VMs"
date: "2014-06-18T09:00:00+01:00"
draft: false
---
The simplest example will replicate a VM within the same vCenter, using only one VMA. From the context menu of a source VM, select All vSphere Replication Actions -> Configure Replication:

![context_replication_menu](/images/posts/2014/06/context_replication_menu.png "context_replication_menu")

We are not using a remote site, so select a target vCenter (we only have the local one available):

![target_vcenter](/images/posts/2014/06/target_vcenter.png "target_vcenter")

Select the destination VRA (again we have only one available):

![target_vra](/images/posts/2014/06/target_vra.png "target_vra")

Select the destination storage:

![target_disk](/images/posts/2014/06/target_disk.png "target_disk")

The advanced disk configuration flag will enable options regarding disk format and VM storage policy.

Enable quiescing if supported by the underlying OS:

![quiescing](/images/posts/2014/06/quiescing.png "quiescing")

Define the Recovery Point Objective (RPO):

![rpo](/images/posts/2014/06/rpo.png "rpo")

In the home page we can monitor the replication process:

![monitor](/images/posts/2014/06/monitor.png "monitor")

The same replica will be listed on both Outgoing and Incoming replication, because only one vCenter is used.

## References

* [Everything you need to know to implement vSphere replication](http://blog.pluralsight.com/implement-vsphere-replication "Everything you need to know to implement vSphere replication")
