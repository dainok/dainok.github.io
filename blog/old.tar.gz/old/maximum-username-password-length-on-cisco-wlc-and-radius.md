---
title: "Maximum username/password length on Cisco WLC and RADIUS"
date: "2016-08-19T09:00:00+01:00"
draft: false
---
Some issues can happen when using RADIUS authentication for management (SSH) on Cisco WLC with long username/password.

## The issue

Cisco WLC does not forward to RADIUS server management (SSH) authentication if username and password are too long. Max length I found are:

* 12 chars for username
* 25 chars for password

If either username or password exceed de above values, WLC refuses to forward the authentication to the RADIUS server and fails to authenticate the user.
No logs are generated.

## Solution

Use username and password below the above values.
