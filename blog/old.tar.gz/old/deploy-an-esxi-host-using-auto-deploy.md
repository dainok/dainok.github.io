---
title: "Deploy an ESXi host using Auto Deploy"
date: "2014-06-18T09:00:00+01:00"
draft: false
---
Assuming there is an installed and working vCenter, install the Auto Deploy server located on vCenter ISO media (vctools\VMware-autodeploy.exe). Auto Deploy can be installed with the vCenter or as stand alone server: in this post vCenter and Auto Deploy are installed together. After Auto Deploy installation, a new option will be available using Web Client: ![auto_deploy_tab](/images/posts/2014/06/auto_deploy_tab.png "auto_deploy_tab")

Download TFTP Boot Zip file (https://vcenter.example.com:6502/vmw/rbd/deploy-tftp.zip) and upload to a TFTP server. In the following example a Cisco switch is used as both DHCP and TFTP server:

~~~
ip dhcp pool LAN
   network 172.31.30.0 255.255.255.224
   bootfile undionly.kpxe.vmw-hardwired
   next-server 172.31.30.2
   domain-name example.com
   dns-server 172.31.30.3
   default-router 172.31.30.1
!
tftp-server flash:undionly.kpxe.vmw-hardwired
tftp-server flash:tramp
~~~

Also unpack the the deploy-tftp.zip file and copy the undionly.kpxe.vmw-hardwired file to the switch:

~~~
Switch#copy tftp://172.31.30.1/undionly.kpxe.vmw-hardwired flash:vmware.pxe
Switch#copy tftp://172.31.30.1/tramp flash:
~~~

The undionly.kpxe.vmw-hardwired file is useful for standard BIOS servers; the deploy-tftp.zip file contains files for EFI architecture also. The tramp file is a simple config file pointing to the vCenter:

~~~
#!gpxe
set filename https://172.31.30.4:6501/vmw/rbd/tramp
chain https://172.31.30.4:6501/vmw/rbd/tramp
~~~

Download ESXi Offline Bundle Install PowerCLI

~~~
PowerCLI> Set-ExecutionPolicy RemoteSigned
PowerCLI> Set-PowerCLIConfiguration -invalidCertificateAction "Ignore" -confirm:$false
PowerCLI> Connect-ViServer -Server vcenter1.example.com -Protocol https -User Administrator -Pass Password
PowerCLI> Add-EsxSoftwareDepot C:\Depot\VMware-ESXi-5.5.0-1331820-depot.zip
PowerCLI> Get-EsxImageProfile

Name                           Vendor          Last Modified   Acceptance Level
----                           ------          -------------   ----------------
ESXi-5.5.0-1331820-standard    VMware, Inc.    9/19/2013 6:... PartnerSupported
ESXi-5.5.0-1331820-no-tools    VMware, Inc.    9/19/2013 6:... PartnerSupported

PowerCLI> New-DeployRule -Name "5.5.0-Stateless" -Item "ESXi-5.5.0-1331820-standard" -Pattern "mac=00:1A:4B:BE:F6:C2,00:1A:4B:BE:F6:C4"
PowerCLI> Add-DeployRule -DeployRule 5.5.0-Stateless
~~~

Now the server can be powered on and it will boot ESXi 5.5.0 via PXE. By deafult host will added to the vCenter server (root password is blank).

![host_added](/images/posts/2014/06/host_added.png "host_added")

## References

* [Using vSphere 5 auto-deploy in your home lab](http://www.yellow-bricks.com/2011/08/25/using-vsphere-5-auto-deploy-in-your-home-lab/ "Using vSphere 5 auto-deploy in your home lab")
* [Cheat sheet &ndash; Auto deploy](http://www.yellow-bricks.com/2011/09/05/cheat-sheet-auto-deploy/ "Cheat sheet &ndash; Auto deploy")
* [VMware Auto Deploy Rules & Rule Sets](http://infrastructureadventures.com/2012/03/19/vmware-auto-deploy-rules-rule-sets/ "VMware Auto Deploy Rules & Rule Sets")
* [vSphere PowerCLI Documentation](http://pubs.vmware.com/vsphere-55/index.jsp#com.vmware.vsphere.scripting.doc/GUID-3C87E067-CF9B-4348-8F27-C278439A71EF.html "vSphere PowerCLI Documentation")
