---
title: "Floodlight SDN controller: overview and installation"
date: "2013-11-08T09:00:00+01:00"
draft: false
---
Floodlight Is an Open SDN Controller sponsored by [Big Switch Networks](http://www.bigswitch.com/ "Big Switch Networks") and others.

![project_floodlight_infographic](/images/posts/2013/11/project_floodlight_infographic.png "project_floodlight_infographic")

Floodlight comes with [Floodlight Applications](http://www.projectfloodlight.org/applications/ "Floodlight Applications") (plugin) already available.

## Installation (on iou-web VM)

Floodlight comes as a Java app. Let's assume we want to install Floodlight SDN controller on [Cisco IOU Web Interface](http://www.routereflector.com/en/cisco/cisco-iou-web-interface/ "Cisco IOU Web Interface") VM: iou-web is a clean CentOS 6 installation, so it's a good platform for Floodlight tests.

The installations steps are very simple:

~~~
yum install make ant
tar xzf floodlight-source-0.90.tar.gz -C /opt --no-same-owner --no-same-permissions
cd /opt/floodlight-0.90/
make
~~~

Because iou-web comes with a firewall configured, the ports used by Floodlight must be properly configured. In this case 8080 port will be used:

~~~
iptables -L INPUT -n --line-numbers
Chain INPUT (policy ACCEPT)
num  target     prot opt source               destination
1    ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0           state RELATED,ESTABLISHED
2    ACCEPT     icmp --  0.0.0.0/0            0.0.0.0/0
3    ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0
4    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0           state NEW tcp dpt:22
5    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0           state NEW tcp dpt:80
6    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0           state NEW tcp dpts:2001:3024
7    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0           state NEW tcp dpts:32768:61000
8    REJECT     all  --  0.0.0.0/0            0.0.0.0/0           reject-with icmp-host-prohibited
~~~

An additional rule must be installed before the rule #8:

~~~
iptables -I INPUT 8  -m state --state NEW -p tcp -m multiport --dports 6633,8080 -j ACCEPT
service iptables save
~~~

Now ports 8080 and 6633 are permitted:

~~~
iptables -L INPUT -n --line-numbers
Chain INPUT (policy ACCEPT)
num  target     prot opt source               destination
1    ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0           state RELATED,ESTABLISHED
2    ACCEPT     icmp --  0.0.0.0/0            0.0.0.0/0
3    ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0
4    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0           state NEW tcp dpt:22
5    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0           state NEW tcp dpt:80
6    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0           state NEW tcp dpts:2001:3024
7    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0           state NEW tcp dpts:32768:61000
8    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0           state NEW multiport dports 6633,8080
9    REJECT     all  --  0.0.0.0/0            0.0.0.0/0           reject-with icmp-host-prohibited
~~~

Floodlight SDN controller can be downloaded as a VM also. In this case just [Floodlight download](http://www.bigswitch.com/download/floodlight "Floodlight download") it, and import the OVF file. Default username login is "floodlight", without any password.

## Starting Floodlight and connecting to

Floodlight can be started using Java:

~~~
cd /opt/floodlight-0.90/
java -jar target/floddlight.jar
~~~

Do not use floodlight.sh because iou-web is a 32bit VM.

Now Floodlight can be managed using HTTP (port 8080) using the IP address of the iou-web VM itself: no username is required. The complete URL is: http://192.168.32.129:8080/ui/index.html

## Adding a device under Floodlight controller

[MiniNet as an SDN test platform](http://www.routereflector.com/en/2013/11/mininet-as-an-sdn-test-platform/ "MiniNet as an SDN test platform") should be used for initial tests with OpenDaylight. Let's assume we want to create a tree topology and import into Floodlight controller:

~~~
sudo mn --controller=remote,ip=192.168.32.129 --topo=tree,3
~~~

Now Floodlight controller can manage seven switches and connected hosts:

![Floodlight_topology](/images/posts/2013/11/Floodlight_topology.png "Floodlight_topology")

## References

* [Floodlight Project](http://www.projectfloodlight.org/floodlight/ "Floodlight Project")
* [Floodlight Applications](http://www.projectfloodlight.org/applications/ "Floodlight Applications")
* [Floodlight download](http://www.projectfloodlight.org/download/ "Floodlight download")
