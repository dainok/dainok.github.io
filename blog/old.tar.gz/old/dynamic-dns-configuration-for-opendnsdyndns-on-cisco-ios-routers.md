---
title: "Dynamic DNS configuration for OpenDNS/DynDNS on Cisco IOS routers"
date: "2013-05-28T09:00:00+01:00"
draft: false
---
On Cisco router a protocol called Dynamic DNS (ddns) can be configured to upgrade DNS entry on remote DNS Server when an IP address changes. This feature is usually used on home routers with dynamic IP address. The Dynamic DNS feature simply invoke an URL, used by the DNS Server owner to update the associated IP address.

There are many Dynamic DNS based services, but two are the most famous:

* [DynDNS](http://www.dyndns.com/ "DynDNS"): links a public dynamic IP address to a third domain level like example.ath.cx (take a look also at [FreeDNS](http://freedns.afraid.org/ "FreeDNS")).
* [OpenDNS](http://www.opendns.com/ "OpenDNS"): allows a filtered DNS resolution based on categories.

## DynDNS configuration

DynDNS use a web page to update DNS third level domain using both HTTP and HTTPS. HTTP is simpler, HTTPS requires to install Root certificates.

A DynDNS method must be created:

~~~
ip ddns update method DYNDNS
 HTTP
  add http://user:password@members.dyndns.org/nic/update?system=dyndns&hostname=&myip=
~~~

interval maximum 1 0 0 0

The char '?' is special, and must be escaped using CTRL+V, followed by '?'.

The above method must be applied to the interface which will receive the public IP address; DynDNS requires the hostname parameter to associate the correct third level domain:

~~~
interface Dialer0
 ip ddns update hostname example.ath.cx
 ip ddns update DYNDNS
~~~

During an interface status change, when the interface became up/up, the router will invoke the following URL: <a> http://user:password@members.dyndns.org/nic/update?system=dyndns&hostname=example.ath.cx&myip=1.2.3.4.</a>

## OpenDNS configuration

The OpenDNS configuration is similar, but more complex because:

* only HTTPS is supported;
* the username is an email address and the char '@' must be substituted by '%40', according [HTML URL Encoding Reference](http://www.w3schools.com/tags/ref_urlencode.asp "HTML URL Encoding Reference").

An OpenDNS method is defined as following:

~~~
ip ddns update method OPENDNS
 HTTP
  add https://user%40example.com:password@updates.opendns.com/nic/update?hostname=Home
 interval maximum 1 0 0 0
~~~

~~~
interface Dialer0
 ip ddns update OPENDNS
~~~

Because HTTPS is used, the certificates must be verified by the router.

## Using HTTPS

A HTTP request should complete without issues:

~~~
Jan  5 11:10:17.628 CEST: DYNUPD: SWIF comingup 'ATM0'
Jan  5 11:10:17.628 CEST: DYNUPD: SWIF comingup 'ATM0.1'
Jan  5 11:11:08.849 CEST: DYNUPD: SWIF comingup 'Virtual-Access2'
Jan  5 11:11:11.633 CEST: DYNDNSUPD: Adding DNS mapping for gateway.example.ath.cx <=> 1.2.3.4
Jan  5 11:11:11.633 CEST: HTTPDNS: Update add called for gateway.example.ath.cx <=> 1.2.3.4
Jan  5 11:11:11.633 CEST: HTTPDNSUPD: Session ID = 0x3D
Jan  5 11:11:11.633 CEST: HTTPDNSUPD: URL = 'https://user%40example.com:password@updates.opendns.com/nic/update?hostname=Home'
Jan  5 11:11:11.633 CEST: HTTPDNSUPD: Sending request
Jan  5 11:11:13.237 CEST: HTTPDNSUPD: Response for update gateway.example.ath.cx <=> 1.2.3.4
Jan  5 11:11:13.237 CEST: HTTPDNSUPD: DATA START good 1.2.3.4
Jan  5 11:11:13.237 CEST: HTTPDNSUPD: DATA END, Status is Response data recieved, successfully
Jan  5 11:11:13.237 CEST: HTTPDNSUPD: Call returned SUCCESS for update gateway.example.ath.cx <=> 1.2.3.4
Jan  5 11:11:13.237 CEST: DYNDNSUPD: Another update completed (outstanding=0, total=0)
Jan  5 11:11:13.237 CEST: HTTPDNSUPD: Clearing all session 61 info
~~~

Using HTTPS a similar error will happen:

~~~
Jan  5 11:20:57.026 CEST: HTTPDNS: Update add called for gateway.example.ath.cx <=> 1.2.3.4
Jan  5 11:20:57.026 CEST: HTTPDNSUPD: Session ID = 0x3F
Jan  5 11:11:11.633 CEST: HTTPDNSUPD: URL = 'https://user%40example.com:password@updates.opendns.com/nic/update?hostname=Home'
Jan  5 11:20:57.026 CEST: HTTPDNSUPD: Sending request
Jan  5 11:20:57.406 CEST: HTTPDNSUPD: Call returned Request Aborted for update gateway.example.ath.cx <=> 1.2.3.4
~~~

The error "HTTPDNSUPD: Call returned Request Aborted" usually means that the certificate cannot be authenticated by the router.
During a HTTP request, the server (updates.opendns.com) will release a certificate. The router must authenticate that certificate using the correspondent Root CA certificate.

Using openssl from a Linux OS, the Root CA can be identified:

~~~
# echo | openssl s_client -showcerts -connect updates.opendns.com:443 2> /dev/null | sed -ne '/-BEGIN CERTIFICATE-/,/-END CERTIFICATE-/p' > opendns.pem
# cat opendns.pem | openssl x509 -noout -subject -dates -issuer
subject= /serialNumber=UoFmxu6ta5ecJiIs4su2w-q-u8rxJ/d3/OU=GT55236522/OU=See www.rapidssl.com/resources/cps (c)12/OU=Domain Control Validated - RapidSSL(R)/CN=*.opendns.com
notBefore=Aug 23 10:11:50 2012 GMT
notAfter=Sep 25 12:42:00 2014 GMT
issuer= /C=US/O=GeoTrust, Inc./CN=RapidSSL CA
~~~

~~~
# echo | openssl s_client -showcerts -connect members.dyndns.org:443 2> /dev/null | sed -ne '/-BEGIN CERTIFICATE-/,/-END CERTIFICATE-/p' > dyndns.pem
# cat dyndns.pem | openssl x509 -noout -subject -dates -issuer
subject= /serialNumber=yVOsLnm4HIMMKOEEGwizzZh6WL7xnTE7/C=US/O=members.dyndns.org/OU=80401367/OU=See www.geotrust.com/resources/cps (c)10/OU=Domain Control Validated - QuickSSL Premium(R)/CN=members.dyndns.org
notBefore=Feb 24 04:47:16 2010 GMT
notAfter=Mar 27 14:28:51 2013 GMT
issuer= /C=US/O=Equifax/OU=Equifax Secure Certificate Authority
~~~

The OpenDNS Root CA is GeoTrust and the DynDNS Root CA is Equifax. [Geotrust]([http://www.geotrust.com/resources/root-certificates/index.html "Geotrust") own both certificates, and both Root certificates are:

* for [OpenDNS Root CA](http://www.geotrust.com/resources/root_certificates/certificates/GeoTrust_Global_CA.pem GeoTrust_Global_CA.pem "OpenDNS Root CA");
* for [DynDNS Root CA](http://www.geotrust.com/resources/root_certificates/certificates/Equifax_Secure_Certificate_Authority.pem Equifax_Secure_Certificate_Authority.pem "DynDNS Root CA").

Both OpenDNS and DynDNS certificates can be verified:

~~~
# wget -q http://www.geotrust.com/resources/root_certificates/certificates/GeoTrust_Global_CA.pem
# openssl verify -CAfile GeoTrust_Global_CA.pem -purpose any -untrusted opendns.pem opendns.pem
opendns.pem: OK
~~~

~~~
# wget -q http://www.geotrust.com/resources/root_certificates/certificates/Equifax_Secure_Certificate_Authority.pem
# openssl verify -CAfile Equifax_Secure_Certificate_Authority.pem -purpose any -untrusted dyndns.pem dyndns.pem
dyndns.pem: OK
~~~

Both Root certificates are corrects and they can be installed into the router as CA Trusted certificates:

~~~
crypto pki trustpoint GEOTRUST
 enrollment terminal pem
 revocation-check none
crypto pki authenticate GEOTRUST

Enter the base 64 encoded CA certificate.
End with a blank line or the word "quit" on a line by itself

-----BEGIN CERTIFICATE-----
MIIDVDCCAjygAwIBAgIDAjRWMA0GCSqGSIb3DQEBBQUAMEIxCzAJBgNVBAYTAlVT
MRYwFAYDVQQKEw1HZW9UcnVzdCBJbmMuMRswGQYDVQQDExJHZW9UcnVzdCBHbG9i
YWwgQ0EwHhcNMDIwNTIxMDQwMDAwWhcNMjIwNTIxMDQwMDAwWjBCMQswCQYDVQQG
EwJVUzEWMBQGA1UEChMNR2VvVHJ1c3QgSW5jLjEbMBkGA1UEAxMSR2VvVHJ1c3Qg
R2xvYmFsIENBMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA2swYYzD9
9BcjGlZ+W988bDjkcbd4kdS8odhM+KhDtgPpTSEHCIjaWC9mOSm9BXiLnTjoBbdq
fnGk5sRgprDvgOSJKA+eJdbtg/OtppHHmMlCGDUUna2YRpIuT8rxh0PBFpVXLVDv
iS2Aelet8u5fa9IAjbkU+BQVNdnARqN7csiRv8lVK83Qlz6cJmTM386DGXHKTubU
1XupGc1V3sjs0l44U+VcT4wt/lAjNvxm5suOpDkZALeVAjmRCw7+OC7RHQWa9k0+
bw8HHa8sHo9gOeL6NlMTOdReJivbPagUvTLrGAMoUgRx5aszPeE4uwc2hGKceeoW
MPRfwCvocWvk+QIDAQABo1MwUTAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTA
ephojYn7qwVkDBF9qn1luMrMTjAfBgNVHSMEGDAWgBTAephojYn7qwVkDBF9qn1l
uMrMTjANBgkqhkiG9w0BAQUFAAOCAQEANeMpauUvXVSOKVCUn5kaFOSPeCpilKIn
Z57QzxpeR+nBsqTP3UEaBU6bS+5Kb1VSsyShNwrrZHYqLizz/Tt1kL/6cdjHPTfS
tQWVYrmm3ok9Nns4d0iXrKYgjy6myQzCsplFAMfOEVEiIuCl6rYVSAlk6l5PdPcF
PseKUgzbFbS9bZvlxrFUaKnjaZC2mqUPuLk/IH2uSrW4nOQdtqvmlKXBx4Ot2/Un
hw4EbNX/3aBd7YdStysVAq45pmp06drE57xNNB6pXE0zX5IJL4hmXXeXxx12E6nV
5fEWCRE11azbJHFwLJhWC9kXtNHjUStedejV0NxPNO3CBWaAocvmMw==
-----END CERTIFICATE-----

Certificate has the following attributes:
       Fingerprint MD5: F775AB29 FB514EB7 775EFF05 3C998EF5
      Fingerprint SHA1: DE28F4A4 FFE5B92F A3C503D1 A349A7F9 962A8212

% Do you accept this certificate? [yes/no]: yes
Trustpoint CA certificate accepted.
% Certificate successfully imported
~~~

~~~
crypto pki trustpoint EQUIFAX
 enrollment terminal pem
 revocation-check none
crypto pki authenticate EQUIFAX

Enter the base 64 encoded CA certificate.
End with a blank line or the word "quit" on a line by itself

-----BEGIN CERTIFICATE-----
MIIDIDCCAomgAwIBAgIENd70zzANBgkqhkiG9w0BAQUFADBOMQswCQYDVQQGEwJV
UzEQMA4GA1UEChMHRXF1aWZheDEtMCsGA1UECxMkRXF1aWZheCBTZWN1cmUgQ2Vy
dGlmaWNhdGUgQXV0aG9yaXR5MB4XDTk4MDgyMjE2NDE1MVoXDTE4MDgyMjE2NDE1
MVowTjELMAkGA1UEBhMCVVMxEDAOBgNVBAoTB0VxdWlmYXgxLTArBgNVBAsTJEVx
dWlmYXggU2VjdXJlIENlcnRpZmljYXRlIEF1dGhvcml0eTCBnzANBgkqhkiG9w0B
AQEFAAOBjQAwgYkCgYEAwV2xWGcIYu6gmi0fCG2RFGiYCh7+2gRvE4RiIcPRfM6f
BeC4AfBONOziipUEZKzxa1NfBbPLZ4C/QgKO/t0BCezhABRP/PvwDN1Dulsr4R+A
cJkVV5MW8Q+XarfCaCMczE1ZMKxRHjuvK9buY0V7xdlfUNLjUA86iOe/FP3gx7kC
AwEAAaOCAQkwggEFMHAGA1UdHwRpMGcwZaBjoGGkXzBdMQswCQYDVQQGEwJVUzEQ
MA4GA1UEChMHRXF1aWZheDEtMCsGA1UECxMkRXF1aWZheCBTZWN1cmUgQ2VydGlm
aWNhdGUgQXV0aG9yaXR5MQ0wCwYDVQQDEwRDUkwxMBoGA1UdEAQTMBGBDzIwMTgw
ODIyMTY0MTUxWjALBgNVHQ8EBAMCAQYwHwYDVR0jBBgwFoAUSOZo+SvSspXXR9gj
IBBPM5iQn9QwHQYDVR0OBBYEFEjmaPkr0rKV10fYIyAQTzOYkJ/UMAwGA1UdEwQF
MAMBAf8wGgYJKoZIhvZ9B0EABA0wCxsFVjMuMGMDAgbAMA0GCSqGSIb3DQEBBQUA
A4GBAFjOKer89961zgK5F7WF0bnj4JXMJTENAKaSbn+2kmOeUJXRmm/kEd5jhW6Y
7qj/WsjTVbJmcVfewCHrPSqnI0kBBIZCe/zuf6IWUrVnZ9NA2zsmWLIodz2uFHdh
1voqZiegDfqnc1zqcPGUIWVEX/r87yloqaKHee9570+sB3c4
-----END CERTIFICATE-----

Certificate has the following attributes:
       Fingerprint MD5: 67CB9DC0 13248A82 9BB2171E D11BECD4
      Fingerprint SHA1: D23209AD 23D31423 2174E40D 7F9D6213 9786633A

% Do you accept this certificate? [yes/no]: yes
Trustpoint CA certificate accepted.
% Certificate successfully imported
~~~

Now certificates can successfully verified and Dynamic DNS HTTPS methods will work.

## References

* [GeoTrust Root Certificates](http://www.geotrust.com/resources/root-certificates/index.html "GeoTrust Root Certificates")
* [Import of RSA Keypair and Certificates in PEM Format](http://www.cisco.com/en/US/docs/ios/12_3t/12_3t4/feature/guide/gtrsapem.html "Import of RSA Keypair and Certificates in PEM Format")
* [Configuring PKI Using the IPSec VPN SPA](http://www.cisco.com/en/US/products/hw/routers/ps368/module_installation_and_configuration_guides_chapter09186a00806c1d0a.html "Configuring PKI Using the IPSec VPN SPA")
* [HTML URL Encoding Reference](http://www.w3schools.com/tags/ref_urlencode.asp "HTML URL Encoding Reference")
