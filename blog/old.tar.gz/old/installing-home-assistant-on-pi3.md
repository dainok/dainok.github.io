---
title: "Installing Home Assistant on a Raspberry Pi 3"
date: "2016-10-03T09:00:00+01:00"
draft: false
---
This post will show how to install Home Assistant on a Raspberry Pi 3, secure it and expose it on Internet.

[Home Assistant](https://home-assistant.io/ "Home Assistant") is a full suite for Smart Home/Home Automation/Domotic installable on a Linux server. Even if it works also on a Raspberry Pi 2, a Raspberry Pi 3 model is preferred.

## Home Assistant installation

Download and install a [Raspbian Lite](https://www.raspberrypi.org/downloads/raspbian/ "Raspbian Lite") on a fast 16GB SD (Class 10).
After the first boot, update all packages to the latest version:

~~~
# apt-get update
# apt-get -y upgrade
~~~

Do not use `rpi-update`, it will install the lastest beta firmware, and it's not so stable.

Install also few development tools:

~~~
# apt-get -y install python3-pip build-essential
~~~

Finally install Home Assistant

~~~
# useradd -m hass
# pip3 install homeassistant
~~~

Create also the startup script:

~~~
[Unit]
Description=Home Assistant for %i
After=network.target

[Service]
Type=simple
User=%i
ExecStart=/usr/local/bin/hass --daemon
SendSIGKILL=no
RestartForceExitStatus=100

[Install]
WantedBy=multi-user.target
~~~

Now enable Home Assistant daemon to start during the system boot:

~~~
# systemctl --system daemon-reload
# systemctl enable home-assistant@hass
~~~

## First Home Assistant startup

Let Home Assistant create the default configuration:

~~~
# su - -c "/usr/local/bin/hass" hass
~~~

~~~
INFO:homeassistant.util.package:Attempting install of sqlalchemy==1.0.14
INFO:homeassistant.util.package:Attempting install of cherrypy==7.1.0
INFO:homeassistant.util.package:Attempting install of static3==0.7.0
INFO:homeassistant.util.package:Attempting install of Werkzeug==0.11.11
INFO:homeassistant.util.package:Attempting install of astral==1.2
INFO:homeassistant.util.package:Attempting install of netdisco==0.7.1
[...]
INFO:urllib3.connectionpool:Starting new HTTP connection (1): 192.168.10.6
~~~

Terminate it (`CTRL+C`) when the last line above appears. And now start it using the `systemctl` wrapper:

~~~
# systemctl start home-assistant@hass
# systemctl status home-assistant@hass -l
~~~

## Home Assistant configuration

Home Assistant configuration is placed under `/home/hass/.homeassistant/configuration.yaml`. By default it contains everything, but I suggest to split it in multiple files:

~~~
# su - hass
$ mkdir -p .homeassistant/automation/ .homeassistant/sensors/
~~~

* [configuration.yaml](https://github.com/dainok/rrlabs/blob/master/linux/home/hass/.homeassistant/configuration.yaml "configuration.yaml")
* [logger.yaml](https://github.com/dainok/rrlabs/blob/master/linux/home/hass/.homeassistant/logger.yaml "logger.yaml")
* [notify.yaml](https://github.com/dainok/rrlabs/blob/master/linux/home/hass/.homeassistant/notify.yaml "notify.yaml")
* [sensors/weather.yaml](https://github.com/dainok/rrlabs/blob/master/linux/home/hass/.homeassistant/sensors/weather.yaml "sensors/weather.yaml")

If you're planning to follow my HowTo about Home Assistant, be sure your installation listen on localhost only using `8123` port:

~~~
http:
  server_host: 127.0.0.1
  server_port: 8123
~~~

## References

* [Home Assistant](https://home-assistant.io/ "Home Assistant")
* [Home Assistant Components](https://home-assistant.io/components/ "Home Assistant Components")
* [Home Assistant Cookbook](https://home-assistant.io/cookbook/ "Home Assistant Cookbook")
