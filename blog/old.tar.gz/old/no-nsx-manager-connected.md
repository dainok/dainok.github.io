---
title: "No VMware NSX manager connected"
date: "2015-01-08T09:00:00+01:00"
draft: false
---
If the VMware vSphere Web Client shows no connected NSX Manager, try to restart the NSX Manager service. The issue can happen if the vCenter is restarted or starts after the NSX Manager.

Connect to the NSX Manager and in the summary view stop and restart the NSX Management Service :

![nsx_manager_issue](/images/posts/2015/01/nsx_manager_issue.png "nsx_manager_issue")

After a while the vCenter will show the NSX Manager again. Logout frmo the Web Client is suggested.
