---
title: "Chrooted SFTP"
date: "2014-02-24T09:00:00+01:00"
draft: false
---
OpenSSH allows SSH/SFTP users to connect to the whole system by default. In many cases this is not the expected behavior: users should be relegated to the home their own home directory only.

Sometimes this is called "Chrooted SFTP".

As we discussed before, SFTP users can see the whole system by default:

~~~
# sftp andrea@localhost
Connecting to localhost...
andrea@localhost's password:
sftp> pwd
Remote working directory: /home/andrea
~~~

Users can be confined changing the SFTP back-end:

~~~
# /etc/ssh/sshd_config
[...]
#Subsystem sftp /usr/libexec/openssh/sftp-server
Subsystem sftp internal-sftp
[...]
~~~

Users part of the webmaster group should only access to the webserver directory; other users should be restricted to their own home directory:

~~~
# /etc/ssh/sshd_config
[...]
Match User webmaster
 ChrootDirectory /var/www/html
 AllowTCPForwarding no
 X11Forwarding no
 ForceCommand internal-sftp
Match Group users
 ChrootDirectory /home
 AllowTCPForwarding no
 X11Forwarding no
 ForceCommand internal-sftp
[...]
~~~

Now users are restricted and cannot leave the configured directory:

~~~
andrea@localhost's password:
sftp> pwd
Remote working directory: /
~~~

Enabling a restricted SSH is more complicated: SSH needs many components like BASH, libraries and so on. The reason is simple: if a user enters to a confined environment, it cannot access components outside the confined environment. All required components must be copied to the path where users are "chrooted".
