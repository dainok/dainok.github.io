---
title: "Distributed routing on VMware NSX"
date: "2015-01-14T09:00:00+01:00"
draft: false
---
On the [VMware NSX: a short introduction and HOWTO install it](http://www.routereflector.com/2015/01/vmware-nsx-a-short-introduction-and-howto-install-it/ "VMware NSX: a short introduction and HOWTO install it") a NSX environment has been configured with three isolated logical switches. In this post a distributed router will be added to route packets between logical switches inside tenant 1.

Open the Web client and go to "Networking & Security -> NES Edges" and add a new logical (distributed) router:

![nsx_ldr_1](/images/posts/2015/01/nsx_ldr_1.png "nsx_ldr_1")

Configure username, password, enable SSH and HA:

![nsx_ldr_2](/images/posts/2015/01/nsx_ldr_2.png "nsx_ldr_2")

With HA flag enabled, two VMs will be deployed and started on different ESXi nodes.

Place the new appliance on a cluster:

![nsx_ldr_4](/images/posts/2015/01/nsx_ldr_4.png "nsx_ldr_4")

Configure management interface and bind all logical switches of Tenant 1, configuring the IP address for each Logical Interface (LIF):

![nsx_ldr_5](/images/posts/2015/01/nsx_ldr_5.png "nsx_ldr_5")Few notes:

* interface type is "Internal", not "Uplink";
* management address is for debug only (Web Client is enough).

Finally do not configure the default gateway (Tenant 1 is still isolated).

After a while the LDR appliance will be deployed and ready for routing; then VMs connected on different logical switches of Tenant 1 can reach each other.

A few check can be made on NSX Controller:

~~~
nsx-controller # show control-cluster logical-routers instance all
LR-Id      LR-Name            Hosts[]         Edge-Connection Service-Controller
0x76d082c0 1+edge-6                                           172.31.30.18
nsx-controller # show control-cluster logical-routers interface-summary 0x76d082c0
Interface                        Type   Id           IP[]
76d082c00000000a                 vxlan  0x138a       172.31.31.1/24
76d082c00000000b                 vxlan  0x1388       172.31.32.1/24
~~~

One logical router exists configured with two logical interface.

On ESXi hosts the VSR is enabled:

~~~
~ # net-vdr --instance -l

VDR Instance Information :
---------------------------

Vdr Name:                   1+edge-6
Vdr Id:                     1993376448
Number of Lifs:             2
Number of Routes:           2
State:                      Enabled
Controller IP:              172.31.30.18
Control Plane IP:           172.31.30.11
Control Plane Active:       Yes
Num unique nexthops:        0
Generation Number:          0
Edge Active:                No
~~~

The VDR is configured with two LIFs, a VNI for each LIF:

~~~
~ # net-vdr --lif -l 1+edge-6

VDR 1+edge-6 LIF Information :

Name:                76d082c00000000b
Mode:                Routing, Distributed, Internal
Id:                  Vxlan:5000
Ip(Mask):            172.31.32.1(255.255.255.0)
Connected Dvs:       DSwitch0
VXLAN Control Plane: Enabled
VXLAN Multicast IP:  0.0.0.1
State:               Enabled
Flags:               0x2388
DHCP Relay:          Not enabled

Name:                76d082c00000000a
Mode:                Routing, Distributed, Internal
Id:                  Vxlan:5002
Ip(Mask):            172.31.31.1(255.255.255.0)
Connected Dvs:       DSwitch0
VXLAN Control Plane: Enabled
VXLAN Multicast IP:  0.0.0.1
State:               Enabled
Flags:               0x2388
DHCP Relay:          Not enabled
~~~

And finally the IP address range for each LIF:

~~~
~ # net-vdr -R -l 1+edge-6

VDR 1+edge-6 Route Table
Legend: [U: Up], [G: Gateway], [C: Connected], [I: Interface]
Legend: [H: Host], [F: Soft Flush] [!: Reject] [E: ECMP]

Destination      GenMask          Gateway          Flags    Ref Origin   UpTime     Interface
-----------      -------          -------          -----    --- ------   ------     ---------
172.31.31.0      255.255.255.0    0.0.0.0          UCI      1   MANUAL   967        76d082c00000000a
172.31.32.0      255.255.255.0    0.0.0.0          UCI      1   MANUAL   966        76d082c00000000b
~~~

On [Configuring OSPF between Logical and Edge routers on VMware NSX](http://www.routereflector.com/2015/01/configuring-ospf-between-logical-and-edge-routers-on-vmware-nsx/ "Configuring OSPF between Logical and Edge routers on VMware NSX") an Edge router will be added for external network connectivity.

## References

* [NSX vSphere troubleshooting](http://www.yet.org/2014/09/nsxv-troubleshooting/ "NSX vSphere troubleshooting")
* [NSX for vSphere: Controller &ldquo;Connections&rdquo; and &ldquo;VTEPs&rdquo;](https://telecomoccasionally.wordpress.com/2014/12/25/nsx-for-vsphere-controller-connections-and-vteps/ "NSX for vSphere: Controller &ldquo;Connections&rdquo; and &ldquo;VTEPs&rdquo;")
* [NSX Controller Troubleshooting &ndash; Logical Routing and Bridging](http://vsential.com/2014/08/nsx-controller-troubleshooting-logical-routing-bridging/ "NSX Controller Troubleshooting &ndash; Logical Routing and Bridging")
