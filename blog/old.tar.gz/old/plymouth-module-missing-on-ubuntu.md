---
title: "plymouth module missing on Ubuntu"
date: "2016-11-22T09:00:00+01:00"
draft: false
---
Using plymouth for boot theme can lead to a strange error on Ubuntu. Here a quick solution.

The full error is:

~~~
W: plymouth module (/usr/lib/x86_64-linux-gnu/plymouth//.so) missing, skipping that theme.
~~~

That's happen when `update-initramfs` is invoked.

## Troubleshooting

Let's see what happen:

~~~
# bash -x /usr/sbin/update-initramfs -u
[...]
+ mkinitramfs -o /boot/initrd.img-4.4.14-eve-ng+.new 4.4.14-eve-ng+
W: plymouth module (/usr/lib/x86_64-linux-gnu/plymouth//.so) missing, skipping that theme.
[...]
~~~

The error is catch by `mkinitramfs`. Let's follow the "white rabbit":

~~~
# bash -x /usr/sbin/mkinitramfs -o /boot/initrd.img-4.4.14-eve-ng+.new 4.4.14-eve-ng+
[...]
+ /usr/share/initramfs-tools/hooks/plymouth
W: plymouth module (/usr/lib/x86_64-linux-gnu/plymouth//.so) missing, skipping that theme.
[...]
~~~

And follow it again:

~~~
# cat /usr/share/initramfs-tools/hooks/plymouth
[...]
MODULE="${PLUGIN_PATH}/$(sed -n 's/^ModuleName=\(.*\)/\1/p' ${THEMES}/${currtheme}/${currtheme}.plymouth 2>/dev/null || true).so"

if [ ! -e "$MODULE" ]
then
		echo "W: plymouth module ($MODULE) missing, skipping that theme."
		continue
fi
[...]
~~~

Mind that:

* PLUGIN_PATH is `plymouth --get-splash-plugin-path`;
* THEMES is `/usr/share/plymouth/themes`;
* currtheme is `eveng`;

And we found some possible common and least common causes:

* Theme folder is now `/usr/share/plymouth/themes`, on previus Ubuntu versions was `/lib/plymouth/themes`, so be sure all references are updated.
* Theme folder and theme filename must be the same, in my case it is `/usr/share/plymouth/themes/eveng/eveng.plymouth`;
* The regex doesn't want spaces before and after `=`, so it must be `ModuleName=script` and not `ModuleName = script`.

Fixed the above three conditions, `update-initramfs` should work fine.
