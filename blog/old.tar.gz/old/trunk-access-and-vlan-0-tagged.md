---
title: "Trunk, Access (802.1P) or Access (Untagged)?"
date: "2018-03-21T09:00:00+01:00"
draft: false
---
On a Cisco ACI fabric ports can be defined as trunk, access (802.1P), or access (untagged). It sounds redundant, but the differences can be very important and leads to limits or incompatibilities.

Before explaining the differences between trunk, access 802.1P and access untagged, a limit of Cisco ACI fabrics should be mentioned:

> Error:400 - Validation failed: Validation failed for fv::EPg: uni/tn-TenantName/ap-AppProfile/epg-EpgName vlan: vlan-200 fvMode should be either set tagged or untagged on all ports.

In other words, in a leaf, inside the same EPG, VLANs can be tagged (trunk or access 802.1P) or untagged, but not both. Or, if a VLAN is defined inside a trunk, it cannot be defined as access (in the same leaf, in the same EPG).

But what's the difference between access 802.1P and access untagged?

802.1P refers to a QoS implementation using 802.1Q protocols. In other words, a port in Access (802.1P) should send and receive frames tagged with VLAN 0 (using 802.1Q).
Untagged ports should send and receive frames untagged (without 802.1Q).
Most of modern operating system should be able to manage tagged frames with VLAN 0 like untagged frames. But using PXE across a Cisco ACI fabric could lead to some issues, because small BIOS/firmware could not read VLAN 0 tagged frames.

Moreover there are two generation of switches:

> *Generation 1 Switches*
> - If the port is configured in Access (802.1p) mode:
>     - On egress, if the access VLAN is the only VLAN deployed on the port, then traffic will be untagged.
>     - On egress, if the port has other (tagged) VLANs deployed along with an untagged EPG, then traffic from that EPG is zero tagged.
>     - On egress, for all FEX ports, traffic is untagged, irrespective of one or more VLAN tags configured on the port.
>     - The port accepts ingress traffic that is untagged, tagged, or in 802.1p mode.
> - If a port is configured in Access (Untagged) mode:
>     - On egress, the traffic from the EPG is untagged.
>     - The port accepts ingress traffic that is untagged, tagged, or 802.1p.

> *Generation 2 Switches*
> Generation 2 switches, or later, do not distinguish between the Access (Untagged) and Access (802.1p) modes. When EPGs are deployed on Generation 2 ports configured with either Untagged or 802.1p mode:
> - On egress, traffic is always untagged on a node where this is deployed.
> - The port accepts ingress traffic that is untagged, tagged, or in 802.1p mode.

## References

* [Native 802.1p and Tagged EPGs on Interfaces](https://www.cisco.com/c/en/us/td/docs/switches/datacenter/aci/apic/sw/1-x/aci-fundamentals/b_ACI-Fundamentals/b_ACI-Fundamentals_chapter_010001.html#concept_450C8C73C1DE4A4EAF6390E862BD9952 "Native 802.1p and Tagged EPGs on Interfaces")
