---
title: "Cisco Extensible Network Controller (XNC): overview and installation"
date: "2013-10-31T09:00:00+01:00"
draft: false
---
Cisco Extensible Network Controller (XNC) is a controller for the ONE enabled devices. Quoting Cisco itself:

> The Cisco&reg; XNC is a software application built on OpenDaylight, and is the first commercial version of OpenDaylight controller. It can run on Linux-based x86 server, such as Cisco Unified Computing System&trade; (Cisco UCS&reg;)

In short XNC is a Cisco ONE application developed using Java language. It uses ONE API to communicate with Cisco ONE enabled device. XNC is the first Cisco SDN controller which allows to centrally manage/configure multiple devices.

![XNC Architecture](/images/posts/2013/10/XNC-Architecture.png "XNC Architecture")

## Installation (on iou-web VM)

XNC comes as a Java app,  so Java must be installed on a Linux system. Let's assume we want to install XNC on [Cisco IOU Web Interface](http://www.routereflector.com/en/cisco/cisco-iou-web-interface/ "Cisco IOU Web Interface") VM: iou-web is a clean CentOS 6 installation, so it's a good platform for XNC tests.

Java SE Runtime Environment (JRE) 7 must be downloaded, so get the [jre-7u45-linux-i586.rpm](http://www.oracle.com/technetwork/java/javase/downloads/jre7-downloads-1880261.html "jre-7u45-linux-i586.rpm") package and upload it to the iou-web VM using SCP. Upload a XNC (xnc1000-ctl-k9-1.0.0.zip) packages also.

The installations steps are very simple:

~~~
yum install unzip
rpm -Uvh jre-7u45-linux-i586.rpm
unzip xnc1000-ctl-k9-1.0.0.zip -d /opt
~~~

Because iou-web comes with a firewall configured, the ports used by XNC must be properly configured. In this case 8022, 8080 and 80443 ports will be used:

~~~
iptables -L INPUT -n --line-numbers
Chain INPUT (policy ACCEPT)
num  target     prot opt source               destination
1    ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0           state RELATED,ESTABLISHED
2    ACCEPT     icmp --  0.0.0.0/0            0.0.0.0/0
3    ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0
4    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0           state NEW tcp dpt:22
5    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0           state NEW tcp dpt:80
6    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0           state NEW tcp dpts:2001:3024
7    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0           state NEW tcp dpts:32768:61000
8    REJECT     all  --  0.0.0.0/0            0.0.0.0/0           reject-with icmp-host-prohibited
~~~

An additional rule must be installed before the rule #8:

~~~
iptables -I INPUT 8  -m state --state NEW -p tcp -m multiport --dports 6633,8022,8080,8443 -j ACCEPT
service iptables save
~~~

Now ports 8022, 8080 and 8443 are permitted:

~~~
iptables -L INPUT -n --line-numbers
Chain INPUT (policy ACCEPT)
num  target     prot opt source               destination
1    ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0           state RELATED,ESTABLISHED
2    ACCEPT     icmp --  0.0.0.0/0            0.0.0.0/0
3    ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0
4    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0           state NEW tcp dpt:22
5    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0           state NEW tcp dpt:80
6    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0           state NEW tcp dpts:2001:3024
7    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0           state NEW tcp dpts:32768:61000
8    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0           state NEW multiport dports 6633,8022,8080,8443
9    REJECT     all  --  0.0.0.0/0            0.0.0.0/0           reject-with icmp-host-prohibited
~~~

## Starting XNC and connecting to

XNC can be started using Java (we wants console port on TCP 8022):

~~~
export JAVA_HOME=/usr/java/latest/
cd /opt/xnc
/opt/xnc/runxnc.sh -start 8022
/opt/xnc/runxnc.sh -status
fuser -n tcp 8022
~~~

Because startup scripts do not read full path, XNC must be started from the installation directory.

Sometimes XNC starts but no process is listening (fuser command has no output). In this case XNC should be stopped and restarted:

~~~
/opt/xnc/runxnc.sh -stop
/opt/xnc/runxnc.sh -start 8022
~~~

Now XNC can be managed using SSH (port 8022), HTTP (port 8080) and HTTPS (port 8443) using the IP address of the iou-web VM itself: default username is "admin" with password "admin".

>![XNC Login](/images/posts/2013/10/XNC-Login.png "XNC Login")

XNC startup can be debugged using the console mode:

~~~
/opt/xnc/runxnc.sh -stop
/opt/xnc/runxnc.sh -console 8022
~~~

## Adding a device under XNC

Currently only Cisco Nexus 3000 switches are supported. Let's assume we had a test environment and we want to use simple clear text authentication on switches:

~~~
username admin privilege 15 password 0 cisco
onep
 transport socket
 start
~~~

Now connect to the XNC controller using SSH and add Nexus switches:

~~~
addOnepNode 192.168.255.1 admin cisco
~~~

Not all versions are supported. If a similar error appears:

~~~
2013-10-31 09:22:12.873 CET [Thread-25] ERROR c.cisco.onep.element.NetworkElement - IDL Exception: ExceptionIDL(code:2, text:NE Version:0.6.0 Client (Cisco ONE Controller - oneP Southbound Plugin) Version: 0.8.0, context:0)
2013-10-31 09:22:12.882 CET [Thread-25] ERROR c.cisco.onep.element.NetworkElement - Could not connect to NetworkElement: com.cisco.onep.core.exception.OnepConnectionException: Error occurred in the operation. Failed to connect to the network element or the session is closed. null
com.cisco.onep.core.exception.OnepConnectionException: Error occurred in the operation. Failed to connect to the network element or the session is closed. null
        at com.cisco.onep.element.NetworkElement.connect_(NetworkElement.java:2098)
        at com.cisco.onep.element.NetworkElement.connect(NetworkElement.java:1980)
        at com.cisco.onep.element.NetworkElement.connect(NetworkElement.java:1871)
        at com.cisco.csdn.onep.element.internal.OnepNode.connect(OnepNode.java:55)
        at com.cisco.csdn.onep.core.internal.Controller.addNodeConfig(Controller.java:84)
        at com.cisco.csdn.sal.implementation.internal.ResourceService.addNodeConfig(ResourceService.java:42)
        at com.cisco.csdn.resourcemanager.ResourceManager.addOnepNode(ResourceManager.java:74)
        at com.cisco.csdn.resourcemanager.ResourceManager._addOnepNode(ResourceManager.java:94)
        at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
        at sun.reflect.NativeMethodAccessorImpl.invoke(Unknown Source)
        at sun.reflect.DelegatingMethodAccessorImpl.invoke(Unknown Source)
        at java.lang.reflect.Method.invoke(Unknown Source)
        at org.eclipse.equinox.console.command.adapter.CommandProviderAdapter.main(CommandProviderAdapter.java:46)
        at org.eclipse.equinox.console.command.adapter.CommandProviderAdapter._main(CommandProviderAdapter.java:64)
        at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
        at sun.reflect.NativeMethodAccessorImpl.invoke(Unknown Source)
        at sun.reflect.DelegatingMethodAccessorImpl.invoke(Unknown Source)
        at java.lang.reflect.Method.invoke(Unknown Source)
        at org.apache.felix.gogo.runtime.Reflective.invoke(Reflective.java:137)
        at org.apache.felix.gogo.runtime.CommandProxy.execute(CommandProxy.java:82)
        at org.apache.felix.gogo.runtime.Closure.executeCmd(Closure.java:477)
        at org.apache.felix.gogo.runtime.Closure.executeStatement(Closure.java:403)
        at org.apache.felix.gogo.runtime.Pipe.run(Pipe.java:108)
        at org.apache.felix.gogo.runtime.Closure.execute(Closure.java:183)
        at org.apache.felix.gogo.runtime.Closure.execute(Closure.java:120)
        at org.apache.felix.gogo.runtime.CommandSessionImpl.execute(CommandSessionImpl.java:89)
        at org.apache.felix.gogo.shell.Console.run(Console.java:62)
        at org.apache.felix.gogo.shell.Shell.console(Shell.java:203)
        at org.apache.felix.gogo.shell.Shell.gosh(Shell.java:128)
        at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
        at sun.reflect.NativeMethodAccessorImpl.invoke(Unknown Source)
        at sun.reflect.DelegatingMethodAccessorImpl.invoke(Unknown Source)
        at java.lang.reflect.Method.invoke(Unknown Source)
        at org.apache.felix.gogo.runtime.Reflective.invoke(Reflective.java:137)
        at org.apache.felix.gogo.runtime.CommandProxy.execute(CommandProxy.java:82)
        at org.apache.felix.gogo.runtime.Closure.executeCmd(Closure.java:477)
        at org.apache.felix.gogo.runtime.Closure.executeStatement(Closure.java:403)
        at org.apache.felix.gogo.runtime.Pipe.run(Pipe.java:108)
        at org.apache.felix.gogo.runtime.Closure.execute(Closure.java:183)
        at org.apache.felix.gogo.runtime.Closure.execute(Closure.java:120)
        at org.apache.felix.gogo.runtime.CommandSessionImpl.execute(CommandSessionImpl.java:89)
        at org.eclipse.equinox.console.ssh.SshSession.run(SshSession.java:122)
Caused by: ExceptionIDL(code:2, text:NE Version:0.6.0 Client (Cisco ONE Controller - oneP Southbound Plugin) Version: 0.8.0, context:0)
        at com.cisco.onep.idl.NetworkElementIDL$NetworkElement_connectIDL_result.read(NetworkElementIDL.java:4011)
        at com.cisco.onep.idl.NetworkElementIDL$Client.recv_NetworkElement_connectIDL(NetworkElementIDL.java:278)
        at com.cisco.onep.idl.NetworkElementIDL$Client.NetworkElement_connectIDL(NetworkElementIDL.java:245)
        at com.cisco.onep.element.NetworkElement.connect_(NetworkElement.java:2077)
        ... 41 more
Failed to add OnePK node. Reason: Error connecting to oneP element
~~~

A debug from ONE device should be checked:

~~~
-Oct 31 08:22:12.358: [network_element_process:428][ONEP][Session]: Posting wait on xdm
-Oct 31 08:22:12.868: [cthrift_recv_main__:2137][ONEP][Message]: Server Done tos 1
-Oct 31 08:22:12.868: %ONEP_BASE-3-VERSION_ERR: [Element]: ONE-P version incompatible between client and network element.NE Version:0.6.0 Client (Cisco ONE Controller - oneP Southbound Plugin) Version: 0.8.0
-Oct 31 08:22:12.868: [cthrift_writev__:481][ONEP][Message]: Writev socket 2: bytes 149
-Oct 31 08:22:12.874: [network_element_process:428][ONEP][Session]: Posting wait on xdm
-Oct 31 08:22:12.875: [network_element_process:428][ONEP][Session]: Posting wait on xdm
~~~

In the above case the ONE version on physical device (Network Element or NE) isn't compatible. At least version 0.7.0 should be used.

Now the XNC can be managed using a Web browser:

![XNC Dashboard](/images/posts/2013/10/XNC-Dashboard.png "XNC Dashboard")

## References

* [Cisco Extensible Network Controller (XNC)](www.cisco.com/go/xnc "Cisco Extensible Network Controller (XNC)")

* [Cisco Extensible Network Controller (XNC) - Overview](http://www.cisco.com/en/US/prod/collateral/netmgtsw/ps13397/ps13400/at_a_glance_c45-729454.pdf "Cisco Extensible Network Controller (XNC) - Overview")
* [Cisco Extensible Network Controller Deployment Guide, Release 1.0](http://www.cisco.com/en/US/docs/net_mgmt/xnc/xnc_deploy/b_Extensible_Network_Controller_Deployment_Guide_10.pdf "Cisco Extensible Network Controller Deployment Guide, Release 1.0")
* [Cisco Extensible Network Controller Configuration Guide, Release 1.0](https://www.cisco.com/en/US/docs/net_mgmt/xnc/xnc_config/1-0/b_XNC_Configuration_Guide_10.html "Cisco Extensible Network Controller Configuration Guide, Release 1.0")
* [Cisco Extensible Network Controller (XNC) Developer Center](http://developer.cisco.com/web/xnc/home "Cisco Extensible Network Controller (XNC) Developer Center")
* [OpenDayLight project](http://www.opendaylight.org/ "OpenDayLight project")
