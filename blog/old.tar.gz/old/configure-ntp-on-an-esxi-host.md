---
title: "Configure NTP on an ESXI host"
date: "2014-06-18T09:00:00+01:00"
draft: false
---
Configure NTP is a mandatory task and it should be done as soon as possibile. Using vSphere Web Client look for Host -> Manage -> Settings:

![ntp_on_esxi](/images/posts/2014/06/ntp_on_esxi.png "ntp_on_esxi")

Using CLI:

~~~
export VI_SERVER=172.31.30.4
export VI_USERNAME=EXAMPLE\\Administrator
export VI_PASSWORD=Password
$ vicfg-ntp -h esxi1.example.com --add ntp1.example.com
$ vicfg-ntp -h esxi1.example.com --start
$ vicfg-ntp -h esxi1.example.com --list
Configured NTP servers:

ntp1.example.com
~~~

Using Host Profiles: General System Settings -> Date and Time Configuration -> Date and time configuration

![ntp_on_profiles](/images/posts/2014/06/ntp_on_profiles.png "ntp_on_profiles")

**Remember: ESXi uses UTC time and does not support changing time zones.**
