---
title: "The Darwin's Law of Evolution for computers"
date: "2017-10-09T09:00:00+01:00"
draft: false
---
We're leaving in the 'hype' era, where everything is sold as the Holy Graal for a non real-problem. Let's try to analyze things with a critical eye.

Pushed by a friend, who is writing a couple of very good posts I recommend[^1][^2], I'm now sharing my thoughts about automation, future of network engineers, AI and so on. Of course this is the point of view of my mind, as a result of 20 years playing in the IT world at both work and home.

It seems to me that vendors are trying to push more an more cool words, in a higher rate compared to the past. Few years ago the "IT outsourcing" mantra lasted for a while, and everyone had to "outsource" something to became a good manager. After a while it was the "cloud" era, but it was too early, so it was a false start. In the last two years, we're seeing many "mantras" coming together: big data, cloud (again, but with a different awareness), cyber security, automation, big data, machine learning. They are really too many mantras!
Not so many years ago, the idea of the cloud could be compared to a startup, and that startup was selling something not ready for the enterprise market. In the last few years, thanks to Amazon, Google, Microsoft, Salesforce and so on, enterprises and IT managers can now approach a valid cloud strategy with a more awareness.

> Lesson learned: better if we wait the second generation to have a mature technology.

I would add another one:

> Lesson learned: successful startup aims to be bought by big companies. Buying cloud services from small companies can lead to unexpected services/licenses change.

Now let's apply the above thesis to the current mantras, especially to: automation, machine learning and cyber security.

I guess I can affirm that networking vendors are including automation on every product. So we have REST APIs to program every device and UI (user interfaces) that should help to manage the whole infrastructure with few clicks and without the knowledge of what is below. But again the real world is different than what is told by marketing: lot of bugs that make software unusable or dangerous[^3].

Moreover asking supports to vendors gives less results than a walk to Santiago de Compostela, or to Lourdes:

![Adecco India at Cisco](/images/posts/2017/10/darwin-law-01.png)

It seems to me that vendors are not interested in selling good software, everything should be developed and sold "agile" (no matter if agile methodology is completely different thing). And the most critical aspect is that the quality of support teams is terrible: lot of FTE spent for debugging what should be analyzed by the vendor, lot of "it's by design" embarrassing limits, and really, too much untrained people unable to support anything or anyone.

> Lesson learned: vendors cannot write good software, and apparently they don't care too much about that. They are only interested on selling ideas, not real and working features.

Let's move now on machine learning, the "hype" that will make humans useless. Computers are able to learn and detect things better than humans and will be able to analyze lot of data in a relative short of time. So big data is not a problem anymore. But... because there is always a "but", the real world is a little bit different. If someone is using Facebook to guess sexual orientation[^4], we should ask to ourselves how much that research is "marketing" and how much is "real". And the answer is that machine learning, used to detect if a photographed man is gay, is slightly more efficient than an untrained human[^5].
So current machine learning algorithms perform better than thousands of untrained people. And that's still a good thing, but we should remember that machine learning algorithms don't (currently) perform like experts.

> Lesson learned: (current) machine learning algorithms slightly perform better than untrained humans, but they can manage lot of data and much faster than humans.

But machine learning applied to automation and cyber security will save the world! (maybe)

The security of our infrastructures/software/iot/whatever electronic device is embarrassing.
We have lot of unupgradeable devices (mobile phones, IOT devices, set top box...) and we have also a lot of vulnerable by design devices[^6].
Moreover we have infrastructures managed by untrained (cheap) people, all around the world. We have critical services exposed to Internet with default or blank password[^7].
But we have lot of vendors selling the Holy Graal of security[^8].

Holy Graal is not enough I guess, because we still have thousands of computers infected by WannaCry ransomware and sooner or later someone will pay the price[^9].

> Lesson learned: cyber security is the current mantra, but it won't help too much.

So we have mature cloud services, but automation, machine learning and security are still too young. The last year demonstrated that connecting everything to Internet is not always a good idea, especially if we're connecting hospitals[^10], 911 emergency number[^11], peace makers[^12], airplanes[^13] or IOT devices[^14].

Should we live like Amish people does? Indeed that's a possibility, and when I retire, I'll think about that for sure.

## How will be the future?

To conclude my mind-flow:

* Will cloud kill IT experts? no, because infrastructures must be managed, platform must be well-deployed, service must be well-designed and well-implemented.
* Will automation kill network experts? no, because network experts started to automate things 10 years ago, and the current "hype" is not changing things so much. You have to know what is below if you want to implement a good and effective solution.

## Is cybersecurity only a new "hype"?

The network has been always asked to fix poorly designed softwares. I could write a lot about how "streched datacenter" is a bad choice, but that's not the right post. I can see more a more good tools used to fix the wrong thing (containers used like a VM, snapshot used as a backup...). But the network layer cannot fix every single mistake of above layers, and sooner or later the above layers will pay a price[^15].

I think that the Darwin's Law of Evolution by Natural Selection is valid also for computers and electronic devices. But it could drammatically impact on humans life too.

![Blackout](/images/posts/2017/10/darwin-law-02.jpg)

[^1]: [The glass cage](https://www.ifconfig.it/hugo/post/theglasscage/ "The glass cage")
[^2]: [Is more technology good for your business?](https://www.ifconfig.it/hugo/post/ismoretechgoodforbusiness/ "Is more technology good for your business?")
[^3]: [Let’s Drop Some Random Commands, Shall We?](http://blog.ipspace.net/2017/04/lets-drop-some-random-commands-shall-we.html "Let’s Drop Some Random Commands, Shall We?")
[^4]: [New AI can guess whether you're gay or straight from a photograph](https://www.theguardian.com/technology/2017/sep/07/new-artificial-intelligence-can-tell-whether-youre-gay-or-straight-from-a-photograph "New AI can guess whether you're gay or straight from a photograph")
[^5]: [You're Looking Gay, Today](https://www.spreaker.com/user/runtime/dataknightmare-eng-1x01-youre-looking-ga "You're Looking Gay, Today")
[^6]: [Il grande down di Infostrada (e i clienti inferociti)](https://www.nextquotidiano.it/infostrada-down-clienti-inferociti/ "Il grande down di Infostrada (e i clienti inferociti)")
[^7]: [115 batshit stupid things you can put on the internet in as fast as I can go by Dan Tentler](https://www.youtube.com/watch?v=hMtu7vV_HmY&t=531s "115 batshit stupid things you can put on the internet in as fast as I can go by Dan Tentler")
[^8]: [The weirdest thing about #WannaCry is all the phone calls I'm getting about security must-have stuffs to protect from anything.](https://twitter.com/adainese/status/864556802943442944)
[^9]: [Return of WannaCry? LG Hit by Ransomware Attack](https://itsecuritycentral.teramind.co/2017/08/21/return-of-wannacry-lg-hit-by-ransomware-attack/ "Return of WannaCry? LG Hit by Ransomware Attack")
[^10]: [UK hospitals hit with massive ransomware attack](https://www.theverge.com/2017/5/12/15630354/nhs-hospitals-ransomware-hack-wannacry-bitcoin "UK hospitals hit with massive ransomware attack")
[^11]: [The Coming Software Apocalypse](https://www.theatlantic.com/technology/archive/2017/09/saving-the-world-from-code/540393/ "The Coming Software Apocalypse")
[^12]: [FDA Recalls Nearly Half a Million Pacemakers Over Hacking Fears](https://thehackernews.com/2017/08/pacemakers-hacking.html "FDA Recalls Nearly Half a Million Pacemakers Over Hacking Fears")
[^13]: [Germanwings Crash Prompts Debate About Remote-Controlled Planes](https://www.nbcnews.com/storyline/german-plane-crash/germanwings-tragedy-prompts-discussion-about-remote-controlled-planes-n343446 "Germanwings Crash Prompts Debate About Remote-Controlled Planes")
[^14]: [650Gbps DDoS Attack from the Leet Botnet](https://www.incapsula.com/blog/650gbps-ddos-attack-leet-botnet.html "650Gbps DDoS Attack from the Leet Botnet")
[^15]: [Microsoft and Mozilla ban Dutch government root certificate](https://www.theinquirer.net/inquirer/news/2107413/microsoft-mozilla-ban-dutch-government-root-certificate "Microsoft and Mozilla ban Dutch government root certificate")
