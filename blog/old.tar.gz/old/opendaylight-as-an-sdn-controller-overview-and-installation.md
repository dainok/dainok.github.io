---
title: "OpenDaylight as an SDN controller: overview and installation"
date: "2013-11-07T09:00:00+01:00"
draft: false
---
OpenDaylight Project is a SDN controller sponsored by a lot of [OpenDaylight members](http://www.opendaylight.org/project/members "OpenDaylight members") and Cisco itself. Cisco Extensible Network Controller (XNC) is a controller for the ONE enabled devices based on OpedDaylight project.

![hydrogen_diagram_-_final_0](/images/posts/2013/11/hydrogen_diagram_-_final_0.jpg "hydrogen_diagram_-_final_0")

## Installation (on iou-web VM)

OpenDaylight comes as a Java app,  so Java must be installed on a Linux system. Let's assume we want to install OpenDaylight on [Cisco IOU Web Interface](http://www.routereflector.com/en/cisco/cisco-iou-web-interface/ "Cisco IOU Web Interface") VM: iou-web is a clean CentOS 6 installation, so it's a good platform for OpenDaylight tests.

Java SE Runtime Environment (JRE) 7 must be downloaded, so get the [jre-7u45-linux-i586.rpm](http://www.oracle.com/technetwork/java/javase/downloads/jre7-downloads-1880261.html "jre-7u45-linux-i586.rpm") package and upload it to the iou-web VM using SCP. Upload an [OpenDaylight distribution](https://jenkins.opendaylight.org/controller/job/controller-merge/lastSuccessfulBuild/artifact/opendaylight/distribution/opendaylight/target/ "OpenDaylight distribution") packages also.

The installations steps are very simple:

~~~
yum install unzip
rpm -Uvh jre-7u45-linux-i586.rpm
unzip distribution.opendaylight-osgipackage.zip -d /opt
~~~

Because iou-web comes with a firewall configured, the ports used by OpenDaylight must be properly configured. In this case 8023, and 8080 ports will be used:

~~~
iptables -L INPUT -n --line-numbers
Chain INPUT (policy ACCEPT)
num  target     prot opt source               destination
1    ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0           state RELATED,ESTABLISHED
2    ACCEPT     icmp --  0.0.0.0/0            0.0.0.0/0
3    ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0
4    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0           state NEW tcp dpt:22
5    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0           state NEW tcp dpt:80
6    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0           state NEW tcp dpts:2001:3024
7    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0           state NEW tcp dpts:32768:61000
8    REJECT     all  --  0.0.0.0/0            0.0.0.0/0           reject-with icmp-host-prohibited
~~~

An additional rule must be installed before the rule #8:

~~~
iptables -I INPUT 8  -m state --state NEW -p tcp -m multiport --dports 6633,8023,8080 -j ACCEPT
service iptables save
~~~

Now ports 6633, 8023 and 8080 are permitted:

~~~
iptables -L INPUT -n --line-numbers
Chain INPUT (policy ACCEPT)
num  target     prot opt source               destination
1    ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0           state RELATED,ESTABLISHED
2    ACCEPT     icmp --  0.0.0.0/0            0.0.0.0/0
3    ACCEPT     all  --  0.0.0.0/0            0.0.0.0/0
4    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0           state NEW tcp dpt:22
5    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0           state NEW tcp dpt:80
6    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0           state NEW tcp dpts:2001:3024
7    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0           state NEW tcp dpts:32768:61000
8    ACCEPT     tcp  --  0.0.0.0/0            0.0.0.0/0           state NEW multiport dports 6633,8023,8080
9    REJECT     all  --  0.0.0.0/0            0.0.0.0/0           reject-with icmp-host-prohibited
~~~

## Starting OpenDaylight and connecting to
OpenDaylight can be started using Java (we wants telnet port on TCP 8023):

~~~
export JAVA_HOME=/usr/java/latest/
cd /opt/opendaylight/
/opt/opendaylight/run.sh -start 8023
~~~

Now OpenDaylight can be managed using Telnet (port 8023) and HTTP (port 8080) using the IP address of the iou-web VM itself: default username is "admin" with password "admin".
![opendaylight_login](/images/posts/2013/11/opendaylight_login.png "opendaylight_login")
OpenDaylight can be debugged using the console mode:

~~~
/opt/opendaylight/run.sh -stop
/opt/opendaylight/run.sh -console
~~~

## Adding a device under OpenDaylight controller

[MiniNet as an SDN test platform](http://www.routereflector.com/en/2013/11/mininet-as-an-sdn-test-platform/ "MiniNet as an SDN test platform") should be used for initial tests with OpenDaylight. Let's assume we want to create a tree topology and import into OpenDaylight controller:

~~~
sudo mn --controller=remote,ip=192.168.32.129 --topo=tree,3
~~~

Now OpenDaylight controller can manage seven switches:

>![mininet_on_sdn_controller](/images/posts/2013/11/mininet_on_sdn_controller.png "mininet_on_sdn_controller")

## References

* [OpenDayLight project](http://www.opendaylight.org/ "OpenDayLight project")
* [OpenDaylight Controller:Installation](https://wiki.opendaylight.org/view/OpenDaylight_Controller:Installation "OpenDaylight Controller:Installation")
* [OpenDaylight Controller: download](https://jenkins.opendaylight.org/controller/job/controller-merge/lastSuccessfulBuild/artifact/opendaylight/distribution/opendaylight/target/ "OpenDaylight Controller: download")d
