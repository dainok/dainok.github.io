---
title: "Social Networking in action"
date: "2017-11-30T09:00:00+01:00"
draft: false
---
I spent the last two days presenting and meeting people. I have to admin that I enjoyed a lot and It was a pleasure meet so many interesting people.

After lot of months, the [Automate IT²](https://automateit2.com/ "Automate IT²") went live. Not so much attendees, but some of them came from abroad, and they were happy about the event itself.
I especially enjoyed the presentation of [Xavier Homs](https://www.linkedin.com/in/xhoms/ "Xavier Homs") from Palo Alto; it was about a real automation case study on automatic firewall policy generation from a CMDB.
I would thanks also [Gabriele Gerbino](https://www.linkedin.com/in/gabrielegerbino/ "Gabriele Gerbino") who assisted me in the organization of the event, and [Mircea Ulinic](https://www.linkedin.com/in/mirceaulinic/ "Mircea Ulinic") who decided to take a trip and present in our, new born, event.
Of course thanks also to [Palo Alto Networks](https://www.paloaltonetworks.com/ "Palo Alto Networks"), [Luigi Mori](https://www.linkedin.com/in/luigi-mori-b010601/ "Luigi Mori"), for offering us a comfortable room.
I had the chance to meet some new and old friends, once again, and it's always a pleasure share a dinner with them.

The day after I was presenting in the [CisCon](http://www.ciscon.net/ "CisCon") event, organized by [AreaNetworking.it](http://www.areanetworking.it/ "AreaNetworking.it") by [Federico Lagni](https://www.linkedin.com/in/federicolagni/ "Federico Lagni"). It was the first edition but in my opinion it was a nice event: interesting speech, not too technical but enough to give an overview to the audience, with a open Q&A session between auditors and all presenters.

Both events gave me the chance to meet interesting and passionate people. I had many question about [UNetLab](http://www.routereflector.com/unetlab/ "UNetLab") and my CCIE path, started in 2010 in another similar event ([CCIE Dinner](http://www.areanetworking.it/cisco-ccie-dinner "CCIE Dinner")).
	During yesterday lunch I had the chance to speak with [Diego Zucca](https://www.linkedin.com/in/diegozucca/ "Diego Zucca"), and he told me about [Cisco Academies in italian prisons](https://www.cisco.com/web/IT/training_education/networking_academy/stories/case_bollate2.pdf "A Bollate i detenuti diventano esperti di Internet"). I didn't know anything about that, and I think that's a great chance for prisoners to start a new life enjoing a beautiful world.

I cannot ignore that in a iper-connected world, people are still meeting in person. And, maybe it's a my opinion only, but I feel that persons need to physically meet more than ever. And that's why we still organize GeekOn Dinners with friends and colleagues here, we're we live: a good chance to meet friends, speak about technologies, jobs, work places, bullshits (why not). Everything in a safe and friendly place under NDA (of course).

## References

* Automate IT² @ Milan: [A CMDB for IT infrastructures](/slides/20171128-AutomateIT2-A CMDB for IT infrastructures.html "A CMDB for IT infrastructures")
* CisCon @ Milan: [Protection and Visibility for Enterprise Networks](/slides/20171129-CisCon-Protection and Visibility for Enterprise Networks.html "Protection and Visibility for Enterprise Networks")
