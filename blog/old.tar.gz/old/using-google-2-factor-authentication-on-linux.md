---
title: "Using Google 2-factor authentication on Linux"
date: "2016-10-10T09:00:00+01:00"
draft: false
---
Google Authenticator is a soft token generator for both Android and iPhone mobile phones. It's usually used to access Google services using a 2-factor authentication, but it can used also to access properly configured Linux server.

Google Authenticator is free and can be used for multiple account.

## Installation

On some Linux distribution, the Google package is officially available:

~~~
# apt-get -y install libpam-google-authenticator
~~~

## System configuration

Edit the `/etc/pam.d/sshd` file to enable `pam_google_authenticator` module before others:

~~~
# Standard Un*x authentication.
auth       required     pam_google_authenticator.so
@include common-auth
~~~

Reconfigure now SSH daemon editing `/etc/ssh/sshd_config` file settint the following options:

~~~
ChallengeResponseAuthentication no
PasswordAuthentication yes
PubkeyAuthentication yes
PermitRootLogin no
~~~

The above configuration will allow users authentication using Google soft token. Public key authentication is allowed but not using `root` user.

Reload SSH daemon:

~~~
# systemctl restart sshd
~~~

Be aware you need to configure at least one to use Google 2-factor authtentication, or no user will be allowed to login.

Mind also that 2-factor authentication requires an active internet connection, otherwise no code can be verified. That's why public key authentication is available and why it's configured on SSH connections only.

## User configuration

Each user willing to use the Google 2-factor authentication must configure it's own environment:

~~~
$ google-authenticator

Do you want authentication tokens to be time-based (y/n) y
https://www.google.com/chart?chs=200x200&chld=M|0&cht=qr&chl=otpauth://totp/andrea@darkgate%3Fsecret%3DP67F2KB36TMDX4KK

[...]

Your new secret key is: P67F2KB36TMDX4KK
Your verification code is 050992
Your emergency scratch codes are:
  17248166
  55321811
  29134462
  99575841
  89403312

Do you want me to update your "/home/andrea/.google_authenticator" file (y/n) y

Do you want to disallow multiple uses of the same authentication
token? This restricts you to one login about every 30s, but it increases
your chances to notice or even prevent man-in-the-middle attacks (y/n) y

By default, tokens are good for 30 seconds and in order to compensate for
possible time-skew between the client and the server, we allow an extra
token before and after the current time. If you experience problems with poor
time synchronization, you can increase the window from its default
size of 1:30min to about 4min. Do you want to do so (y/n) n

If the computer that you are logging into isn't hardened against brute-force
login attempts, you can enable rate-limiting for the authentication module.
By default, this limits attackers to no more than 3 login attempts every 30s.
Do you want to enable rate-limiting (y/n) y
~~~

Install now the [Google Authenticator](https://play.google.com/store/apps/dev?id=5700313618786177705 "Google Authenticator") app on a mobile phone, and open the app.

Add a new account pressing the `+` button, and use the above `secret key` or the provided QR code.

![Add a new account on Google Authenticator](/images/posts/2016/10/Google-Authenticator-1.png "Add a new account on Google Authenticator")

Another account will be immediately available for your Linux system.

![Multiple account Google Authenticator](/images/posts/2016/10/Google-Authenticator-2.png "Multiple account on Google Authenticator")

The login process will ask now for the soft-token PIN:

~~~
login as: andrea
Using keyboard-interactive authentication.
Verification code:
Using keyboard-interactive authentication.
Password:
~~~

Users without the above configuration will fail:

~~~
Oct 10 06:03:10 darkgate sshd(pam_google_authenticator)[13733]: Failed to read "/home/test/.google_authenticator"
~~~

## References

* [Google Authenticator OpenSource](http://code.google.com/p/google-authenticator/ "Google Authenticator OpenSource")
* [Google Authenticator Android app](https://play.google.com/store/apps/dev?id=5700313618786177705 "Google Authenticator Android app")
* [Google Authenticator iPhone app](https://itunes.apple.com/us/app/google-authenticator/id388497605?mt=8 "Google Authenticator iPhone app")
