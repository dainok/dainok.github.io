---
title: "Configure a separate network for a VMware lab"
date: "2014-01-15T09:00:00+01:00"
draft: false
---
A new VMware lab was needed: it should be completely separated by production network and, in the same time, should be accessible by remote workstations. This time a VPN approach was used:
![lab_diagram](/images/posts/2014/01/lab_diagram.png "lab_diagram")
A Linux server provides connectivity to lab networks (172.31.16.0/24). Each client can reach the lab networks using a VPN (PPTP) connection terminating on the Linux gateway. Everything inside the lab networks cannot see outside world: the Linux gateway acts as a firewall too.

Using this approach routing of corporate network has not been modified.

## Configuring Linux networking

The Linux server uses eth0 to reach the corporate network (10.0.0.217) and eth1 to reach the lab (172.31.16.1):

~~~
# cat /etc/sysconfig/network-scripts/ifcfg-eth1
DEVICE=eth1
HWADDR=00:0F:20:12:34:56
ONBOOT=yes
BOOTPROTO=static
IPADDR=172.31.16.1
NETMASK=255.255.255.224
~~~

The gateway will be used to route all lab networks, summarized in 172.31.16.0/24:

~~~
# cat /etc/sysconfig/network-scripts/route-eth1
172.31.16.0/24 via 172.31.16.2
~~~

Be sure that Linux gateway can route traffic:

~~~
# cat /etc/sysctl.conf | grep ip_forward
net.ipv4.ip_forward = 1
# sysctl -p
~~~

## Installing and configuring PPTP daemon

There are many VPN tunnels available, but the most simple and ready to use is PPTP, provided on Linux by [PopTop](http://poptop.sourceforge.net/ "PopTop"). [PopTop repository](http://poptop.sourceforge.net/yum/stable/packages/ "PopTop repository") and install both ppp and ppptpd packages:

~~~
# rpm -Uvh pptpd-1.4.0-1.rhel5.i386.rpm ppp-2.4.4-14.1.rhel5.rpm
~~~

In our example, clients will use 172.31.16.32-63/32 ip address range:

~~~
# cat /etc/pptpd.conf
option /etc/ppp/options.pptpd
logwtmp
localip 172.31.16.1
remoteip 172.31.16.32-63
~~~

The mppe encryption is not supported on some distributions; because it's a VPN connection through a corporate network used for test purposes, encryption can be disabled:

~~~
# cat /etc/ppp/options.pptpd | grep mppe
#require-mppe-128
~~~

Then create required user(s):

~~~
# /etc/ppp/chap-secrets
# Secrets for authentication using CHAP
# client        server  secret                  IP addresses
user            pptpd   password                *
~~~

Finally start PPTP daemon:

~~~
# service pptpd start
# chkconfig pptpd on
~~~

## Configure the Linux firewall

Lab networks cannot be reach the outside world, except for DHCP and TFTP services:

~~~
# iptables -A INPUT -s 172.31.16.0/255.255.255.0 -d 172.31.16.0/255.255.255.0 -i eth1 -j ACCEPT
# iptables -A INPUT -i eth1 -p udp -m udp --dport 69 -j ACCEPT
# iptables -A INPUT -i eth1 -p udp -m udp --dport 68 -j ACCEPT
# iptables -A INPUT -i eth3 -j REJECT --reject-with icmp-port-unreachable
# iptables -A INPUT -i eth3 -j DROP
~~~

The REJECT keywords will prevent timeout when requests start from inside the lab.

If lab must connect to outside networks, NAT (MASQUERADE) is required:

~~~
# iptables -A POSTROUTING -o bond0 -j MASQUERADE
# iptables -A FORWARD -m state --state RELATED,ESTABLISHED -j ACCEPT
# iptables -A FORWARD -d 1.1.1.1 -i eth3 -p udp -m udp --dport 8080 -j ACCEPT
# iptables -A FORWARD -i eth3 -j REJECT --reject-with icmp-port-unreachable
# iptables -A FORWARD -i eth3 -j DROP
~~~

## Configuring a Windows client

The configuration is very simple:

1. add a new VPN connection, use PPTP as VPN type with no cryptography;
2. configure the IP address of the Linux gateway (10.0.0.217);
3. use the account previously configured (admin:)
4. be sure "Use default gateway on remote network" is unchecked (under Advanced TCP/IP settings configuration);
5. be sure "Disable class based route addition" is unchecked.

After connecting the client should be able to reach the 172.31.16.0/24 network because of the 172.31.0.0/16 route is installed:

~~~
C:\Windows\system32>route print | find "172.31.0.0"
       172.31.0.0      255.255.0.0      172.31.16.1     172.31.16.32     11
~~~

## References

* [How to Setup a VPN (PPTP) Server on Debian Linux](http://www.howtogeek.com/51237/setting-up-a-vpn-pptp-server-on-debian/ "How to Setup a VPN (PPTP) Server on Debian Linux")
* [http://poptop.sourceforge.net/](http://poptop.sourceforge.net/ "http://poptop.sourceforge.net/")
