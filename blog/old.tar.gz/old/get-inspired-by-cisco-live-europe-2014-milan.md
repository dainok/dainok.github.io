---
title: "Get Inspired by Cisco Live Europe 2014 (Milan)"
date: "2014-02-01T09:00:00+01:00"
draft: false
---
The Cisco Live Europe 2014 (Milan) has just ended, and I think I will need few days to reorganize my ideas. It was my first time I had the great opportunity to attend the CLEUR, and moreover I could do it as a CCIE.

![live14](/images/posts/2014/02/live14.png "live14")

CLEUR is not just a Cisco event (maybe I should say THE Cisco event), CLEUR is also a unique opportunity to meet technology, expertise, visions, friends and inspirations.
Let me explain better what I mean.

## Expertise

I attended few technical sessions on Data Center, IPv6, VIRL/CML and 801.x. During that sessions I was able to understand so many small details that I missed before. I don't always have the time to verify every single details of each technology: a 2 hours session was very helpful to connecting the dots and improve my skills and my design.
Moreover I had the chance to speak face to face with a many Cisco guys and I want to publicly thank them for their suggestions on IPv6 and especially on WAAS and DMVPN.

## Technology

During my days at CLEUR I decided to reserve time to visit the World of Solutions. I did 't have expectations, I just wanted to have a walk between vendors. It was simply great!
I had the opportunity to see solutions that feet my actual needing and very competent guys were available to speak about the high level design but also to cover every single technical detail.

![wos](/images/posts/2014/02/wos.jpg "wos")

I had the chance to speak about automation through Puppet and OnePk, about documentation and monitoring with NetBrain, about DNS security with Infloblox, about office extend and real example of SDN in a service provider network with Cisco.

I realized that four days were not enough to see everything I need.

## Vision

Cisco is not only a technology provider, in my opinion it's also a vision maker. Both keynotes were about Internet of Everything, but from a high level point of view.

![keynote](/images/posts/2014/02/keynote.jpg "keynote")

There was also an IoE section where I was able to discover details about sensors and [Fog Computing](http://www.cisco.com/web/about/ac50/ac207/crc_new/university/RFP/rfp13078.html "Fog Computing"): when Cloud meets the ground.

## Friends

CLEUR is an European event, and is the chance to meet friends who live in other country. I was present at both the party: the one  reserved to CCIE guys and the great Customer Appreciation Event.

![party](/images/posts/2014/02/party.jpg "party")

CLEUR gave me the chance to meet celebrities like [Himawan Nugroho](https://twitter.com/hnugroho "Himawan Nugroho"), [Amy Lewis](https://twitter.com/CommsNinja "Amy Lewis"), Jeanne Beliveau-Dunn and many others...

## Get Inspired by Cisco Live

As I mentioned before, I will need few days to reorganize my ideas. Real networkers really love their jobs. Meeting people, new ideas, different minds make my brain to breath. Now there are so many new ideas that are waiting for me: I need to discover details, to test and share what I got. The circle of knowledge must not be stopped.

## Thanks

Finally I want to thank [SAIV](http://www.saiv.it/ "SAIV") and [Gian Paolo Boarina](http://www.ifconfig.it/ "Gian Paolo Boarina"), the system integrator which give me the chance to attend the Cisco Live 2014 in Milan, and all the great guys who actively listen to my needing, ideas and proposals.

![saiv](/images/posts/2014/02/saiv.png "saiv")

See you next year Cisco, in Milan again!
