---
title: "Unattended VMware ESXi installation via PXE Boot and Kickstart"
date: "2014-01-02T09:00:00+01:00"
draft: false
---
As many operating systems, VMware ESXi can be automatically installed via PXE (Preboot Execution Environment). PXE is a way to boot an operating system using only an ethernet card. Kickstart is way to script a Linux unattended installation. VMware ESXi support Kickstart syntax.

PXE relays on:

* DHCP: the booting server will ask for IP configuration (IP, netmask, gateway and file server)
* TFTP: the TFTP server provides kernel and additional files via TFTP protocol.

Obiosuly PXE must be supported by at least an ethernet NIC and by the BIOS.

Download from syslinux and VMware sites the following files:

* syslinux-3.86.tar.gz
* VMware-VMvisor-Installer-5.1.0.update01-1065491.x86_64.iso

Upload both files to a Linux server.

Because VMware ESXi mbootc.32 file is compiled using syslinux-3.86, the same version must be used:

~~~
# mount -o loop,ro VMware-VMvisor-Installer-5.1.0.update01-1065491.x86_64.iso /mnt
# strings /mnt/isolinux.bin | grep ISOLINUX
ISOLINUX 3.86
~~~

Configure the environment as following:

~~~
# yum -y install tftp-server httpd dhcp httpd
# tar --no-same-permissions --no-same-owner --strip-components 2 -xzf syslinux-3.86.tar.gz -C /tftpboot/pxe syslinux-3.86/core/pxelinux.0
# tar --no-same-permissions --no-same-owner --strip-components 3 -xzf syslinux-3.86.tar.gz -C /tftpboot/pxe syslinux-3.86/com32/menu/menu.c32 syslinux-3.86/com32/modules/chain.c32
# mkdir -p /tftpboot/pxe/pxelinux.cfg
# mkdir -p /mnt
# mount -o loop,ro VMware-VMvisor-Installer-5.1.0.update01-1065491.x86_64.iso /mnt
# mkdir -p /tftpboot/pxe/esxi-5.1.0u1-1065491
# rsync -a /mnt/ /tftpboot/pxe/esxi-5.1.0u1-1065491/
# cat /mnt/boot.cfg | sed -e "s#/##g" -e "3s#^#prefix=esxi-5.1.0u1-1065491\n#" > /tftpboot/pxe/esxi-5.1.0u1-1065491/boot.cfg
~~~

Three files are taken from the syslinux-3.86 package, then the content of the ESXi ISO is copied under tftboot path.
Create also the following file, needed for PXE boot menu:

~~~
# vi /tftpboot/pxe/pxelinux.cfg/default
default menu.c32
prompt 0
timeout 300

menu title PXE Boot Menu

label local
  menu label ^0 - Boot from first hard drive
  com32 chain.c32
  append hd0

label 1
  menu label ^1 - Install VMware ESXi 5.1.0u1
  kernel esxi-5.1.0u1-1065491/mboot.c32
  append -c esxi-5.1.0u1-1065491/boot.cfg ks=http://172.31.30.1/ks/esxi-5.1.0u1.cfg
~~~

By default local disk is used after 30 seconds.
At the end the following structure will be available:

~~~
# tree /tftpboot/
/tftpboot/
`-- pxe
    |-- chain.c32
    |-- esxi-5.1.0u1-1065491
[...]
    |-- menu.c32
    |-- pxelinux.0
    `-- pxelinux.cfg
        `-- default
~~~

DHCP must be configured with next-server (66) and filename (67) options:

~~~
# vi /etc/dhcpd.conf
ddns-update-style ad-hoc;
ignore client-updates;

allow booting;
allow bootp;
local-address 172.31.30.1;

subnet 172.31.30.0 netmask 255.255.255.224 {
        option routers                  172.31.30.1;
        option subnet-mask              255.255.255.224;
        range 172.31.30.16 172.31.30.30;
}
subnet 172.31.30.64 netmask 255.255.255.192 {
        option routers                  172.31.30.65;
        option subnet-mask              255.255.255.192;
        range 172.31.30.112 172.31.30.126;
}
subnet 172.31.30.128 netmask 255.255.255.192 {
        option routers                  172.31.30.129;
        option subnet-mask              255.255.255.192;
        range 172.31.30.176 172.31.30.190;
}

class "pxeclients" {
        match if substring(option vendor-class-identifier, 0, 9) = "PXEClient";
        next-server 172.31.30.1;
        filename = "pxe/pxelinux.0";
}
class "etherboot" {
        match if substring(option vendor-class-identifier, 0, 9) = "Etherboot";
        next-server 172.31.30.1;
        filename "pxe/pxelinux.0";
}
~~~

An embedded DHCP server on Cisco switch can also be used:

~~~
ip dhcp pool VLAN2
   network 172.31.30.64 255.255.255.192
   bootfile pxe/pxelinux.0
   next-server 172.31.30.1
   default-router 172.31.30.65
!
ip dhcp pool VLAN3
   network 172.31.30.128 255.255.255.192
   bootfile pxe/pxelinux.0
   next-server 172.31.30.1
   default-router 172.31.30.65
~~~

A simple Kickstart file can be create as following:

~~~
# vi /var/www/html/ks/esxi-5.1.0u1.cfg
accepteula
install --firstdisk --overwritevmfs
rootpw password
network --bootproto=dhcp --device=vmnic0
reboot
~~~

Finally be sure that DHCP and TFTP server starts on boot:

~~~
# service dhcpd restart
# service xinetd restart
# chkconfig dhcpd on
# chkconfig tftp on
# umount /mnt
~~~

During the boot, if no local OS is installed, the server, with UUID b8945908-d6a6-41a9-611d-74a6ab80b83d and MAC address 01-88-99-aa-bb-cc-dd, should boot from Ethernet:

* an IP address is requested using DHCP
* the DHCP server offers IP, netmask, gateway, file server and file name parameters
* the server will get via TFTP the following files:
    * /tftpboot/pxe/pxelinux.cfg/b8945908-d6a6-41a9-611d-74a6ab80b83d
    * /tftpboot/pxe/pxelinux.cfg/01-88-99-aa-bb-cc-dd
    * /tftpboot/pxe/pxelinux.cfg/C000025B
    * /tftpboot/pxe/pxelinux.cfg/C000025
    * /tftpboot/pxe/pxelinux.cfg/C00002
    * /tftpboot/pxe/pxelinux.cfg/C0000
    * /tftpboot/pxe/pxelinux.cfg/C000
    * /tftpboot/pxe/pxelinux.cfg/C00
    * /tftpboot/pxe/pxelinux.cfg/C0
    * /tftpboot/pxe/pxelinux.cfg/C
    * /tftpboot/pxe/pxelinux.cfg/default


If ESXi installation menu entry is selected, the server get ESXI installation files and Kickstart via TFTP from the file server.

![esxi_via_pxe](/images/posts/2014/01/esxi_via_pxe.png "esxi_via_pxe")

If the error "Failed to load COM32 file exi-5.1.0u1-1065491/mboot.c32" appear, double check the syslinux version used: pxelinux.0 must come from the same syslinux version used on ESXi ISO.

## References

* [PXELINUX](http://www.syslinux.org/wiki/index.php/PXELINUX "PXELINUX")
* [VMware ESXi 5 Interactive PXE Installation Improvements](http://www.vcritical.com/2011/07/vmware-esxi-5-interactive-pxe-installation-improvements/ "VMware ESXi 5 Interactive PXE Installation Improvements")
* [Automating ESXi 5 Kickstart Tips & Tricks](http://www.virtuallyghetto.com/2011/07/automating-esxi-5x-kickstart-tips.html "Automating ESXi 5 Kickstart Tips & Tricks")
* [Deploying ESXi 5.x using the Scripted Install feature (2004582)](http://kb.vmware.com/selfservice/microsites/search.do?language=en_US&cmd=displayKC&externalId=2004582 "Deploying ESXi 5.x using the Scripted Install feature (2004582)")
